/* eslint-disable @typescript-eslint/no-explicit-any */
declare namespace JSX {
  // Define custom elements for A-Frame entities.
  // We use `IntrinsicElements` to augment the built-in JSX elements recognized by React/TypeScript.
  interface IntrinsicElements {
    'a-scene': any;
    'a-assets': any;
    'a-camera': any;
    'a-entity': any;
    'a-box': any;
    'a-plane': any;
    'a-cylinder': any;
    'a-sphere': any;
    'a-light': any;
    // Catch-all for any other A-Frame components/attributes not explicitly listed
    [key: string]: any; 
  }
}

// Global declaration to fix the 'Property 'AFRAME' does not exist on type 'Window'' error
declare global {
  interface Window {
    AFRAME?: any;
  }
}