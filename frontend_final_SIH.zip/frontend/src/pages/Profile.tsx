import { Layout } from "@/components/Layout";
import  ProfileComp  from "@/components/ui/profile";

const ProfilePage = () => {
  return (
    <Layout>
      <ProfileComp />
    </Layout>
  );
};

export default ProfilePage;
