import { Layout } from "../components/Layout";
import AFrameScene from "../components/ui/fileRoom"

export default function File() {

  return (
    <Layout>
      <div className="w-full h-full flex flex-1 overflow-hidden">
          <AFrameScene />
    </div>
        </Layout>
        
    
  );
}

