import { Layout } from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BarChart3, TrendingUp, DollarSign, Clock, CheckCircle, FileText, Calendar, Filter, Zap, LineChart, PieChart } from "lucide-react"; 

// --- Hardcoded Data for Finance & Accounts ---

// 1. Finance-Specific Key Metrics
const financeMetrics = [
  {
    title: "Pending Invoice Value",
    value: "₹ 5.2 Cr", 
    change: "-18%",
    trend: "down",
    icon: DollarSign,
    description: "Total value of invoices awaiting approval (MoM)"
  },
  {
    title: "Avg. Invoice Approval Time",
    value: "4.5 Days", 
    change: "+0.3 Days",
    trend: "down", 
    icon: Clock,
    description: "Average time from receipt to payment (QoQ)"
  },
  {
    title: "Audit-Ready Documents",
    value: "98%", 
    change: "+1%", 
    trend: "up",
    icon: CheckCircle,
    description: "Critical documents flagged as fully indexed and auditable"
  },
  {
    title: "Documents Processed Today", 
    value: "1,120",
    change: "+15%",
    trend: "up",
    icon: FileText,
    description: "Invoices, POs, and Reports scanned/indexed"
  }
];

// 2. Expenditure by Department (Bar Chart Data)
const expenditureData = [
  { department: "Operations", amount: 45.6, percentage: 38, color: "bg-red-500", label: "₹45.6 Cr" },
  { department: "Engineering & Maint.", amount: 32.5, percentage: 27, color: "bg-blue-500", label: "₹32.5 Cr" },
  { department: "Project Expansion", amount: 20.9, percentage: 17, color: "bg-green-500", label: "₹20.9 Cr" },
  { department: "HR & Admin", amount: 12.0, percentage: 10, color: "bg-yellow-500", label: "₹12.0 Cr" },
  { department: "Others", amount: 9.0, percentage: 8, color: "bg-purple-500", label: "₹9.0 Cr" }
];

// 3. Document Workflow Status (Funnel/Progress View)
const invoiceWorkflowStatus = [
  { stage: "Received/Scanned", count: 180, percentage: 100, color: "bg-gray-400" },
  { stage: "PO Matched", count: 165, percentage: 92, color: "bg-indigo-500" },
  { stage: "HOD Approved", count: 130, percentage: 72, color: "bg-amber-500" },
  { stage: "Awaiting Payment Run", count: 45, percentage: 25, color: "bg-red-500" }, 
];

// 4. Critical Compliance/Contract Alerts
const complianceAlerts = [
  { type: "Regulatory", name: "MRTS Safety Circular 05/2025", status: "Action Required", urgency: "High", icon: Zap },
  { type: "Vendor Contract", name: "Rolling Stock Maint. Contract", status: "Expiring in 60 Days", urgency: "Medium", icon: Calendar },
  { type: "Legal Opinion", name: "Land Acquisition Dispute Update", status: "Awaiting CFO Review", urgency: "High", icon: FileText },
  { type: "Audit Finding", name: "Internal Audit Rejection Rate Q3", status: "Pending Fix (Engineering)", urgency: "Medium", icon: CheckCircle },
];

// DATA FOR LINE CHART (Monthly Revenue Trend)
const revenueTrendData = [
    { month: "Aug", revenue: 155, target: 140 },
    { month: "Sep", revenue: 162, target: 145 },
    { month: "Oct", revenue: 148, target: 150 },
    { month: "Nov", revenue: 175, target: 155 },
    { month: "Dec", revenue: 180, target: 160 },
];

// DATA FOR DONUT CHART (Unpaid Invoices by Age)
const invoiceAgingData = [
    { age: "0-30 Days", count: 75, color: "bg-green-500" },
    { age: "31-60 Days", count: 35, color: "bg-yellow-500" },
    { age: "61-90 Days", count: 15, color: "bg-orange-500" },
    { age: "> 90 Days (Critical)", count: 5, color: "bg-red-500" },
];

// Function to calculate total for donut chart (for percentages)
const totalUnpaid = invoiceAgingData.reduce((sum, item) => sum + item.count, 0);

const FinanceAnalytics = () => {

    // --- LINE CHART LOGIC ---
    // Define bounds for scaling the Y-axis
    const MIN_REVENUE = 140; 
    const MAX_REVENUE = 185; 
    const RANGE = MAX_REVENUE - MIN_REVENUE;

    // Y-axis labels generation
    const Y_AXIS_LABELS = [
        { value: MAX_REVENUE, label: `${MAX_REVENUE} Cr` },
        { value: MIN_REVENUE + (RANGE * 0.75), label: `${(MIN_REVENUE + (RANGE * 0.75)).toFixed(0)} Cr` },
        { value: MIN_REVENUE + (RANGE * 0.50), label: `${(MIN_REVENUE + (RANGE * 0.50)).toFixed(0)} Cr` },
        { value: MIN_REVENUE + (RANGE * 0.25), label: `${(MIN_REVENUE + (RANGE * 0.25)).toFixed(0)} Cr` },
        { value: MIN_REVENUE, label: `${MIN_REVENUE} Cr` },
    ];

    // Function to generate SVG path and point coordinates
    const getRevenueChartPath = (data) => {
        if (data.length === 0) return { path: "", points: [] };
        
        let path = "";
        const points = data.map((d, index) => {
            const x = (index / (data.length - 1)) * 100;
            // Scale Y position: 90% vertical range + 5% padding at top/bottom
            const yPercent = ((d.revenue - MIN_REVENUE) / RANGE) * 90 + 5; 
            const y = 100 - yPercent; // Invert for SVG (0=top)
            
            return { x, y, revenue: d.revenue };
        });

        points.forEach((p, index) => {
            if (index === 0) {
                path += `M ${p.x} ${p.y}`;
            } else {
                path += `L ${p.x} ${p.y}`;
            }
        });

        return { path, points };
    };

    const { path: revenueSvgPath, points: revenueChartPoints } = getRevenueChartPath(revenueTrendData);

    // --- END LINE CHART LOGIC ---


    return (
        <Layout>
            <div className="space-y-6">
                <div className="flex items-center justify-between border-b pb-4">
                    <div>
                        <h1 className="text-3xl font-extrabold text-primary flex items-center gap-2">
                            <DollarSign className="h-8 w-8" /> Finance & Accounts Dashboard
                        </h1>
                        <p className="text-muted-foreground mt-2">
                            Real-time insights on financial health, invoice processing, and compliance for KMRL.
                        </p>
                    </div>
                    <div className="flex gap-2">
            
                    </div>
                </div>

                {/* --- 1. Key Performance Indicators (KPIs) --- */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {financeMetrics.map((metric) => (
                        <Card key={metric.title} className="hover:shadow-lg transition-shadow duration-300 border-t-4 border-primary/70">
                            <CardContent className="p-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-sm font-medium text-muted-foreground">{metric.title}</p>
                                        <p className="text-3xl font-extrabold text-foreground mt-1">{metric.value}</p>
                                        <p className="text-xs text-muted-foreground mt-2">{metric.description}</p>
                                    </div>
                                    <div className="flex flex-col items-end gap-2">
                                        <metric.icon className="h-10 w-10 text-primary opacity-80" />
                                        <Badge variant="secondary" className={`${metric.trend === 'up' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'} font-semibold`}>
                                            <TrendingUp className="mr-1 h-3 w-3" />
                                            {metric.change}
                                        </Badge>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {/* --- 2. CHARTS ROW: Revenue Trend (Line Chart) and Invoice Aging (Donut Chart) --- */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    
                    {/* CHART 1: Monthly Revenue Trend (Line Chart with SVG) */}
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <LineChart className="h-5 w-5 text-primary" /> Monthly Revenue Trend (₹ in Cr)
                            </CardTitle>
                            <CardDescription>Comparison of operating revenue against monthly targets.</CardDescription>
                        </CardHeader>
                        <CardContent className="h-72 flex p-4 pb-0">
                            
                            {/* Y-Axis Labels and Grid */}
                            <div className="flex flex-col justify-between items-end text-xs text-muted-foreground pr-2 w-12 h-full relative py-2">
                                {Y_AXIS_LABELS.map((item, index) => (
                                    <div key={item.label} className="flex items-center w-full relative">
                                        <span className="font-semibold whitespace-nowrap">{item.label}</span>
                                    </div>
                                ))}
                            </div>

                            {/* Chart Area with Line and Dots (SVG) */}
                            <div className="relative flex-grow h-full border-l border-b border-gray-200">
                                <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
                                    
                                    {/* Horizontal Grid Lines */}
                                    {Y_AXIS_LABELS.slice(0, Y_AXIS_LABELS.length - 1).map((item, index) => {
                                        const yPercent = ((item.value - MIN_REVENUE) / RANGE) * 90 + 5;
                                        const svgY = 100 - yPercent;
                                        return (
                                            <line 
                                                key={`grid-${index}`} 
                                                x1="0" 
                                                y1={svgY} 
                                                x2="100" 
                                                y2={svgY} 
                                                stroke="#e5e7eb" 
                                                strokeDasharray="1,2"
                                            />
                                        );
                                    })}

                                    {/* The Connecting Line */}
                                    <path 
                                        d={revenueSvgPath} 
                                        fill="none" 
                                        stroke="hsl(var(--primary))" 
                                        strokeWidth="1.5"
                                    />

                                    {/* Data Points (Dots) and Value Labels */}
                                    {revenueChartPoints.map((p, index) => (
                                        <g key={index}>
                                            {/* Data Point Dot */}
                                            <circle 
                                                cx={p.x} 
                                                cy={p.y} 
                                                r="1.5" 
                                                fill="hsl(var(--primary))" 
                                                stroke="white" 
                                                strokeWidth="0.5"
                                            />
                                            {/* Value Label */}
                                            <text 
                                                x={p.x} 
                                                y={p.y - 3} 
                                                fontSize="4" 
                                                textAnchor="middle" 
                                                fill="hsl(var(--foreground))"
                                                className="font-bold"
                                            >
                                                {p.revenue}
                                            </text>
                                        </g>
                                    ))}
                                </svg>
                            </div>
                        </CardContent>

                        {/* X-Axis Labels (Below the Chart Area) */}
                        <div className="flex justify-between text-xs text-muted-foreground pt-1 px-4 ml-12 pb-6">
                            {revenueTrendData.map(d => (
                                <span key={d.month} className="font-semibold">{d.month}</span>
                            ))}
                        </div>
                    </Card>

                    {/* CHART 2: Unpaid Invoices by Age (Donut Chart) */}
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <PieChart className="h-5 w-5" /> Unpaid Invoices by Age
                            </CardTitle>
                            <CardDescription>Categorization of outstanding invoices by aging buckets (Total: {totalUnpaid} invoices).</CardDescription>
                        </CardHeader>
                        <CardContent className="flex h-72 items-center justify-between p-6">
                            {/* Mock Donut Chart Placeholder */}
                            <div className="w-1/2 flex items-center justify-center relative">
                                <div className="w-40 h-40 rounded-full bg-gray-100 flex items-center justify-center text-center font-bold text-lg text-primary" style={{backgroundImage: 'conic-gradient(var(--color-green-500) 0% 48%, var(--color-yellow-500) 48% 70%, var(--color-orange-500) 70% 86%, var(--color-red-500) 86% 100%)', boxShadow: '0 0 0 10px white inset'}}>
                                    <div className="w-20 h-20 rounded-full bg-card flex items-center justify-center text-primary">
                                        {totalUnpaid}
                                        <div className="text-xs font-normal absolute mt-6 text-muted-foreground">Invoices</div>
                                    </div>
                                </div>
                            </div>
                            {/* Legend */}
                            <div className="w-1/2 space-y-3">
                                {invoiceAgingData.map((item) => (
                                    <div key={item.age} className="flex justify-between items-center p-1 rounded-sm">
                                        <div className="flex items-center gap-2">
                                            <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                                            <span className="text-sm">{item.age}</span>
                                        </div>
                                        <span className="text-sm font-semibold">{item.count} ({((item.count / totalUnpaid) * 100).toFixed(0)}%)</span>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>
                
                {/* --- 3. Expenditure, Funnel, and Compliance Alerts --- */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    {/* Expenditure by Department (Bar Chart) */}
                    <Card className="lg:col-span-2"> 
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <BarChart3 className="h-5 w-5" /> Monthly Expenditure by Department
                            </CardTitle>
                            <CardDescription>Major expenditure distribution for the current month (in Crores INR).</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {expenditureData.map((item) => (
                                    <div key={item.department} className="space-y-1">
                                        <div className="flex justify-between items-center">
                                            <div className="flex items-center gap-2">
                                                <span className="font-semibold">{item.department}</span>
                                            </div>
                                            <span className="text-sm font-bold text-foreground">{item.label}</span>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <div className={`h-2 rounded-full ${item.color}`} style={{ width: `${item.percentage}%` }}></div>
                                            <span className="text-xs text-muted-foreground">{item.percentage}%</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Invoice Workflow Status (Funnel) */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Invoice Approval Funnel</CardTitle>
                            <CardDescription>Current status of all outstanding invoices in the system.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {invoiceWorkflowStatus.map((item) => (
                                    <div key={item.stage} className="space-y-1">
                                        <div className="flex justify-between items-center">
                                            <span className="font-medium text-sm">{item.stage}</span>
                                            <Badge variant="secondary" className={`${item.stage === 'Awaiting Payment Run' ? 'bg-red-100 text-red-700' : 'bg-primary/10 text-primary'} font-semibold`}>
                                                {item.count} Invoices
                                            </Badge>
                                        </div>
                                        <Progress value={item.percentage} className={`h-3 ${item.color}`} />
                                        <p className="text-xs text-muted-foreground text-right">{item.percentage}% Retention</p>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>


                {/* --- 4. Compliance and High-Risk Alerts --- */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-red-600">
                            <Zap className="h-5 w-5" /> Critical Financial & Compliance Alerts
                        </CardTitle>
                        <CardDescription>Immediate action items from regulatory documents, contracts, and internal audits.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {complianceAlerts.map((alert, index) => (
                                <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-red-50/50 transition-colors">
                                    <div className="flex items-center gap-3">
                                        <alert.icon className={`h-5 w-5 ${alert.urgency === 'High' ? 'text-red-600' : 'text-amber-500'}`} />
                                        <div>
                                            <p className="font-medium">{alert.name}</p>
                                            <p className="text-sm text-muted-foreground">
                                                <Badge variant="outline" className="mr-2">{alert.type}</Badge>
                                                {alert.status}
                                            </p>
                                        </div>
                                    </div>
                                    <Badge className={`${alert.urgency === 'High' ? 'bg-red-600 hover:bg-red-700' : 'bg-amber-500 hover:bg-amber-600'} text-white font-semibold`}>
                                        Urgency: {alert.urgency}
                                    </Badge>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                {/* --- 5. Simplified Efficiency Summary --- */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                    <Card>
                        <CardHeader>
                            <CardTitle>Upcoming Payments</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-center">
                                <p className="text-3xl font-bold text-primary">154</p>
                                <p className="text-sm text-muted-foreground">Payment runs scheduled this week</p>
                                <Badge variant="secondary" className="mt-2 text-blue-600">
                                Total Value: ₹ 7.8 Cr
                                </Badge>
                            </div>
                        </CardContent>
                    </Card>

                    {/* UPDATED CARD: Total Unsettled Commitment (PO Value) */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Total Unsettled Commitment</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-center">
                                <p className="text-3xl font-bold text-green-600">₹ 21.5 Cr</p>
                                <p className="text-sm text-muted-foreground">Value of active POs and Contracts (Next 3 Months)</p>
                                <Progress value={55} className="mt-3 h-2 bg-green-600" />
                                <Badge variant="secondary" className="mt-2 text-blue-600">
                                    55% of quarterly budget reserved
                                </Badge>
                            </div>
                        </CardContent>
                    </Card>
                    
                    {/* UPDATED CARD: Daily Paper-to-Digital Clearance (Digitization Rate) */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Daily Paper-to-Digital Clearance</CardTitle> 
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center justify-around space-x-6 h-full pt-4">
                                <div className="text-center">
                                    <p className="text-3xl font-bold text-primary">1,120</p>
                                    <p className="text-sm text-muted-foreground">Documents Scanned Today</p>
                                    <Badge variant="secondary" className="mt-2 text-green-600">
                                        +120 vs Yesterday
                                    </Badge>
                                </div>
                                <div className="text-center">
                                    <p className="text-3xl font-bold text-green-600">98%</p>
                                    <p className="text-sm text-muted-foreground">Daily Target Achieved</p>
                                    <Progress value={98} className="mt-2 h-2" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    
                </div>
            </div>
        </Layout>
    );
};

export default FinanceAnalytics;