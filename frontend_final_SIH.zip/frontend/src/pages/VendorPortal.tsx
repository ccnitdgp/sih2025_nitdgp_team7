// import React, { useState, useEffect, useRef } from 'react';
// import { useParams } from 'react-router-dom'; // To get Token from URL
// import { Send, FileText, CheckCircle, Clock } from 'lucide-react';
// import { toast } from 'sonner';

// const VendorPortal = () => {
//   const { token } = useParams(); // URL: /proposal/:token
//   const [data, setData] = useState<any>(null);
//   const [loading, setLoading] = useState(true);
  
//   // Pitch Form State
//   const [quote, setQuote] = useState("");
//   const [remarks, setRemarks] = useState("");

//   // Chat State
//   const [msgInput, setMsgInput] = useState("");
//   const bottomRef = useRef<HTMLDivElement>(null);

//   // 1. POLLING FETCH
//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const res = await fetch(`http://localhost:5001/api/negotiation/details?token=${token}`);
//         if (res.ok) {
//           const json = await res.json();
//           setData(json);
//         }
//       } catch (err) {
//         console.error(err);
//       } finally {
//         setLoading(false);
//       }
//     };
    
//     fetchData();
//     const interval = setInterval(fetchData, 3000); // 3s polling
//     return () => clearInterval(interval);
//   }, [token]);

//   // Auto Scroll Chat
//   useEffect(() => {
//     bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
//   }, [data?.messages]);


//   // 2. SUBMIT PITCH
//   const handleSubmitPitch = async () => {
//     try {
//       await fetch('http://localhost:5001/api/negotiation/submit-pitch', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ token, quote, remarks })
//       });
//       toast.success("Proposal Submitted!");
//     } catch (err) {
//       toast.error("Error submitting");
//     }
//   };

//   // 3. SEND MESSAGE
//   const handleSendMessage = async () => {
//     if (!msgInput.trim()) return;
//     try {
//       await fetch('http://localhost:5001/api/negotiation/send-message', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ token, sender: "VENDOR", text: msgInput })
//       });
//       setMsgInput("");
//     } catch (err) {
//       toast.error("Error sending");
//     }
//   };


//   if (loading) return <div className="p-10 text-center">Loading Project...</div>;
//   if (!data) return <div className="p-10 text-center text-red-500">Invalid Link</div>;

//   // --- VIEW 1: PITCH FORM ---
//   if (data.status === 'WAITING_FOR_PITCH') {
//     return (
//       <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
//         <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 border border-gray-200">
//           <div className="text-center mb-6">
//             <h1 className="text-2xl font-bold text-gray-900">Project Invitation</h1>
//             <p className="text-gray-500 mt-2">KMRL requests a proposal</p>
//           </div>
          
//           <div className="bg-blue-50 p-4 rounded-lg mb-6 text-sm">
//             <div className="flex justify-between mb-2">
//               <span className="text-blue-600 font-medium">Project:</span>
//               <span className="font-bold">{data.project_name}</span>
//             </div>
//             <div className="flex justify-between">
//               <span className="text-blue-600 font-medium">Budget Cap:</span>
//               <span className="font-bold">₹{data.budget}</span>
//             </div>
//           </div>

//           <div className="space-y-4">
//             <div>
//               <label className="block text-sm font-medium mb-1">Your Quote (₹)</label>
//               <input type="number" className="w-full border p-2 rounded" value={quote} onChange={e => setQuote(e.target.value)} />
//             </div>
//             <div>
//               <label className="block text-sm font-medium mb-1">Remarks / Timeline</label>
//               <textarea className="w-full border p-2 rounded h-24" value={remarks} onChange={e => setRemarks(e.target.value)} />
//             </div>
//             <button onClick={handleSubmitPitch} className="w-full bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700">
//               Submit Proposal
//             </button>
//           </div>
//         </div>
//       </div>
//     );
//   }

//   // --- VIEW 2: CHAT INTERFACE ---
//   return (
//     <div className="min-h-screen bg-white flex flex-col max-w-2xl mx-auto shadow-xl border-x">
//       {/* Header */}
//       <div className="p-4 border-b bg-gray-50 sticky top-0 z-10">
//         <div className="flex justify-between items-center">
//            <h2 className="font-bold text-lg">{data.project_name}</h2>
//            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold">Active</span>
//         </div>
//         <div className="text-sm text-gray-500 mt-1">
//            Your Quote: <span className="font-bold text-black">₹{data.vendor_pitch.quote}</span>
//         </div>
//       </div>

//       {/* Messages */}
//       <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50/30">
//         {data.messages.map((msg: any, i: number) => (
//           <div key={i} className={`flex ${msg.sender === 'VENDOR' ? 'justify-end' : 'justify-start'}`}>
//             <div className={`max-w-[80%] rounded-2xl px-4 py-2 shadow-sm ${msg.sender === 'VENDOR' ? 'bg-blue-600 text-white' : 'bg-white border'}`}>
//               <p className="text-sm">{msg.text}</p>
//               <span className={`text-[10px] block mt-1 opacity-70 ${msg.sender === 'VENDOR' ? 'text-blue-100' : 'text-gray-400'}`}>
//                 {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
//               </span>
//             </div>
//           </div>
//         ))}
//         <div ref={bottomRef} />
//       </div>

//       {/* Input */}
//       <div className="p-4 border-t bg-white flex gap-2">
//         <input 
//           value={msgInput} onChange={e => setMsgInput(e.target.value)} 
//           onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
//           className="flex-1 border p-2 rounded-lg" placeholder="Type a message..." 
//         />
//         <button onClick={handleSendMessage} className="bg-blue-600 text-white p-2 rounded-lg">
//           <Send size={20} />
//         </button>
//       </div>
//     </div>
//   );
// };

// export default VendorPortal;

import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { Send, FileText, CheckCircle, Clock, MessageSquare, DollarSign, Calendar } from 'lucide-react';
import { toast } from 'sonner';

// Type definitions for clarity
interface NegotiationData {
  token: string;
  project_name: string;
  budget: string;
  deadline: string;
  status: 'WAITING_FOR_PITCH' | 'NEGOTIATION_ACTIVE' | 'APPROVED';
  messages: { sender: 'MANAGER' | 'VENDOR'; text: string; timestamp: string }[];
  vendor_pitch?: { quote: string; remarks: string; submitted_at: string };
}

const VendorPortal = () => {
  const { token } = useParams();
  const [data, setData] = useState<NegotiationData | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Pitch Form State
  const [quote, setQuote] = useState("");
  const [remarks, setRemarks] = useState("");

  // Chat State
  const [msgInput, setMsgInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  // Status map for UI rendering
  const statusMap = {
    'WAITING_FOR_PITCH': { label: 'Awaiting Pitch', icon: Clock, color: 'text-yellow-600 bg-yellow-100' },
    'NEGOTIATION_ACTIVE': { label: 'Negotiation Active', icon: MessageSquare, color: 'text-blue-600 bg-blue-100' },
    'APPROVED': { label: 'Contract Approved', icon: CheckCircle, color: 'text-green-600 bg-green-100' },
  };

  // 1. POLLING FETCH
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`http://localhost:5001/api/negotiation/details?token=${token}`);
        if (res.ok) {
          const json: NegotiationData = await res.json();
          setData(json);
        } else {
          // Handle 404/Invalid token
          setData(null);
        }
      } catch (err) {
        console.error("Fetch error:", err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
    const interval = setInterval(fetchData, 3000); // 3s polling
    return () => clearInterval(interval);
  }, [token]);

  // Auto Scroll Chat
  useEffect(() => {
    if (data?.messages.length) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [data?.messages]);


  // 2. SUBMIT PITCH
  const handleSubmitPitch = async () => {
    if (!quote || !remarks) {
      toast.error("Quote and Remarks/Timeline are required.");
      return;
    }
    
    setLoading(true); // Disable button during submission
    try {
      const res = await fetch('http://localhost:5001/api/negotiation/submit-pitch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, quote, remarks })
      });
      
      if (res.ok) {
        // Successful submission, polling will pick up the new data
        toast.success("Proposal Submitted! Negotiation is now active.");
      } else {
        toast.error("Failed to submit proposal.");
      }
    } catch (err) {
      toast.error("Network error during submission.");
    } finally {
      setLoading(false);
    }
  };

  // 3. SEND MESSAGE
  const handleSendMessage = async () => {
    if (!msgInput.trim()) return;
    
    const tempMsg = msgInput;
    setMsgInput(""); // Clear input immediately for better UX
    
    try {
      await fetch('http://localhost:5001/api/negotiation/send-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, sender: "VENDOR", text: tempMsg })
      });
      // Polling will update the chat list
    } catch (err) {
      setMsgInput(tempMsg); // Restore if error
      toast.error("Error sending message.");
    }
  };


  if (loading) return <div className="min-h-screen p-10 text-center text-xl text-gray-700 bg-gray-50 flex items-center justify-center">Loading Project Details...</div>;
  if (!data) return <div className="min-h-screen p-10 text-center text-red-600 bg-gray-50 flex items-center justify-center">⚠️ Invalid or Expired Proposal Link</div>;

  const currentStatus = data.status ? statusMap[data.status] : statusMap['WAITING_FOR_PITCH'];
  const StatusIcon = currentStatus.icon;

  // --- COMPONENT STRUCTURE ---
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-white rounded-xl shadow-2xl overflow-hidden border border-gray-200">
        
        {/* TOP HEADER / STATUS BAR */}
        <div className="p-5 border-b border-gray-100 bg-white sticky top-0 z-10">
          <h1 className="text-3xl font-extrabold text-gray-900">{data.project_name}</h1>
          <div className="flex items-center mt-2 space-x-2">
            <StatusIcon className={`w-5 h-5 ${currentStatus.color}`} />
            <span className={`text-sm font-semibold ${currentStatus.color}`}>{currentStatus.label}</span>
          </div>
        </div>

        {/* CONTENT AREA */}
        <div className="flex flex-col lg:flex-row h-full">
          
          {/* LEFT: DETAILS PANEL */}
          <div className="w-full lg:w-1/3 p-5 border-b lg:border-r lg:border-b-0 bg-gray-50">
            <h3 className="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Project Specifications</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-white rounded-lg shadow-sm">
                <div className="flex items-center space-x-2">
                  <DollarSign className="w-5 h-5 text-indigo-500" />
                  <span className="text-sm font-medium text-gray-600">Budget Cap</span>
                </div>
                <span className="text-base font-extrabold text-indigo-600">₹{data.budget}</span>
              </div>

              <div className="flex items-center justify-between p-3 bg-white rounded-lg shadow-sm">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5 text-red-500" />
                  <span className="text-sm font-medium text-gray-600">Deadline</span>
                </div>
                <span className="text-base font-extrabold text-red-600">{new Date(data.deadline).toLocaleDateString()}</span>
              </div>
            </div>
            
            {/* VENDOR PITCH SUMMARY (Only after submission) */}
            {data.vendor_pitch && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h3 className="text-lg font-bold text-gray-700 mb-3">Your Proposal</h3>
                <div className="bg-indigo-50 p-4 rounded-lg space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium text-indigo-700">Your Quote:</span>
                    <span className="font-bold text-indigo-800">₹{data.vendor_pitch.quote}</span>
                  </div>
                  <div className="text-xs text-gray-600">
                    <span className="font-medium">Remarks:</span> {data.vendor_pitch.remarks}
                  </div>
                  <div className="text-xs text-gray-500 pt-2 border-t border-indigo-200">
                    Submitted: {new Date(data.vendor_pitch.submitted_at).toLocaleDateString()}
                  </div>
                </div>
              </div>
            )}
            
          </div>

          {/* RIGHT: MAIN INTERFACE (FORM OR CHAT) */}
          <div className="w-full lg:w-2/3 p-5">
            {data.status === 'WAITING_FOR_PITCH' ? (
              // --- VIEW 1: PITCH FORM (Styled) ---
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-800">Submit Your Pitch</h3>
                <p className="text-gray-600">Please provide your competitive quote and detailed remarks/timeline to KMRL.</p>
                
                <div className="space-y-4 bg-gray-50 p-4 rounded-lg border">
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Your Quote (₹) <span className="text-red-500">*</span></label>
                    <input 
                      type="number" 
                      className="w-full border-gray-300 p-3 rounded-lg focus:ring-indigo-500 focus:border-indigo-500" 
                      placeholder="e.g., 850000"
                      value={quote} 
                      onChange={e => setQuote(e.target.value)} 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Remarks / Proposed Timeline <span className="text-red-500">*</span></label>
                    <textarea 
                      className="w-full border-gray-300 p-3 rounded-lg h-32 focus:ring-indigo-500 focus:border-indigo-500" 
                      placeholder="e.g., We can complete this project within 12 weeks."
                      value={remarks} 
                      onChange={e => setRemarks(e.target.value)} 
                    />
                  </div>
                  <button 
                    onClick={handleSubmitPitch} 
                    disabled={loading}
                    className="w-full flex items-center justify-center space-x-2 bg-indigo-600 text-white py-3 rounded-lg font-bold hover:bg-indigo-700 transition duration-150 disabled:bg-indigo-400"
                  >
                    <FileText className="w-5 h-5" />
                    <span>{loading ? "Submitting..." : "Submit Official Proposal"}</span>
                  </button>
                </div>
              </div>
            ) : (
              // --- VIEW 2: CHAT INTERFACE (Enhanced) ---
              <div className="flex flex-col h-[70vh]">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Negotiation Channel</h3>
                
                {/* Messages Container */}
                <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50 rounded-lg border mb-4">
                  {data.messages.map((msg: NegotiationData['messages'][0], i: number) => (
                    <div key={i} className={`flex ${msg.sender === 'VENDOR' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[75%] rounded-t-xl px-4 py-3 shadow-md ${msg.sender === 'VENDOR' ? 'bg-indigo-600 text-white rounded-bl-xl' : 'bg-white border rounded-br-xl'}`}>
                        <p className="text-sm font-medium">{msg.text}</p>
                        <span className={`text-[10px] block mt-1 pt-1 opacity-80 ${msg.sender === 'VENDOR' ? 'text-indigo-100' : 'text-gray-500'}`}>
                          {new Date(msg.timestamp).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ))}
                  <div ref={bottomRef} />
                </div>

                {/* Input */}
                <div className="flex gap-3">
                  <input 
                    value={msgInput} 
                    onChange={e => setMsgInput(e.target.value)} 
                    onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1 border border-gray-300 p-3 rounded-lg focus:ring-indigo-500 focus:border-indigo-500" 
                    placeholder="Send a message to the Manager..." 
                    disabled={data.status === 'APPROVED'}
                  />
                  <button 
                    onClick={handleSendMessage} 
                    className="bg-indigo-600 text-white p-3 rounded-lg hover:bg-indigo-700 transition duration-150 disabled:bg-gray-400"
                    disabled={!msgInput.trim() || data.status === 'APPROVED'}
                  >
                    <Send size={20} />
                  </button>
                </div>
                {data.status === 'APPROVED' && (
                  <p className="text-center text-green-600 mt-2 font-semibold">Contract has been approved. Messaging is now closed.</p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VendorPortal;