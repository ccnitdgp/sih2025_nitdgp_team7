import { Layout } from "@/components/Layout";
import { useEffect, useState, useCallback } from "react";
import API from "../utils/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import ShareNotificationModal from "../components/ui/shareNotificationModal";
import { FileText, Download, Eye, Share, Calendar, User, Filter, Search } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";


const formatBytes = (bytes = 0, decimals = 2) => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
};

const STAT_MAPPING = [
  { name: "Total Documents", color: "bg-blue-600", type: "calculated" },
  { name: "WhatsApp", route: "/messages/search", color: "bg-primary/90", type: "dynamic" },
  { name: "Email Threads", route: "/gmail/db/emails", color: "bg-red-500", type: "dynamic" },
  { name: "Drive Files", count: 35, color: "bg-green-500", type: "hardcoded" },
  { name: "Maximo Work Orders", route: "messages/maximo/count", color: "bg-orange-500", type: "dynamic" },
];

const FILTER_OPTIONS = [
  { name: "type", label: "Document Type", options: ["All", "PDF", "DOCX", "XLSX", "Image", "MAXIMO"] },
  { name: "date", label: "Date Range", options: ["All Time", "Today", "This Week", "This Month", "This Year"] }
];

const Documents = () => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDoc, setSelectedDoc] = useState(null);

  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    type: "all",
    date: "alltime"
  });


  const [stats, setStats] = useState(
    STAT_MAPPING.map((stat) => ({
      ...stat,
      count: stat.type === "hardcoded" ? stat.count : 0,
      loading: stat.type === "dynamic",
    }))
  );
  const [loadingDynamic, setLoadingDynamic] = useState(true);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareTargetDoc, setShareTargetDoc] = useState(null);

  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({ ...prev, [filterName]: value }));
  };



  const fetchDocumentCounts = useCallback(async () => {
    setLoadingDynamic(true);
    let totalSum = 0;
    const updatedStats = [];
    const dynamicPromises = [];
    for (const stat of STAT_MAPPING) {
      if (stat.type === "dynamic") {
        dynamicPromises.push(
          API.get(stat.route)
            .then((res) => {
              let count = 0;
              if (stat.name === "Maximo Work Orders") {
                count = typeof res.data === 'number' ? res.data : 0;
              } else {
                count = Array.isArray(res.data) ? res.data.length : 0;
              }
              return { ...stat, count: count, loading: false };
            })
            .catch((error) => {
              console.error(
                `Failed to fetch count for ${stat.name} from ${stat.route}:`,
                error
              );
              return { ...stat, count: 0, loading: false };
            })
        );
      } else {
        updatedStats.push(stat);
        if (stat.type === "hardcoded") {
          totalSum += stat.count;
        }
      }
    }
    const dynamicResults = await Promise.all(dynamicPromises);
    let dynamicSum = 0;
    dynamicResults.forEach((result) => {
      updatedStats.push(result);
      dynamicSum += result.count;
    });
    totalSum += dynamicSum;
    const finalStats = updatedStats.map((stat) => {
      if (stat.type === "calculated") {
        return { ...stat, count: totalSum, loading: false };
      }
      return stat;
    });
    const sortedStats = STAT_MAPPING.map(
      (originalStat) =>
        finalStats.find((finalStat) => finalStat.name === originalStat.name) ||
        originalStat
    );
    setStats(sortedStats);
    setLoadingDynamic(false);
  }, []);

  useEffect(() => {
    fetchDocumentCounts();
  }, [fetchDocumentCounts]);

  const getOverallPriority = useCallback((actions) => {
    if (!Array.isArray(actions) || actions.length === 0) return "Normal";

    const priorities = actions
      .map((a) => a.priority?.toLowerCase())
      .filter((p) => p);

    if (priorities.includes("high") || priorities.includes("critical")) return "High";
    if (priorities.includes("medium")) return "Medium";
    if (priorities.includes("low")) return "Low";

    return "Normal";
  }, []);

  // 1. Refined fetchDocuments to include Maximo date filtering
  const fetchDocuments = useCallback(
    async (query = "", currentFilters = { type: 'all', date: 'alltime' }) => {
      setLoading(true);

      const { type, date } = currentFilters;

      // Parameters for general search
      const params = {
        q: query,
        // Only include type/dateRange if not 'all' or 'alltime'
        ...(type !== 'all' && { type: type }),
        ...(date !== 'alltime' && { dateRange: date }),
      };

      try {
        // 1. Fetch general documents
        const generalResponse = await API.get("/messages/search", { params });
        let allDocuments = generalResponse.data;

        // 2. Fetch Maximo documents (with date filter)
        let maximoDocuments = [];
        if (type === 'maximo' || type === 'all') {
          try {
            // FIX: Pass date filter to Maximo endpoint
            const maximoParams = {
              ...(date !== 'alltime' && { dateRange: date }),
            };
            
            const maximoResponse = await API.get("messages/maximo/documents", { params: maximoParams });
            maximoDocuments = maximoResponse.data;

            // Local search/filter for Maximo documents (still needed)
            const lowerQuery = query.toLowerCase();
            maximoDocuments = maximoDocuments.filter(doc =>
              doc.title?.toLowerCase().includes(lowerQuery) ||
              doc.summary?.toLowerCase().includes(lowerQuery)
            );
          } catch (maximoError) {
            console.error("Failed to fetch Maximo documents:", maximoError);
          }
        }

        allDocuments = [...allDocuments, ...maximoDocuments];


        const transformedDocs = allDocuments.map((doc) => {
          const isGmail = doc.source === "gmail";
          const isMaximo = doc.source === "MAXIMO";

          let rawActions = [];
          let tags = [];
          const flaggedDepartments = Array.isArray(doc.flaggedDepartments)
            ? doc.flaggedDepartments
            : [];

          if (isGmail) {
            const analysis = doc.analysis || {};
            rawActions = analysis.raw.data.actions_required || [];
            tags = analysis.document_category ? [analysis.document_category] : [];
          } else if (isMaximo) {
            rawActions = doc.raw_analysis?.data?.actions_required || [];
            tags = doc.raw_analysis?.data?.tags || [];
            tags = [...new Set(tags.concat(flaggedDepartments))];
          } else {
            const analysisRaw = doc.analysis?.raw.data;
            rawActions = analysisRaw?.actions_required || [];
            tags = tags.concat(flaggedDepartments);
            tags = [...new Set(tags)];
          }

          const overallPriority = getOverallPriority(rawActions);
          const finalDepartments = flaggedDepartments;

          const firstAction = rawActions[0] || {};
          const firstActionText =
            firstAction.action || "No specific action required.";
          const firstActionDeadline = firstAction.deadline || "N/A";

          let name = "Untitled Document";
          let uploadedBy = "Unknown User";
          let uploadedDate = doc.date || new Date().toISOString();
          let status = doc.is_relevant || doc.analysis?.isRelevant || doc.analysis?.is_relevant
            ? "Relevant"
            : "Pending Analysis";
          let summary = doc.summary || "No summary available.";

          if (isGmail) {
            name = doc.subject || "Untitled Email";
            uploadedBy = doc.from || "Unknown Sender";
          } else if (isMaximo) {
            name = doc.title || `Maximo Document: ${doc.source_id}`;
            uploadedBy = `Maximo WO: ${doc.related_wo_id || 'N/A'}`;
            uploadedDate = doc.createdAt?.$date?.$numberLong ? new Date(parseInt(doc.createdAt.$date.$numberLong)).toISOString() : new Date().toISOString();
            console.log(uploadedBy);
            status = doc.raw_analysis?.data?.status || status;
            summary = doc.summary || "No summary available.";
          } else { // Default/Drive/WhatsApp
            name = doc.fileName;
            uploadedBy = doc.userId?.name || "Unknown User";
          }

          return {
            id: isMaximo ? doc.source_id : doc._id,
            name: name,
            size: isGmail || isMaximo ? "" : formatBytes(doc.fileSize),
            uploadedBy: uploadedBy,
            uploadedDate: uploadedDate,
            filePath: isGmail || isMaximo ? "" : doc.path,
            status: status,
            summary: summary,

            allActions: rawActions,
            departments: finalDepartments,
            priority: overallPriority,
            action: firstActionText,
            deadline: firstActionDeadline,

            tags: tags,
            source: doc.source,
          };
        });

        setDocuments(transformedDocs);
      } catch (error) {
        console.error("Failed to fetch documents:", error);
      } finally {
        setLoading(false);
      }
    },
    [getOverallPriority] // keep only stable deps
  );

  // 2. FIX: Use useEffect to trigger fetch immediately when filters change
  useEffect(() => {
    // This runs on initial load AND whenever filters state changes, 
    // ensuring the list updates when the user selects a date range.
    fetchDocuments(searchQuery, filters);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchDocumentCounts, filters, fetchDocuments]); // Added fetchDocuments to deps

  const handleSearch = () => {
    // This runs when the user explicitly clicks the search button or hits Enter
    fetchDocuments(searchQuery, filters);
  };


  const handleDownload = (doc) => {
    // Download logic remains the same...
    if (doc.source === "gmail") {
      API.get(`/messages/gmail/download/${doc.id}/${doc.name}`, {
        responseType: "blob",
      }).then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", doc.name);
        document.body.appendChild(link);
        link.click();
        link.remove();
      });
    } else if (doc.source === "MAXIMO") {
      alert(`Maximo document download requested for ID: ${doc.id}. Backend download endpoint for Maximo is required.`);
    } else {
      API.get(`/messages/download/${doc.id}`, { responseType: "blob" }).then(
        (response) => {
          const url = window.URL.createObjectURL(new Blob([response.data]));
          const link = document.createElement("a");
          link.href = url;
          link.setAttribute("download", doc.name);
          document.body.appendChild(link);
          link.click();
          link.remove();
        }
      );
    }
  };

  const handleShareClick = (doc) => {
    setShareTargetDoc(doc);
    setIsShareModalOpen(true);
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold">Documents</h1>
            <p className="text-muted-foreground"> Manage and organize all your documents in one place </p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" disabled> <Filter className="h-4 w-4 mr-2" /> Filter </Button>
            <Button> <FileText className="h-4 w-4 mr-2" /> Add Document </Button>
          </div>
        </div>

        {/* Integrated Search and Filter Card */}
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex flex-col gap-4">
              <div className="flex gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search documents by name or summary..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { handleSearch(); } }}
                  />
                </div>
                <Button onClick={handleSearch} disabled={loading}>
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </Button>
              </div>
              
              {/* Filter Dropdowns */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {FILTER_OPTIONS.map((filter) => (
                  <div key={filter.name}>
                    <label className="text-sm font-medium mb-1 block text-muted-foreground">
                      {filter.label}
                    </label>
                    <Select
                      onValueChange={(value) => handleFilterChange(filter.name, value)}
                      defaultValue={filter.options[0].toLowerCase().replace(" ", "").replace("time", "time")}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {filter.options.map((option) => (
                          <SelectItem
                            key={option}
                            value={option.toLowerCase().replace(" ", "").replace("time", "time")}
                          >
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
        {/* End Integrated Search and Filter Card */}

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {stats.map((stat) => (
            <Card key={stat.name} className="shadow-soft hover:shadow-elevated transition-smooth cursor-pointer" >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  {stat.name === "Total Documents" ? (
                    <FileText className="h-6 w-6 text-blue-600 flex-shrink-0" />
                  ) : (<div className={`h-3 w-3 rounded-full ${stat.color} flex-shrink-0`} />)}

                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{stat.name}</p>
                    <p className="text-lg font-bold"> {stat.loading ? "..." : stat.count.toLocaleString()} </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle>Recent Documents</CardTitle>
            <CardDescription>
              Showing {documents.length} documents matching your search and filter criteria.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading && <p className="text-center">Loading documents...</p>}
            {!loading && documents.length === 0 && (<p className="text-center">No documents found matching your criteria.</p>)}
            <div className="space-y-4">
              {documents.map((doc) => (
                <div
                  key={doc.id}
                  className="flex items-start gap-4 p-4 border rounded-lg hover:shadow-sm"
                >
                  <div className="p-2 bg-primary/10 rounded-lg flex-shrink-0 mt-1">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0 space-y-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-medium truncate" title={doc.name}>
                        {doc.name}
                      </h3>
                      <Badge variant={doc.status === "Relevant" ? "default" : "secondary"}>{doc.status}</Badge>
                      <Badge variant={doc.priority === "High" ? "destructive" : doc.priority === "Medium" ? "secondary" : "outline"}>Priority: {doc.priority}</Badge>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1"><User className="h-3 w-3" />{doc.uploadedBy}</div>
                      <div className="flex items-center gap-1"><Calendar className="h-3 w-3" />{new Date(doc.uploadedDate).toLocaleDateString()}</div>
                      {doc.size && (<div className="text-xs">Size: {doc.size}</div>)}
                    </div>
                    <div className="p-3 bg-muted/50 rounded-md space-y-2">
                      <p className="font-semibold text-foreground"> Action Required ({doc.allActions.length || 0}): </p>
                      {doc.allActions.length > 0 ? (
                        <>
                          <p className="text-muted-foreground text-sm line-clamp-2"> {doc.allActions[0].action} </p>
                          <p className="text-xs text-muted-foreground mt-1"> <b>Deadline:</b> {doc.allActions[0].deadline || "N/A"}|{" "} <b>Assigned:</b> {doc.allActions[0].assigned_department || "N/A"} </p>
                          {doc.allActions.length > 1 && (
                            <Button variant="link" size="sm" className="h-auto p-0 text-xs mt-1" onClick={() => setSelectedDoc(doc)} > See all {doc.allActions.length} actions... </Button>
                          )}
                        </>
                      ) : (
                        <p className="text-muted-foreground text-sm"> No specific action required. </p>
                      )}
                    </div>
                    <div>
                      <p className="text-xs font-semibold mb-1"> Departments to Notify ({doc.departments.length}): </p>
                      <div className="flex items-center gap-2 flex-wrap">
                        {doc.departments.length > 0 ? (doc.departments.map((dept) => (<Badge key={dept} variant="secondary" className="bg-purple-100 text-purple-800" > {dept} </Badge>))
                        ) : (
                          <span className="text-xs text-muted-foreground"> None specified </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-center gap-2">
                    <Button variant="ghost" size="icon" title="Download" onClick={() => handleDownload(doc)} > <Download className="h-4 w-4" /> </Button>
                    <Button variant="ghost" size="icon" title="View Details" onClick={() => setSelectedDoc(doc)} > <Eye className="h-4 w-4" /> </Button>
                    <Button variant="ghost" size="icon" title="Share" onClick={() => handleShareClick(doc)}>
                      <Share className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!selectedDoc} onOpenChange={(isOpen) => !isOpen && setSelectedDoc(null)} >
        <DialogContent className="sm:max-w-[625px]">
          <DialogHeader>
            <DialogTitle> {selectedDoc?.allActions?.length > 0 ? "Detailed Action Plan" : "Document Summary"} </DialogTitle>
            <DialogDescription className="truncate">
              {selectedDoc?.name}
            </DialogDescription>
          </DialogHeader>

          {selectedDoc?.allActions?.length > 0 ? (
            <div className="space-y-4 max-h-[70vh] overflow-y-auto">
              <p className="text-sm font-semibold text-foreground border-b pb-2"> Summary: </p>
              <div className="py-2 prose prose-sm max-w-none text-muted-foreground"> <p>{selectedDoc.summary}</p> </div>
              <h3 className="text-lg font-bold border-t pt-4"> Required Actions ({selectedDoc.allActions.length}) </h3>
              {selectedDoc.allActions.map((action, index) => (
                <Card key={index} className="shadow-sm border-l-4 border-primary/50" >
                  <CardContent className="p-4 space-y-2">
                    <p className="text-sm font-bold text-foreground"> Action #{index + 1}:{action.action} </p>
                    <div className="flex flex-wrap gap-3 text-xs">
                      <Badge variant="secondary"> Assigned Dept: {action.assigned_department || "Unassigned"} </Badge>
                      <Badge variant={action.priority === "High" || action.priority === "Critical" ? "destructive" : action.priority === "Medium" ? "secondary" : "outline"} > Priority: {action.priority || "Normal"} </Badge>
                      <Badge variant="outline"> Deadline: {action.deadline || "N/A"} </Badge>
                    </div>
                    {action.notes && (
                      <p className="text-xs italic text-muted-foreground mt-2"> <span className="font-semibold">Notes:</span> {action.notes} </p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="py-4 prose prose-sm max-w-none text-muted-foreground">
              <p>{selectedDoc?.summary}</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
      {shareTargetDoc && (
        <ShareNotificationModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          document={shareTargetDoc}
        />
      )}
    </Layout>
  );
};

export default Documents;