import { Layout } from "@/components/Layout";
import { useEffect, useState } from "react";
import API from "../utils/api";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const [status, setStatus] = useState("loading");
  const [qr, setQr] = useState(null);
  const [messages, setMessages] = useState([]);
  const router = useNavigate();

  useEffect(() => {
    let isMounted = true;
    const fetchStatus = async () => {
      try {
        const res = await API.get("/whatsapp/status");
        if (!isMounted) return;

        if (res.data.status === "connected") {
          setStatus("connected");
          setQr(null);
        } else if (res.data.status === "qr") {
          setStatus("qr");
          setQr(res.data.qr);
        } else {
          setStatus("loading");
        }
      } catch (err) {
        if (isMounted) {
          console.error("Failed to fetch WhatsApp status:", err);
          if (err.response?.status === 401) {
            navigate("/login");
          }
        }
      }
    };

    const fetchMessages = async () => {
      try {
        const res = await API.get("/messages/search");
        setMessages(res.data);
      } catch (err) {
        console.error(err);
      }
    };

    fetchStatus();
    const interval = setInterval(() => {
      fetchStatus();
      fetchMessages();
    }, 5000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [router]);

  const handleDisconnect = async () => {
    try {
      await API.post("/whatsapp/disconnect");
      setStatus("loading");
      setQr(null);
    } catch (err) {
      console.error("Failed to disconnect WhatsApp:", err);
    }
  };

  const handleDownload = async (messageId, fileName, mimeType) => {
    try {
      const response = await API.get(`/messages/download/${messageId}`, {
        responseType: "blob",
      });
      const url = window.URL.createObjectURL(
        new Blob([response.data], { type: mimeType })
      );
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error(
        "Failed to download media:",
        err.response ? err.response.data : err.message
      );
      alert("Download failed. Check console for details.");
    }
  };

  return (
    <Layout>
      <div className="p-10">
        <h1 className="text-2xl mb-6">WhatsApp Connection</h1>

        {status === "connected" && (
          <div className="flex items-center gap-4 p-4 bg-green-100 text-green-800 rounded">
            Connected to WhatsApp
            <button
              onClick={handleDisconnect}
              className="px-3 py-1 border rounded bg-red-100 text-red-800 hover:bg-red-200"
            >
              Disconnect
            </button>
          </div>
        )}

        {status === "qr" && qr && (
          <div>
            <p className="mb-2">Scan this QR to connect:</p>
            <img
              src={qr}
              alt="QR Code"
              width={256}
              height={256}
              className="border"
            />
          </div>
        )}

        {status === "loading" && <p>⏳ Initializing WhatsApp client...</p>}

        <h2 className="text-xl mt-6 mb-2">Received Messages</h2>
        {messages.length > 0 ? (
          <ul className="list-disc pl-6">
            {messages.map((m) =>
              m.type === "text" ? (
                <li key={m._id} className="mb-2">
                  💬 <b>{m.from}</b>: {m.body}
                </li>
              ) : (
                <li key={m._id} className="mb-2">
                  📂 <b>{m.from}</b>: {m.fileName} ({m.mimeType})
                  <button
                    onClick={() =>
                      handleDownload(m._id, m.fileName, m.mimeType)
                    }
                    className="text-blue-500 underline ml-2 bg-transparent border-none p-0 cursor-pointer"
                  >
                    Download
                  </button>
                  {m.analysis?.summary && (
                    <p className="mt-1 ml-4 text-gray-700">
                      📝 Summary: {m.analysis.summary}
                    </p>
                  )}
                </li>
              )
            )}
          </ul>
        ) : (
          <p>No messages received yet.</p>
        )}
      </div>
    </Layout>
  );
}
