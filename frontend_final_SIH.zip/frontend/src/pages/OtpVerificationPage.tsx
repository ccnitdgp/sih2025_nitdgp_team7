import { useState, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import API from "@/utils/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import logo from "@/assets/logo-kmrl.png";

const MOCK_USER_ID = "test_user_id_123";

interface UserType {
  name: string;
  email: string;
  profileCompleted?: boolean;
}

const OtpVerificationPage = () => {
  const navigate = useNavigate();

  const [otpCode, setOtpCode] = useState("");
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [otpExpiry, setOtpExpiry] = useState<number | null>(null);
  const [timer, setTimer] = useState<number>(0);

  const [isSending, setIsSending] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [smsSent, setSmsSent] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");

  // ✅ AFTER OTP SUCCESS → REDIRECT BASED ON PROFILE
  const handlePostVerificationRedirect = useCallback(async () => {
    try {
      const fetchedUser: UserType = await API.fetchUser();
      sessionStorage.setItem("otp_verified_session", "true");

      if (fetchedUser && fetchedUser.email && !fetchedUser.profileCompleted) {
        setStatusMessage("✅ Verification successful! Redirecting to profile...");
        setTimeout(() => navigate("/profile", { replace: true }), 500);
      } else {
        setStatusMessage("✅ Verification successful! Redirecting to home...");
        setTimeout(() => navigate("/", { replace: true }), 500);
      }
    } catch (error) {
      console.error("Post verification error:", error);
      sessionStorage.setItem("otp_verified_session", "true");
      navigate("/profile", { replace: true });
    }
  }, [navigate]);

  // ✅ AUTO REDIRECT IF OTP ALREADY VERIFIED (ON REFRESH)
  useEffect(() => {
    const isOtpVerified = sessionStorage.getItem("otp_verified_session") === "true";
    if (isOtpVerified) {
      handlePostVerificationRedirect();
    }
  }, [handlePostVerificationRedirect]);

  // ✅ SEND RANDOM OTP WITH 60s EXPIRY
  const handleSendCode = useCallback(async () => {
    setIsSending(true);
    setStatusMessage("Sending verification code...");

    try {
      const randomOtp = Math.floor(100000 + Math.random() * 900000).toString();
      setGeneratedOtp(randomOtp);

      const expiryTime = Date.now() + 60000; // ✅ 60 SECONDS
      setOtpExpiry(expiryTime);
      setTimer(60);
      setOtpCode("");

      await API.post("/sms/send", {
        userId: MOCK_USER_ID,
        messageBody: `Your OTP is ${randomOtp}`, // mock
      });

      console.log("🔐 MOCK OTP:", randomOtp);
      setStatusMessage("✅ OTP sent! It will expire in 60 seconds.");
      setSmsSent(true);
    } catch (error) {
      setStatusMessage("❌ Failed to send OTP.");
    } finally {
      setIsSending(false);
    }
  }, []);

  // ✅ 60s COUNTDOWN TIMER
  useEffect(() => {
    if (!otpExpiry) return;

    const interval = setInterval(() => {
      const remaining = Math.max(
        0,
        Math.ceil((otpExpiry - Date.now()) / 1000)
      );

      setTimer(remaining);

      if (remaining === 0) {
        setGeneratedOtp(null);
        setOtpExpiry(null);
        setStatusMessage("⏳ OTP expired. Please resend the code.");
        clearInterval(interval);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [otpExpiry]);

  // ✅ VERIFY OTP
  const handleVerifyOtp = () => {
    setIsVerifying(true);
    setStatusMessage("Verifying code...");

    setTimeout(() => {
      setIsVerifying(false);

      if (!generatedOtp || !otpExpiry || Date.now() > otpExpiry) {
        setStatusMessage("⏳ OTP expired. Please resend.");
        return;
      }

      if (otpCode === generatedOtp) {
        handlePostVerificationRedirect();
      } else {
        setStatusMessage("❌ Invalid OTP. Try again.");
      }
    }, 1200);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <Card className="w-[400px] shadow-2xl">
        <CardHeader className="text-center">
          <img src={logo} alt="Logo" className="h-16 mx-auto mb-2" />
          <CardTitle className="text-2xl">Two-Factor Verification</CardTitle>
          <CardDescription>Please verify your account to proceed.</CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <p className="text-sm text-center text-muted-foreground">
            {statusMessage || "Click below to receive your verification code."}
          </p>

          {smsSent && timer > 0 && (
            <p className="text-center text-xs text-blue-600 font-semibold">
              OTP expires in {timer} seconds
            </p>
          )}

          <Button
            onClick={handleSendCode}
            disabled={isSending || isVerifying}
            className="w-full"
          >
            {isSending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending...
              </>
            ) : smsSent ? (
              "Resend Code"
            ) : (
              "Send Verification Code"
            )}
          </Button>

          <Input
            type="text"
            placeholder="Enter 6-digit OTP"
            value={otpCode}
            onChange={(e) => setOtpCode(e.target.value)}
            maxLength={6}
            disabled={!smsSent || isVerifying}
            className="text-center text-lg tracking-widest"
          />
        </CardContent>

        <CardFooter>
          <Button
            onClick={handleVerifyOtp}
            disabled={isVerifying || otpCode.length !== 6 || !smsSent}
            className="w-full"
          >
            {isVerifying ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifying...
              </>
            ) : (
              "Verify OTP & Continue"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default OtpVerificationPage;
