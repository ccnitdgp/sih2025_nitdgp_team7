import { Layout } from "@/components/Layout";
import  MetroMap  from "@/components/ui/smartmap";

const Map = () => {
  return (
    <Layout>
      <MetroMap />
    </Layout>
  );
};

export default Map;
