/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect, useRef } from 'react';
import { 
  PlusCircle, MessageSquare, Search as SearchIcon, Clock, 
  Send, FileText, IndianRupee, Calendar, Users
} from 'lucide-react';
import { toast } from 'sonner';
import { Layout } from "@/components/Layout";

// --- TYPES ---
interface Project {
  _id: string;
  project_name: string;
  vendor_email: string;
  budget: string;
  assignedUserIds: string[];
  status: 'WAITING_FOR_PITCH' | 'NEGOTIATION_ACTIVE' | 'APPROVED';
  messages: Message[];
  vendor_pitch?: {
    quote: string;
    remarks: string;
  };
}

interface Message {
  sender: 'MANAGER' | 'VENDOR';
  text: string;
  timestamp: string;
}

const Proposal = () => {
  const [activeTab, setActiveTab] = useState<'create' | 'negotiate'>('negotiate');
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  
  // 1. FETCH REAL DATA (Polling every 3s)
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const res = await fetch('http://localhost:5001/api/negotiation/list');
        if (res.ok) {
          const data = await res.json();
          setProjects(data);
        }
      } catch (err) {
        console.error("Failed to fetch projects");
      }
    };

    fetchProjects(); // Initial Load
    const interval = setInterval(fetchProjects, 3000); // Poll for updates
    return () => clearInterval(interval);
  }, []);

  return (
    <Layout>
      <div className="min-h-[calc(100vh-100px)] bg-background text-foreground flex flex-col transition-smooth">
        
        {/* HEADER */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
              <Users size={20} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Vendor Management</h1>
              <p className="text-muted-foreground text-sm">Manage work orders and negotiations</p>
            </div>
          </div>
          
          {/* TABS */}
          <div className="flex bg-muted/50 p-1 rounded-lg border border-border">
            <button
              onClick={() => setActiveTab('negotiate')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === 'negotiate' ? 'bg-background shadow-sm text-foreground ring-1 ring-border' : 'text-muted-foreground'
              }`}
            >
              <MessageSquare size={16} /> Negotiations
            </button>
            <button
              onClick={() => setActiveTab('create')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === 'create' ? 'bg-background shadow-sm text-foreground ring-1 ring-border' : 'text-muted-foreground'
              }`}
            >
              <PlusCircle size={16} /> New Request
            </button>
          </div>
        </div>

        {/* MAIN CONTENT */}
        <main className="flex-1 w-full animate-in fade-in slide-in-from-bottom-2 duration-500">
          {activeTab === 'create' ? (
            <CreateRequestView setActiveTab={setActiveTab} />
          ) : (
            <NegotiationView 
              projects={projects} 
              selectedId={selectedProjectId} 
              setSelectedId={setSelectedProjectId} 
            />
          )}
        </main>
      </div>
    </Layout>
  );
};

// --- SUB-COMPONENT: CREATE REQUEST FORM (CONNECTED) ---
const CreateRequestView = ({ setActiveTab }: { setActiveTab: (t: 'create'|'negotiate') => void }) => {
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const payload = {
      project_name: formData.get('project_name'),
      budget: formData.get('budget'),
      deadline: formData.get('deadline'),
      vendor_email: formData.get('vendor_email')
    };

    toast.info("Sending Request...");

    try {
      const res = await fetch('http://localhost:5001/api/negotiation/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      const data = await res.json();

      if (res.ok) {
        toast.success("Request Created!", {
           description: data.message + (data.debug_link ? ` (Debug Link: ${data.debug_link})` : "")
        });
        setTimeout(() => setActiveTab('negotiate'), 1000);
      } else {
        toast.error("Failed to create request");
      }
    } catch (err) {
      toast.error("Server Error");
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-card border border-border rounded-xl shadow-soft p-6 lg:p-8">
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Note: name attributes added for FormData */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Project Title</label>
            <input name="project_name" required className="w-full h-10 px-3 rounded-md border border-input bg-background" placeholder="e.g. Repair HVAC" />
          </div>
          <div className="grid grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-sm font-medium">Budget (₹)</label>
              <input name="budget" type="number" required className="w-full h-10 px-3 rounded-md border border-input bg-background" placeholder="50000" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Deadline</label>
              <input name="deadline" type="date" required className="w-full h-10 px-3 rounded-md border border-input bg-background" />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Vendor Email</label>
            <input name="vendor_email" type="email" required className="w-full h-10 px-3 rounded-md border border-input bg-background" placeholder="vendor@gmail.com" />
          </div>
          <div className="pt-4">
            <button type="submit" className="w-full h-10 rounded-md bg-primary text-primary-foreground font-medium hover:bg-primary/90">
              <Send className="mr-2 h-4 w-4 inline" /> Publish Request
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// --- SUB-COMPONENT: CHAT DASHBOARD (CONNECTED) ---
const NegotiationView = ({ projects, selectedId, setSelectedId }: any) => {
  const activeProject = projects.find((p: any) => p._id === selectedId);
  const bottomRef = useRef<HTMLDivElement>(null);
  const [input, setInput] = useState("");

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeProject?.messages]);

  const handleSend = async () => {
    if(!input.trim() || !activeProject) return;
    
    // Optimistic Update (Optional)
    // setInput(""); 

    try {
      await fetch('http://localhost:5001/api/negotiation/send-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: activeProject._id, // Identify by ID for Manager
          sender: "MANAGER",
          text: input
        })
      });
      setInput("");
      toast.success("Message sent");
    } catch (err) {
      toast.error("Failed to send");
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-[600px] gap-6 border border-border rounded-xl bg-card shadow-sm overflow-hidden">
      {/* SIDEBAR LIST */}
      <div className="w-full lg:w-80 border-r border-border bg-muted/10 flex flex-col">
         <div className="p-4 border-b border-border font-bold">Projects</div>
         <div className="flex-1 overflow-y-auto p-2 space-y-2">
          {projects.map((p: any) => (
            <div key={p._id} onClick={() => setSelectedId(p._id)} 
              className={`p-3 rounded-lg cursor-pointer ${selectedId === p._id ? 'bg-background shadow ring-1 ring-primary' : 'hover:bg-muted/50'}`}>
              <div className="flex justify-between mb-1">
                 <span className={`text-[10px] px-2 rounded-full ${p.status === 'NEGOTIATION_ACTIVE' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                   {p.status === 'NEGOTIATION_ACTIVE' ? 'ACTIVE' : 'WAITING'}
                 </span>
              </div>
              <h3 className="font-medium text-sm truncate">{p.project_name}</h3>
            </div>
          ))}
         </div>
      </div>

      {/* CHAT WINDOW */}
      <div className="flex-1 flex flex-col bg-background">
        {activeProject ? (
          <>
            <div className="p-4 border-b border-border bg-muted/20 flex justify-between">
              <div>
                <h2 className="font-bold">{activeProject.project_name}</h2>
                <div className="text-xs text-muted-foreground mt-1 flex gap-3">
                  <span>Budget: ₹{activeProject.budget}</span>
                  {activeProject.vendor_pitch && <span className="text-primary font-bold">Quote: ₹{activeProject.vendor_pitch.quote}</span>}
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-muted/10">
               {/* CHAT MESSAGES LOGIC SAME AS BEFORE */}
               {activeProject.status === 'WAITING_FOR_PITCH' ? (
                 <div className="h-full flex items-center justify-center text-muted-foreground">Waiting for Vendor Pitch...</div>
               ) : (
                 <>
                   {activeProject.messages.map((msg: any, i: number) => (
                     <div key={i} className={`flex ${msg.sender === 'MANAGER' ? 'justify-end' : 'justify-start'}`}>
                       <div className={`max-w-[85%] rounded-2xl px-4 py-2 ${msg.sender === 'MANAGER' ? 'bg-primary text-white' : 'bg-white border'}`}>
                         <p className="text-sm">{msg.text}</p>
                       </div>
                     </div>
                   ))}
                   <div ref={bottomRef} />
                 </>
               )}
            </div>

            <div className="p-3 border-t bg-card flex gap-2">
              <input 
                disabled={activeProject.status === 'WAITING_FOR_PITCH'}
                value={input} onChange={e => setInput(e.target.value)} 
                className="flex-1 border rounded-md px-3" placeholder="Type message..." 
                onKeyDown={e => e.key === 'Enter' && handleSend()}
              />
              <button onClick={handleSend} disabled={activeProject.status === 'WAITING_FOR_PITCH'} className="bg-primary text-white px-4 rounded-md">
                <Send size={18} />
              </button>
            </div>
          </>
        ) : (
          <div className="h-full flex items-center justify-center text-muted-foreground">Select a project</div>
        )}
      </div>
    </div>
  );
};

export default Proposal;