import { useState } from "react";
import Joyride, { CallBackProps, Step } from "react-joyride";
import { useNavigate, useLocation } from "react-router-dom";

export default function AppTour() {
  const navigate = useNavigate();
  const location = useLocation();
  const oauthEmail = localStorage.getItem("oauthEmail"); 
  const tourKey = `patram_tour_done_${oauthEmail}`;
  const [run, setRun] = useState(() => !localStorage.getItem(tourKey));

  const steps: Step[] = [
    { target: "body", content: "👋 Welcome to Patram ∞ ! Let's take a quick tour.", placement: "center", disableBeacon: true },
    { target: '[data-tour="login"]', content: "Click here to login or register and access the portal.", placement: "right", disableBeacon: true },
    { target: '[data-tour="integrations-tab"]', content: "Integrations help you to connect to external apps like Whatsapp, Gmail, Drive, SharePoint and Maximo Exports.", placement: "right", disableBeacon: true },
    { target: '[data-tour="dashboard"]', content: "This is your main Dashboard where you can get important insights.", placement: "right", disableBeacon: true },
    { target: '[data-tour="summariq"]', content: "SummariQ lets you view the original documents along with their summaries.", placement: "right", disableBeacon: true },
    { target: '[data-tour="manager"]', content: "Manager section organizes your resources.", placement: "right", disableBeacon: true },
    { target: '[data-tour="shelfy"]', content: "Shelfy lets you visualise documents with tags and categories.", placement: "right", disableBeacon: true },
    { target: '[data-tour="usersAccess"]', content: "Manage user access and roles here.", placement: "right", disableBeacon: true },
    { target: '[data-tour="analytics"]', content: "Analytics shows performance tracking and how the storage is being managed .", placement: "right", disableBeacon: true },
    { target: '[data-tour="security"]', content: "Security settings keep things safe.", placement: "right", disableBeacon: true },
    { target: '[data-tour="settings"]', content: "Here you can manage general settings, integrations, storage etc.", placement: "right", disableBeacon: true },
    { target: "body", content: "🎉 That’s it! You’re ready to explore Patram ∞ on your own.", placement: "center", disableBeacon: true },
  ];

  const routeMap: Record<string, string> = {
    summariq: "/documents",
    manager: "/manager",
    shelfy: "/categories",
    usersAccess: "/users",
    analytics: "/analytics",
    security: "/security",
    settings: "/settings",
  };

  // Wait for an element to exist in DOM
  const waitForElement = async (selector: string, timeout = 3000) => {
    const interval = 50;
    let elapsed = 0;
    return new Promise<HTMLElement | null>((resolve) => {
      const timer = setInterval(() => {
        const el = document.querySelector(selector) as HTMLElement;
        if (el) {
          clearInterval(timer);
          resolve(el);
        }
        elapsed += interval;
        if (elapsed >= timeout) {
          clearInterval(timer);
          resolve(null);
        }
      }, interval);
    });
  };

  const handleJoyrideCallback = async (data: CallBackProps) => {
  const { type, status, index } = data;

  //Tour finished or skipped
  if (status === "finished" || status === "skipped") {
    localStorage.setItem(tourKey, "true");
    setRun(false);
    return;
  }

  //Keep your existing route navigation logic
  if (type === "step:before") {
    const step = steps[index];
    if (typeof step.target === "string") {
      const match = step.target.match(/data-tour="(.+?)"/);
      const key = match?.[1];

      if (key === "integrations-tab") {
        if (location.pathname !== "/settings") navigate("/settings");

        const el = await waitForElement('[data-value="integrations"]');
        if (el) el.click();
      } 
      else if (key && routeMap[key] && location.pathname !== routeMap[key]) {
        navigate(routeMap[key]);
      }
    }
  }
};


  return (
    <Joyride
      steps={steps}
      run={run}
      continuous
      showProgress
      showSkipButton
      spotlightClicks
      disableOverlayClose
      scrollToFirstStep={false}
      scrollOffset={100}
      spotlightPadding={10}
      styles={{
        options: {
          zIndex: 99999,
          primaryColor: "#2563eb",
          textColor: "#111",
          width: 350,
        },
        tooltip: {
          fontSize: "14px",
          textAlign: "left",
          maxWidth: "350px",
          whiteSpace: "normal",
        },
        buttonNext: { backgroundColor: "#2563eb" },
        buttonBack: { marginRight: 10 },
      }}
      callback={handleJoyrideCallback}
      disableScrolling={true}
    />
  );
}
