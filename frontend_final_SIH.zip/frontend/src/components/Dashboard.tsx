import {
  FileText,
  FolderOpen,
  Upload,
  Download,
  Eye,
  Lock,
  AlertCircle,
  Shield,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import heroImage from "@/assets/dashboard-hero.jpg";
import { useNavigate } from 'react-router-dom';
import Translated from "@/components/Translated";
import CalendarPage from "./ui/calenderPage";


const statsCards = [
  {
    id: "totalDocuments",
    value: "12,847",
    change: "+12%",
    trend: "up",
    icon: FileText,
    color: "text-blue-600",
    bgColor: "bg-blue-100",
  },
  {
    id: "storageUsed",
    value: "2.4 TB",
    change: "78%",
    trend: "neutral",
    icon: FolderOpen,
    color: "text-purple-600",
    bgColor: "bg-purple-100",
  },
  {
    id: "activeUsers",
    value: "1,245",
    change: "+8%",
    trend: "up",
    icon: Lock,
    color: "text-green-600",
    bgColor: "bg-green-100",
  },
  {
    id: "monthlyGrowth",
    value: "18.2%",
    change: "+3.1%",
    trend: "up",
    icon: Shield,
    color: "text-accent",
    bgColor: "bg-amber-100",
  },
];

const recentActivities = [
  { id: 1, type: "upload", file: "Q3_Financial_Report.pdf", user: "Sara Raees", time: "2 minutes ago" },
  { id: 2, type: "access", file: "Project_Proposal_2024.docx", user: "Pranav Rajesh", time: "15 minutes ago" },
  { id: 3, type: "review", file: "Safety_Guidelines.pdf", user: "Bina Kapoor", time: "1 hour ago" },
  { id: 4, type: "sync", file: "SharePoint Integration", user: "System", time: "3 hours ago" },
];

const pendingApprovals = [
  { id: 1, title: "Marketing Budget Q4 2025", priority: "high", submitter: "Alex Ray", daysWaiting: 2 },
  { id: 2, title: "New Employee Onboarding Manual", priority: "medium", submitter: "Jane Doe", daysWaiting: 5 },
  { id: 3, title: "IT Hardware Purchase Request", priority: "low", submitter: "John Smith", daysWaiting: 12 },
];

const storageData = [
  {
    id: "pdf",
    size: "1.2 TB",
    percentage: 65,
  },
  {
    id: "images",
    size: "0.8 TB",
    percentage: 25,
  },
  {
    id: "other",
    size: "0.4 TB",
    percentage: 10,
  },
];

export const Dashboard = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">

      {/* Hero Section */}
      <div
        id="dashboard-hero"
        className="relative overflow-hidden rounded-xl bg-gradient-to-r from-primary to-primary-light"
      >
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="relative px-8 py-12 text-primary-foreground">
          <div className="max-w-2xl">
            <h1 className="text-4xl font-bold mb-4">
              <Translated defaultText="Welcome to Patram Infinity" />
            </h1>

            <p className="text-lg opacity-90 mb-6">
              <Translated defaultText="Centralized document management platform for seamless collaboration, automated workflows, and intelligent document processing across all departments." />
            </p>

            <div className="flex gap-4">
              <Button size="lg" variant="secondary">
                <Upload className="h-5 w-5 mr-2" />
                <Translated defaultText="Integrations" />
              </Button>

              <Button
                size="lg"
                variant="secondary"
                className=" hover:bg-primary-foreground hover:text-primary"
              >
                <Eye className="h-5 w-5 mr-2" />
                <Translated defaultText="View All Files" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div id="stats-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsCards.map((stat) => (
          <Card key={stat.id} className="shadow-soft hover:shadow-elevated transition-smooth">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">
                    {stat.id === "totalDocuments" && <Translated defaultText="Total Documents" />}
                    {stat.id === "storageUsed" && <Translated defaultText="Storage Used" />}
                    {stat.id === "activeUsers" && <Translated defaultText="Encrypted Documents" />}
                    {stat.id === "monthlyGrowth" && <Translated defaultText="Security Score" />}
                  </p>

                  <p className="text-2xl font-bold">{stat.value}</p>

                  <div className="flex items-center text-xs">
                    <Badge
                      variant={stat.trend === "up" ? "default" : "secondary"}
                      className="text-xs"
                    >
                      {stat.change}
                    </Badge>

                    <span className="ml-2 text-muted-foreground">
                      <Translated defaultText="vs last month" />
                    </span>
                  </div>
                </div>

                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div>
        <CalendarPage/>
      </div>

      {/* Storage Overview */}
      <Card id="storage-overview" className="shadow-soft">
        <CardHeader>
          <CardTitle>
            <Translated defaultText="Storage Overview" />
          </CardTitle>

          <CardDescription>
            <Translated defaultText="Current storage usage across different file types" />
          </CardDescription>
        </CardHeader>

        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {storageData.map((item) => (
              <div key={item.id} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>
                    {item.id === "pdf" && (
                      <Translated defaultText="PDF Documents" />
                    )}
                    {item.id === "images" && (
                      <Translated defaultText="Images & Scans" />
                    )}
                    {item.id === "other" && (
                      <Translated defaultText="Other Files" />
                    )}
                  </span>

                  <span className="font-medium">{item.size}</span>
                </div>

                <Progress value={item.percentage} className="h-2" />

                <p className="text-xs text-muted-foreground">
                  {item.percentage}%{" "}
                  <Translated defaultText="of total storage" />
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

    </div>
  );
};
