// src/components/ProjectBoard/ProjectBoard.tsx

/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect, useCallback } from "react";
import { Layout } from "../Layout";
import API from "../../utils/api";
import { Project, Task, TaskStatus } from "../../types";
import { groupTasks } from "../../utils/helper";

// Component Imports
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../ui/card";
import { Button } from "../ui/button";
import { User as UserIcon, Plus, BarChart, Clock, CheckCircle, CheckCheck } from "lucide-react";
import { Badge } from "../ui/badge";

// Dedicated Component Imports
import TaskCard from "./TaskCard";
import ProjectAnalyticsModal from "../modals/ProjectAnalyticsModal";
import { EmployeeCompleteModal, ManagerReviewModal } from "../modals/TaskModals";
import { ProjectFormModal, AssignActionModal } from "../modals/ProjectModals";

// Define a type for the essential user data we need
interface CurrentUser {
    jobTitle: string;
    employeeId: string;
    department: string;
}

// Define Document structure for state management
interface Document {
    id: string;
    name: string;
    allActions: any[];
}

// Define the structure for fetched team members (matches TeamMember in ProjectModals.tsx)
interface TeamMember {
    _id: string;
    name: string;
    department: string;
}


const ProjectBoard: React.FC = () => {
    // 1. User and Loading states
    const [loggedInUser, setLoggedInUser] = useState<CurrentUser | null>(null);
    const [loadingUser, setLoadingUser] = useState(true);

    // 2. Document state for Assignment Modal (already implemented)
    const [availableDocuments, setAvailableDocuments] = useState<Document[]>([]);
    const [loadingDocuments, setLoadingDocuments] = useState(false);


    // 3. Derive user properties from state
    const currentUserId = loggedInUser?.employeeId || '';
    const isManager = loggedInUser?.jobTitle === 'Manager';
    const isEmployee = loggedInUser?.jobTitle === 'Junior Engineer';

    // State Hooks (Project/Task management)
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [tasks, setTasks] = useState<Task[]>([]);
    const [projects, setProjects] = useState<Project[]>([]);
    const [selectedProject, setSelectedProject] = useState<Project | null>(null);
    const [loadingProjects, setLoadingProjects] = useState(true);
    const [loadingTasks, setLoadingTasks] = useState(false);

    // Modal States (unmodified)
    const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
    const [targetUserId, setTargetUserId] = useState('');
    const [isCompleteModalOpen, setIsCompleteModalOpen] = useState(false);
    const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
    const [selectedTask, setSelectedTask] = useState<Task | null>(null);
    const [isAnalyticsModalOpen, setIsAnalyticsModalOpen] = useState(false);


    // --- Document Transformation Utility (Copied for local definition) ---
    const transformFetchedDocs = (docs: any[]): Document[] => {
        return docs.map((doc) => {
            const isMaximo = doc.source === "MAXIMO";
            let name = "Untitled Document";
            const rawActions = doc.analysis?.raw?.data?.actions_required || doc.raw_analysis?.data?.actions_required || [];

            if (doc.source === "gmail") {
                name = doc.subject || "Untitled Email";
            } else if (isMaximo) {
                name = doc.title || `Maximo Document: ${doc.source_id}`;
            } else {
                name = doc.fileName || "Untitled Document";
            }

            return {
                id: isMaximo ? doc.source_id : doc._id,
                name: name,
                allActions: rawActions,
            };
        });
    };

    // --- API HANDLERS ---

    // Fetch documents for the user's department (unmodified logic)
    const fetchDepartmentDocuments = useCallback(async (department: string) => {
        if (!department) {
            setAvailableDocuments([]);
            return;
        }
        setLoadingDocuments(true);
        try {
            const response = await API.get("/messages/search", {
                params: { department: department }
            });

            const transformed = transformFetchedDocs(response.data);
            setAvailableDocuments(transformed);

        } catch (error) {
            console.error("Failed to fetch department documents:", error);
            setAvailableDocuments([]);
        } finally {
            setLoadingDocuments(false);
        }
    }, []);


    const fetchProjects = useCallback(async (newProjectIdToSelect: string | null = null) => {
        if (loadingUser) return;
        setLoadingProjects(true);
        try {
            const response = await API.get("/projects/my-projects");
            const fetchedProjects = response.data.data as Project[];
            setProjects(fetchedProjects);

            if (fetchedProjects.length > 0) {
                const projectToSelect = fetchedProjects.find(p => p._id === newProjectIdToSelect) || fetchedProjects[0];
                setSelectedProject(projectToSelect);
            } else {
                setSelectedProject(null);
                setTasks([]);
            }
        } catch (error) {
            console.error("Failed to fetch projects:", (error as any).response?.data || error);
        } finally {
            setLoadingProjects(false);
        }
    }, [loadingUser]);

    const fetchTasks = useCallback(async (projectId: string) => {
        if (!projectId) return;
        setLoadingTasks(true);
        try {
            const response = await API.get(`/tasks/${projectId}`);
            setTasks(response.data.data as Task[]);
        } catch (error) {
            console.error(`Failed to fetch tasks for project ${projectId}:`, (error as any).response?.data || error);
            setTasks([]);
        } finally {
            setLoadingTasks(false);
        }
    }, []);

    const handleTaskUpdateFlow = useCallback(async (
        taskId: string,
        newStatus: TaskStatus,
        comment?: string,
        proof?: { filePath: string, comment: string }
    ) => {
        const updatePayload: any = { status: newStatus };

        if (newStatus === 'Completed' && proof) {
            const fullProof = { ...proof, uploadedAt: new Date().toISOString() };
            updatePayload.completionProof = fullProof;
            // Optimistic update for UI feedback
            setTasks(prev => prev.map(t =>
                t._id === taskId ? { ...t, status: newStatus, completionProof: fullProof } : t
            ));
        } else if (newStatus === 'Pending' && comment) {
            updatePayload.managerComment = comment;
            updatePayload.completionProof = undefined; // Clear proof upon rejection
        } else if (newStatus === 'Approved') {
            updatePayload.managerComment = comment;
        }

        try {
            await API.patch(`/tasks/${taskId}/status`, updatePayload);
            console.log(`Task status set to ${newStatus}.`);
            if (selectedProject) fetchTasks(selectedProject._id);

        } catch (error) {
            console.error("Failed to update task status:", (error as any).response?.data || error);
            alert(`Failed to update task status: ${newStatus}. See console.`);
        }
    }, [selectedProject, fetchTasks]);


    // --- INITIAL DATA LOADING ---
    useEffect(() => {
        const fetchUser = async () => {
            setLoadingUser(true);
            try {
                const user: any = await API.fetchUser();
                setLoggedInUser({
                    jobTitle: user.jobTitle,
                    employeeId: user.employeeId,
                    department: user.department,
                });
            } catch (error) {
                console.error("Error fetching logged-in user data:", error);
            } finally {
                setLoadingUser(false);
            }
        };
        fetchUser();
    }, []);

    // Effect to fetch projects AND documents once user is loaded
    useEffect(() => {
        if (!loadingUser) {
            fetchProjects();

            // Fetch documents for the user's department once login is complete
            if (loggedInUser?.department) {
                fetchDepartmentDocuments(loggedInUser.department);
            }
        }
    }, [loadingUser, fetchProjects, loggedInUser?.department, fetchDepartmentDocuments]);

    useEffect(() => {
        if (selectedProject) {
            fetchTasks(selectedProject._id);
        }
    }, [selectedProject, fetchTasks]);


    // --- VIEW DATA PREPARATION ---
    const groupedTasks = groupTasks(tasks);
    console.log(groupedTasks);
    // 4. Transform grouped task user data into the TeamMember structure expected by the modals
    const boardUsers: TeamMember[] = Object.values(groupedTasks).map(group => ({
        _id: group.user._id, // Assuming the structure of user in groupedTasks has _id
        name: group.user.name,
        department: group.user.dept, // Assuming the department property is named 'dept' in the grouped user structure
    }));

    if (loadingUser) {
        return (
            <Layout>
                <div className="p-10 text-center text-xl font-semibold">
                    <Clock className="h-6 w-6 inline mr-2 animate-spin" /> Loading user profile...
                </div>
            </Layout>
        );
    }

    const isReadyForAssignment = !loadingDocuments && availableDocuments.length > 0;


    return (
        <Layout>
            <div className="space-y-4">
                <h1 className="text-3xl font-bold">Document-Driven Project Board</h1>
                <p className="text-muted-foreground">User Role: {loggedInUser?.jobTitle || 'Unknown'} | Department: {loggedInUser?.department || 'N/A'}</p>
            </div>

            <div className="grid grid-cols-12 gap-6 mt-6">

                {/* --- LEFT SIDE (70%): Task Board --- */}
                <div className="col-span-9 space-y-4">
                    <div className="flex justify-between items-center">
                        <h2 className="text-2xl font-semibold">
                            Active Project: {selectedProject?.projectName || "Select a Project"}
                        </h2>
                        {isManager && (
                            <div className="flex gap-2">
                                <Button variant="secondary" onClick={() => selectedProject && setIsAnalyticsModalOpen(true)}>
                                    <BarChart className="h-4 w-4 mr-2" /> View Analytics
                                </Button>
                                <Button onClick={() => setIsFormOpen(true)}>
                                    <Plus className="h-4 w-4 mr-2" /> Add New Project
                                </Button>
                            </div>
                        )}
                    </div>
                    {/* Task Board Grid */}
                    {selectedProject ? (
                        <div className="space-y-8">
                            {boardUsers.length > 0 ? (
                                boardUsers.map(user => (
                                    (isManager || user._id === currentUserId) && (
                                        <div key={user._id}>
                                            <h3 className="text-xl font-bold border-b pb-1 mb-3 flex items-center gap-2">
                                                <UserIcon className="h-5 w-5 text-gray-600" /> {user.name}
                                                <Badge variant="secondary" className="text-xs">{user.department}</Badge>
                                                {user._id === currentUserId && <Badge variant="default" className="text-xs bg-blue-500 hover:bg-blue-600">You</Badge>}
                                            </h3>

                                            <div className="grid grid-cols-3 gap-4">

                                                {/* Column 1: PENDING */}
                                                <Card>
                                                    <CardHeader className="bg-red-50 p-3 border-b">
                                                        <CardTitle className="text-lg flex justify-between items-center text-red-700">
                                                            Pending
                                                            {isManager && (
                                                                <Button
                                                                    variant="ghost"
                                                                    size="icon"
                                                                    onClick={() => {
                                                                        setTargetUserId(user._id);
                                                                        if (isReadyForAssignment) setIsAssignModalOpen(true);
                                                                        else alert(loadingDocuments ? "Documents are still loading..." : "No documents available to assign tasks from.");
                                                                    }}
                                                                    title={`Assign task to ${user.name}`}
                                                                    disabled={!isReadyForAssignment}
                                                                >
                                                                    <Plus className="h-4 w-4 text-red-700" />
                                                                </Button>
                                                            )}
                                                        </CardTitle>
                                                    </CardHeader>
                                                    <CardContent className="p-3 min-h-[100px]">
                                                        {groupedTasks[user._id]?.Pending.map(task =>
                                                            <TaskCard
                                                                key={task._id}
                                                                task={task}
                                                                currentUserId={currentUserId}
                                                                setIsCompleteModalOpen={setIsCompleteModalOpen}
                                                                setIsReviewModalOpen={setIsReviewModalOpen}
                                                                setSelectedTask={setSelectedTask}
                                                            />
                                                        )}
                                                        {groupedTasks[user._id]?.Pending.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No tasks pending.</p>}
                                                    </CardContent>
                                                </Card>

                                                {/* Column 2: COMPLETED */}
                                                <Card>
                                                    <CardHeader className="bg-yellow-50 p-3 border-b">
                                                        <CardTitle className="text-lg flex items-center text-yellow-700">
                                                            <CheckCircle className="h-5 w-5 mr-2" /> Completed
                                                        </CardTitle>
                                                    </CardHeader>
                                                    <CardContent className="p-3 min-h-[100px]">
                                                        {groupedTasks[user._id]?.Completed.map(task =>
                                                            <TaskCard
                                                                key={task._id}
                                                                task={task}
                                                                currentUserId={currentUserId}
                                                                setIsCompleteModalOpen={setIsCompleteModalOpen}
                                                                setIsReviewModalOpen={setIsReviewModalOpen}
                                                                setSelectedTask={setSelectedTask}
                                                            />
                                                        )}
                                                        {groupedTasks[user._id]?.Completed.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">Awaiting completion.</p>}
                                                    </CardContent>
                                                </Card>

                                                {/* Column 3: APPROVED */}
                                                <Card>
                                                    <CardHeader className="bg-green-50 p-3 border-b">
                                                        <CardTitle className="text-lg flex items-center text-green-700">
                                                            <CheckCheck className="h-5 w-5 mr-2" /> Approved
                                                        </CardTitle>
                                                    </CardHeader>
                                                    <CardContent className="p-3 min-h-[100px]">
                                                        {groupedTasks[user._id]?.Approved.map(task =>
                                                            <TaskCard
                                                                key={task._id}
                                                                task={task}
                                                                currentUserId={currentUserId}
                                                                setIsCompleteModalOpen={setIsCompleteModalOpen}
                                                                setIsReviewModalOpen={setIsReviewModalOpen}
                                                                setSelectedTask={setSelectedTask}
                                                            />
                                                        )}
                                                        {groupedTasks[user._id]?.Approved.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">Awaiting approval.</p>}
                                                    </CardContent>
                                                </Card>
                                            </div>
                                        </div>
                                    )
                                ))
                            ) : (
                                <p className="p-10 text-center text-lg text-muted-foreground">No assigned tasks in this project.</p>
                            )}
                        </div>
                    ) : (
                        <p className="p-10 text-center text-xl text-muted-foreground">
                            {loadingProjects ? "Loading projects..." : "No active projects found. Click 'Add New Project' to begin."}
                        </p>
                    )}
                </div>

                {/* --- RIGHT SIDE (30%): Project List --- */}
                <div className="col-span-3">
                    <Card className="shadow-lg">
                        <CardHeader>
                            <CardTitle className="text-xl">My Projects</CardTitle>
                            <CardDescription>Select a project to view its tasks.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-2">
                            {loadingProjects ? (
                                <p className="text-sm text-center text-muted-foreground">Loading...</p>
                            ) : projects.length === 0 ? (
                                <p className="text-sm text-center text-muted-foreground">No projects created yet.</p>
                            ) : (
                                projects.map(project => (
                                    <div
                                        key={project._id}
                                        onClick={() => setSelectedProject(project)}
                                        className={`p-3 border rounded-lg cursor-pointer transition-all ${selectedProject?._id === project._id ? 'bg-primary/10 border-primary' : 'hover:bg-muted'}`}
                                    >
                                        <p className="font-semibold">{project.projectName}</p>
                                        <p className="text-xs text-muted-foreground flex items-center">
                                            <Clock className="h-3 w-3 mr-1" /> Deadline: {new Date(project.initialDeadline).toLocaleDateString()}
                                        </p>
                                    </div>
                                ))
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>

            {/* --- MODALS --- (Defined in dedicated files) */}

            {/* 1. Manager: Add Project */}
            {isManager && (
                <ProjectFormModal
                    isOpen={isFormOpen}
                    onClose={() => setIsFormOpen(false)}
                    refreshProjects={fetchProjects}
                />
            )}

            {/* 2. Manager: Assign Task */}
            {isManager && isAssignModalOpen && selectedProject && targetUserId && (
                <AssignActionModal
                    isOpen={isAssignModalOpen}
                    onClose={() => setIsAssignModalOpen(false)}
                    userId={targetUserId}
                    projectId={selectedProject._id}
                    refreshTasks={fetchTasks}
                    availableDocuments={availableDocuments}
                    availableUsers={boardUsers} // 5. Pass boardUsers as availableUsers
                />
            )}

            {/* 3. Employee: Mark Completed (Requires Proof) */}
            {isCompleteModalOpen && selectedTask && (
                <EmployeeCompleteModal
                    isOpen={isCompleteModalOpen}
                    onClose={() => setIsCompleteModalOpen(false)}
                    task={selectedTask}
                    handleUpdate={handleTaskUpdateFlow}
                />
            )}

            {/* 4. Manager: Review & Reject/Approve */}
            {isManager && isReviewModalOpen && selectedTask && (
                <ManagerReviewModal
                    isOpen={isReviewModalOpen}
                    onClose={() => setIsReviewModalOpen(false)}
                    task={selectedTask}
                    handleUpdate={handleTaskUpdateFlow}
                />
            )}

            {/* 5. Manager: Analytics */}
            {isManager && isAnalyticsModalOpen && selectedProject && (
                <ProjectAnalyticsModal
                    isOpen={isAnalyticsModalOpen}
                    onClose={() => setIsAnalyticsModalOpen(false)}
                    project={selectedProject}
                    tasks={tasks}
                />
            )}
        </Layout>
    );
};

export default ProjectBoard;