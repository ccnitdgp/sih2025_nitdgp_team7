import React from 'react';
import { Clock, CheckCircle, X, CornerDownRight, Zap, User, ArrowRight } from 'lucide-react';
import { Button } from './button'; 

const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
        case 'high':
            return 'bg-red-500 text-white';
        case 'medium':
            return 'bg-orange-400 text-white';
        case 'low':
            return 'bg-yellow-300 text-black';
        default:
            return 'bg-gray-100 text-gray-800';
    }
};

const NotificationDetailModal = ({ notification, onClose }) => {
    if (!notification) return null;

    const deadline = notification.deadline 
        ? new Date(notification.deadline).toLocaleDateString('en-US', {
              year: 'numeric', month: 'short', day: 'numeric'
          })
        : 'Not Set';
        
    const createdDate = new Date(notification.createdAt).toLocaleDateString('en-US', {
        year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    return (
        <div className="fixed inset-0 z-50 bg-black/50 flex justify-center p-4 pt-10 overflow-y-auto">
            <div 
                className="bg-white p-4 rounded-xl shadow-2xl max-w-sm w-full 
                           max-h-[85vh] overflow-y-auto self-start"
            >
                {/* Header */}
                <div className="flex justify-between items-start border-b pb-3 mb-4">
                    <h2 className="text-xl font-bold text-gray-800 flex items-center">
                        <CornerDownRight className="h-5 w-5 mr-2 text-primary" />
                        Task Details
                    </h2>
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={onClose} 
                        className="text-gray-400 hover:text-gray-600"
                    >
                        <X className="h-5 w-5" />
                    </Button>
                </div>
                
                {/* Status & Priority Badges */}
                <div className="flex gap-3 mb-4 flex-wrap">
                    {/* Status Badge */}
                    <span className={`px-3 py-1 text-xs rounded-full font-semibold flex items-center ${
                        notification.isCompleted 
                            ? 'bg-emerald-100 text-emerald-700' 
                            : 'bg-yellow-100 text-yellow-700'
                    }`}>
                        {notification.isCompleted 
                            ? <CheckCircle className="h-3 w-3 mr-1"/> 
                            : <Zap className="h-3 w-3 mr-1"/>}
                        {notification.isCompleted ? 'COMPLETED' : 'PENDING'}
                    </span>

                    {/* Priority Badge */}
                    <span className={`px-3 py-1 text-xs rounded-full font-semibold ${getPriorityColor(notification.priority)}`}>
                        <div className='flex items-center'>
                            <ArrowRight className="h-3 w-3 mr-1"/>
                            Priority: {notification.priority || 'N/A'}
                        </div>
                    </span>
                </div>

                {/* Main Content */}
                <div className="space-y-4">
                    {/* Action Required */}
                    <div className="border p-2 rounded-lg bg-gray-50">
                        <h3 className="text-sm font-semibold text-gray-600 mb-1">ACTION REQUIRED</h3>
                        <p className="text-base font-medium text-gray-900">{notification.actionRequired}</p>
                    </div>

                    {/* Sender Details */}
                    <div>
                        <h3 className="text-sm font-semibold text-gray-600 flex items-center mb-1">
                            <User className="h-4 w-4 mr-1 text-gray-500" />
                            ASSIGNED BY
                        </h3>
                        <p className="text-sm text-gray-800">
                            <span className="font-semibold">{notification.senderId.name}</span>
                            <span className="text-xs text-gray-500 ml-1">({notification.senderId.department})</span>
                        </p>
                    </div>

                    {/* Dates */}
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                            <h3 className="text-xs font-semibold text-gray-600 flex items-center mb-1">
                                <Clock className="h-3.5 w-3.5 mr-1 text-gray-500" />
                                CREATED ON
                            </h3>
                            <p className="text-gray-800">{createdDate}</p>
                        </div>
                        <div>
                            <h3 className="text-xs font-semibold text-gray-600 flex items-center mb-1">
                                <Clock className="h-3.5 w-3.5 mr-1 text-red-500" />
                                DEADLINE
                            </h3>
                            <p className="text-gray-800 font-bold">{deadline}</p>
                        </div>
                    </div>

                    {/* Note/Description */}
                    {notification.description && (
                        <div className='pt-2'>
                            <h3 className="text-xs font-semibold text-gray-600 mb-1">DETAILS / INSTRUCTIONS</h3>
                            <p className="text-sm text-gray-700 whitespace-pre-wrap border-l-2 border-primary pl-2">{notification.description}</p>
                        </div>
                    )}
                </div>

                {/* Footer/Close Button */}
                <div className="mt-6 flex justify-end">
                    <Button 
                        onClick={onClose} 
                        variant="outline"
                        className="text-gray-600 hover:bg-gray-100 h-8 px-3 text-sm"
                    >
                        Close
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default NotificationDetailModal;