import React, { useEffect, useState } from 'react';

const AFRAME_SCRIPT_URL = 'https://aframe.io/releases/1.4.0/aframe.min.js';

const AFrameScene = () => {
  const [isAFrameLoaded, setIsAFrameLoaded] = useState(false);

  // Effect to dynamically load the A-Frame script
  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if ((window as any).AFRAME) {
      setIsAFrameLoaded(true);
      return;
    }

    const script = document.createElement('script');
    script.src = AFRAME_SCRIPT_URL;
    script.onload = () => {
      setIsAFrameLoaded(true);
    };
    script.onerror = () => {
      console.error("Failed to load A-Frame script.");
    };

    document.head.appendChild(script);

    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, []);

  if (!isAFrameLoaded) {
    return (
      <div className="flex items-center justify-center h-screen w-full bg-gray-100">
        <div className="p-4 bg-white rounded-lg shadow-lg">
          <p className="text-lg font-semibold text-indigo-600">
            Loading 3D Environment (A-Frame)...
          </p>
        </div>
      </div>
    );
  }

  // Render the A-Frame scene once the script is loaded
  return (
    <div className="w-full h-screen relative bg-gray-200">
      
      <a-scene style={{ height: '100%', width: '100%' }} embedded>

        {/* A-Frame Assets */}
        <a-assets>
          {/* Note: In a Next.js project, you would ensure these assets are correctly
              placed in the `/public/virtual/` directory or imported correctly.
              For this component, we keep the original relative paths.
          */}
          <img id="wood" src="/virtual/woodplank.jpg" alt="Wood Texture" />
          <img id="floor" src="/virtual/floor.jpg" alt="Floor Texture" />
          <img id="door" src="/virtual/door.jpg" alt="Door Texture" />
          <img id="shelfy" src="/virtual/Shelfy.jpg" alt="Shelfy Texture" />
          <img id="doc" src="/virtual/Tenderdocs.jpg" alt="Tender Docs Texture" />
          <img id="engg" src="/virtual/Engineering Drawing.jpeg" alt="Engineering Drawing Texture" />
          <img id="hr" src="/virtual/HR Policies.jpeg" alt="HR Policies Texture" />
          <img id="incident" src="/virtual/Incident Report.jpeg" alt="Incident Report Texture" />
          <img id="maintain" src="/virtual/Maintenance Files.jpeg" alt="Maintenance Files Texture" />
          <img id="mom" src="/virtual/Meeting Minutes.jpeg" alt="Meeting Minutes Texture" />
          <img id="regd" src="/virtual/Regulatory Directives.jpeg" alt="Regulatory Directives Texture" />
          <img id="safe" src="/virtual/Safety Circular.jpeg" alt="Safety Circular Texture" />
          <img id="vendor" src="/virtual/Vendor Invoices.jpeg" alt="Vendor Invoices Texture" />
        </a-assets>

        {/* Floor */}
        <a-plane position="-2.762 0.054 2.564" rotation="-90 0 90" color="#bbb7ac" material="src: #floor"
          scale="2.832 4.152 2.083"></a-plane>
        <a-box position="0.347 0.065 -0.480" rotation="-90 0 90" color="#bbb7ac" material="src: #floor"
          scale="4.002 10.427 0.016"></a-box>

        {/* Shelfy */}
        <a-box position="3.040 1.968 1.557" rotation="0 90 0" scale="0.059 0.438 1.255" color="#bb9854" material="src: #shelfy">
        </a-box>

        {/* Walls */}
        {/* Side Walls */}
        <a-box position="4.636 1.178 1.53" rotation="0 90 0" scale="0.059 2.21 2.017" color="#bb9854">
        </a-box>
        <a-box position="5.594 1.159 -0.488" rotation="0 0 0" scale="0.059 2.210 4.045" color="#bb9854">
        </a-box>
        <a-box position="0.34 1.194 -2.455" rotation="0 90 0" scale="0.059 2.175 10.497" color="#bb9854">
        </a-box>
        <a-box position="-4.886 1.184 0.728" rotation="0 0 0" scale="0.059 2.210 6.473" color="#bb9854">
        </a-box>
        <a-box position="-2.792 1.184 3.963" rotation="0 90 0" scale="0.059 2.210 4.235" color="#bb9854">
        </a-box>
        <a-box position="-0.705 1.184 2.75" rotation="0 0 0" scale="0.059 2.210 2.445" color="#bb9854">
        </a-box>
        <a-box position="0.264 1.178 1.536" rotation="0 90 0" scale="0.059 2.210 4.198" color="#bb9854">
        </a-box>
        {/* Top wall (above the door) */}
        <a-box position="3.004 2.006 1.531" rotation="90 90 0" scale="0.059 1.308 0.556" color="#bb9854">
        </a-box>

        {/* intersecting walls */}
        <a-box position="-0.012 1.184 -2.103" rotation="0 0 0" scale="0.059 2.21 0.755" color="#bb9854">
        </a-box>
        {/* doorframe top */}
        <a-box position="-0.018 2.005 -1.18" rotation="90 0 0" scale="0.059 1.16 0.556" color="#bb9854">
        </a-box>
        <a-box position="-0.019 1.184 0.421" rotation="0 0 0" scale="0.059 2.21 2.232" color="#bb9854">
        </a-box>

        {/* doorframe walls */}
        <a-box position="-2.072 2.005 1.539" rotation="90 90 0" scale="0.059 1.745 0.556" color="#bb9854">
        </a-box>
        <a-box position="-3.895 1.184 1.539" rotation="0 90 0" scale="0.059 2.21 2.017" color="#bb9854">
        </a-box>
        {/* Top */}
        <a-box position="-2.34 2.005 1.537" rotation="90 90 0" scale="0.059 1.16 0.556" color="#bb9854">
        </a-box>

        {/* Door */}
        <a-box position="3.928 0.894 1.907" rotation="0 41.157 0" scale="0.059 1.634 0.969" color="#bb9854" material="src: #door">
        </a-box>

        {/* Table */}
        <a-cylinder position="4.496 0.562 0.307" scale="0.559 0.038 0.579" color="#FFC0CB" rotation="0 45 0"></a-cylinder>
        <a-cylinder position="4.473 0.304 0.344" scale="0.221 0.488 0.197" color="#FFC0CB" rotation="0 45 0"></a-cylinder>

        {/* seats */}
        <a-cylinder position="4.988 0.175 0.935" scale="0.226 0.229 0.231" color="#FFC0CB" rotation="0 45 0"></a-cylinder>
        <a-cylinder position="5.048 0.199 -0.371" scale="0.226 0.229 0.231" color="#FFC0CB" rotation="0 45 0"></a-cylinder>
        <a-cylinder position="3.937 0.178 -0.210" scale="0.226 0.229 0.231" color="#FFC0CB" rotation="0 45 0"></a-cylinder>

        <a-cylinder position="1.157 0.580 0.575" scale="0.559 0.038 0.579" color="#FFC0CB" rotation="0 45 0"></a-cylinder>
        <a-cylinder position="1.115 0.334 0.572" scale="0.221 0.488 0.197" color="#FFC0CB" rotation="0 45 0"></a-cylinder>

        {/* seats */}
        <a-cylinder position="0.441 0.203 0.979" scale="0.226 0.229 0.231" color="#FFC0CB" rotation="0 45 0"></a-cylinder>
        <a-cylinder position="0.834 0.181 -0.242" scale="0.226 0.229 0.231" color="#FFC0CB" rotation="0 45 0"></a-cylinder>

        {/* Racks - Room 3 */}
        <a-box position="-1.13 0.867 2.144" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-1.13 0.867 3.467" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-1.122 1.361 2.801" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-1.122 0.955 2.814" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-1.122 0.574 2.823" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>

        <a-box position="-4.678 0.886 3.744" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-4.661 0.886 2.447" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-4.673 1.361 3.089" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-4.673 0.955 3.089" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-4.667 0.505 3.089" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>

        <a-box position="-3.264 0.867 -2.214" rotation="90 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-1.933 0.867 -2.214" rotation="90 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-2.601 1.361 -2.247" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-2.601 0.955 -2.247" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-2.6012 0.505 -2.247" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>

        <a-box position="-3.674 0.867 3.711" rotation="90 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-2.380 0.867 3.711" rotation="90 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-3.029 1.361 3.711" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-3.029 0.955 3.711" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-3.029 0.513 3.711" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>

        {/* Racks - Room 2 */}
        <a-box position="-4.611 0.867 0.945" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-4.611 0.867 -0.361" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-4.615 1.361 0.283" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-4.615 0.955 0.283" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-4.615 0.574 0.283" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>

        <a-box position="-4.59 0.867 -0.998" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-4.608 0.867 -2.296" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-4.595 1.361 -1.644" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-4.595 0.955 -1.644" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-4.595 0.574 -1.644" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>

        <a-box position="-0.33 0.867 -0.361" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-0.33 0.867 0.945" rotation="90 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="-0.332 1.361 0.283" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-0.332 0.955 0.283" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="-0.332 0.514 0.283" rotation="0 0 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>

        {/* Racks - Room 1 */}
        <a-box position="3.787 0.867 -2.235" rotation="90 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="5.108 0.867 -2.235" rotation="90 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="4.445 1.361 -2.244" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="4.445 0.918 -2.244" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="4.445 0.473 -2.244" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>

        <a-box position="1.067 0.867 -2.235" rotation="90 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="2.389 0.867 -2.235" rotation="90 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.579"></a-box>
        <a-box position="1.722 1.361 -2.244" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="1.722 0.918 -2.244" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>
        <a-box position="1.722 0.473 -2.244" rotation="0 90 0" color="#b68907" material="src: #wood" scale="0.35 0.025 1.307"></a-box>

        {/* Files/Documents on Racks */}
        {/* Tender doc */}
        <a-box position="1.743 2.006 -2.424" rotation="0 90 0" scale="0.059 0.250 1.101" color="#F7F5F5" material="src: #doc"></a-box>
        {/* Files - Level 3 */}
        <a-box position="1.346 1.390 -2.273" rotation="0 90 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="1.737 1.385 -2.236" rotation="0 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="1.719 1.439 -2.273" rotation="0 90 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="2.039 1.390 -2.273" rotation="0 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="2.039 1.390 -2.273" rotation="0 90 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 2 */}
        <a-box position="1.396 0.952 -2.222" rotation="0 93.189 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="1.346 0.983 -2.273" rotation="0 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="1.346 1.031 -2.273" rotation="0 104.08 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="1.876 0.951 -2.273" rotation="0 90 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="2.113 0.998 -2.273" rotation="5.744 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 1 */}
        <a-box position="1.346 0.501 -2.273" rotation="0 90 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="1.383 0.543 -2.273" rotation="0 85 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="2.07 0.499 -2.273" rotation="0 78.206 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>

        {/* Engineering Drawings */}
        <a-box position="4.489 2.006 -2.424" rotation="0 90 0" scale="0.059 0.250 1.101" color="#F7F5F5" material="src: #engg"></a-box>
        {/* Files - Level 3 */}
        <a-box position="4.056 1.390 -2.273" rotation="0 90 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="4.458 1.385 -2.236" rotation="0 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="4.461 1.42 -2.273" rotation="0 90 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 2 */}
        <a-box position="4.057 0.946 -2.222" rotation="0 93.189 90" color="#B04C02" scale="0.041 0.379 0.331"></a-box>
        <a-box position="4.108 0.983 -2.273" rotation="0 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="4.483 0.947 -2.244" rotation="0 104.08 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="4.892 0.942 -2.273" rotation="0 90 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 1 */}
        <a-box position="4.141 0.508 -2.273" rotation="0 90 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="4.637 0.504 -2.273" rotation="0 85 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>

        {/* Incident Reports */}
        <a-box position="-2.577 2.006 -2.424" rotation="0 90 0" scale="0.059 0.250 1.101" color="#F7F5F5" material="src: #incident"></a-box>
        {/* Files - Level 3 */}
        <a-box position="-2.954 1.39 -2.273" rotation="0 90 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-3.047 1.439 -2.273" rotation="0 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-2.37 1.395 -2.273" rotation="0 90 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 2 */}
        <a-box position="-2.986 0.998 -2.273" rotation="0 90 90" color="#701705" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-2.422 0.999 -2.228" rotation="0 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 1 */}
        <a-box position="-2.994 0.550 -2.273" rotation="0 90 90" color="#0B5417" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-2.189 0.543 -2.273" rotation="0 90 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-2.272 0.603 -2.273" rotation="0 85 90" color="#6E0B3B" scale="0.041 0.379 0.331"></a-box>

        {/* Vendor Invoices */}
        <a-box position="-0.06 2.006 0.31" rotation="0 0 0" scale="0.059 0.250 1.101" color="#F7F5F5" material="src: #vendor"></a-box>
        {/* Files - Level 3 */}
        <a-box position="-0.299 1.385 -0.076" rotation="0 0 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-0.368 1.396 0.325" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-0.324 1.394 0.687" rotation="0 90 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 2 */}
        <a-box position="-0.365 1.003 -0.132" rotation="0 -10 90" color="#B04C02" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-0.348 1.051 -0.166" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-0.311 0.992 0.477" rotation="0 0 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 1 */}
        <a-box position="-0.402 0.603 -0.054" rotation="0 0 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-0.344 0.55 0.589" rotation="0 -5 90" color="#701705" scale="0.041 0.379 0.331"></a-box>

        {/* Regulatory Directives */}
        <a-box position="-0.757 2.006 2.783" rotation="0 0 0" scale="0.059 0.250 1.101" color="#F7F5F5" material="src: #regd"></a-box>
        {/* Files - Level 3 */}
        <a-box position="-1.079 1.385 2.491" rotation="0 0 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-1.09 1.392 2.59" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-1.112 1.394 3.035" rotation="0 90 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 2 */}
        <a-box position="-1.101 0.992 2.447" rotation="0 -10 90" color="#0B5417" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-1.117 0.993 3.138" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-1.165 1.041 3.127" rotation="0 0 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 1 */}
        <a-box position="-1.101 0.603 2.41" rotation="0 0 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-1.159 0.626 2.856" rotation="0 -5 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-1.126 0.603 3.225" rotation="0 0 90" color="#701705" scale="0.041 0.379 0.331"></a-box>

        {/* HR Policies */}
        <a-box position="-4.829 2.006 -1.679" rotation="0 0 0" scale="0.059 0.250 1.101" color="#F7F5F5" material="src: #hr"></a-box>
        {/* Files - Level 3 */}
        <a-box position="-4.575 1.394 -1.453" rotation="0 0 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.614 1.392 -2.014" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 2 */}
        <a-box position="-4.648 0.987 -1.382" rotation="0 -10 90" color="#6E0B3B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.640 1.024 -1.399" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.622 0.995 -1.906" rotation="0 0 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 1 */}
        <a-box position="-4.588 0.605 -1.307" rotation="0 0 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.563 0.607 -1.946" rotation="0 -5 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>

        {/* Maintenance Files */}
        <a-box position="-4.829 2.006 3.075" rotation="0 0 0" scale="0.059 0.250 1.101" color="#F7F5F5" material="src: #maintain"></a-box>
        {/* Files - Level 3 */}
        <a-box position="-4.581 1.394 3.472" rotation="0 0 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.644 1.394 3.106" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.602 1.385 2.739" rotation="0 90 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 2 */}
        <a-box position="-4.675 0.992 3.47" rotation="0 -10 90" color="#0B5417" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.687 0.987 2.754" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.695 1.034 2.777" rotation="0 0 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 1 */}
        <a-box position="-4.694 0.533 3.483" rotation="0 0 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.695 0.537 3.101" rotation="0 -5 90" color="#B04C02" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.653 0.534 2.689" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>

        {/* Safety Circulars */}
        <a-box position="-4.829 2.006 0.3" rotation="0 0 0" scale="0.059 0.250 1.101" color="#F7F5F5" material="src: #safe"></a-box>
        {/* Files - Level 3 */}
        <a-box position="-4.581 1.394 0.602" rotation="0 0 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.602 1.385 0.023" rotation="0 0 90" color="#B04C02" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 2 */}
        <a-box position="-4.675 0.992 0.602" rotation="0 -10 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.646 0.988 0.012" rotation="0 0 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 1 */}
        <a-box position="-4.611 0.632 0.587" rotation="0 0 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-4.595 0.611 -0.015" rotation="0 -5 90" color="#701705" scale="0.041 0.379 0.331"></a-box>

        {/* Meeting Minutes */}
        <a-box position="-3.071 2.006 3.950" rotation="0 90 0" scale="0.059 0.250 1.101" color="#F7F5F5" material="src: #mom"></a-box>
        {/* Files - Level 3 */}
        <a-box position="-2.592 1.394 3.698" rotation="0 90 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-3.098 1.427 3.731" rotation="6.916 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-3.371 1.394 3.715" rotation="0 90 90" color="#0B5417" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 2 */}
        <a-box position="-2.840 0.987 3.697" rotation="0 90 90" color="#F4320B" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-3.346 0.992 3.692" rotation="0 90 90" color="#6E0B3B" scale="0.041 0.379 0.331"></a-box>
        {/* Files - Level 1 */}
        <a-box position="-2.723 0.626 3.770" rotation="0 85 90" color="#C86909" scale="0.041 0.379 0.331"></a-box>
        <a-box position="-3.394 0.537 3.727" rotation="0 90 90" color="#07169C" scale="0.041 0.379 0.331"></a-box>


        {/* Camera */}
        <a-entity id="rig" position="0.335 -0.109 8.821" rotation="0 0 0">
          <a-camera id="camera"></a-camera>
        </a-entity>

      </a-scene>
    </div>
  );
};



export default AFrameScene;