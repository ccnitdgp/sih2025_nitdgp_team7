/* eslint-disable @typescript-eslint/no-explicit-any */

import React, { useState, useEffect, useCallback, useRef } from "react";
import { Layout } from "../Layout";
import API from "../../utils/api";


import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./card";
import { Button } from "./button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./dialog";
import { Input } from "./input";
import { Badge } from "./badge";
import { Textarea } from "./textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./select";
import { ScrollArea } from "./scroll-area";
import { Plus, List, User as UserIcon, CheckCircle, Clock, CheckCheck, FileText, TrendingUp, Info, LineChart } from "lucide-react";

import {
    PieChart,
    Pie,
    Cell,
    Tooltip,
    Legend,
    XAxis,
    YAxis,
    CartesianGrid,
    Line,
    LineChart as ReLineChart,
    BarChart
} from "recharts";

interface Project {
    _id: string;
    projectName: string;
    initialDeadline: string;
    managerId: string;
    targetDepartment: string;
}


interface User {
    _id: string;
    name: string;
    dept: string;
}


interface Task {
    _id: string;
    projectId: string;
    assignedToId: string;
    sourceDocumentId: string;
    actionText: string;
    status: 'Pending' | 'Completed' | 'Approved';
    priority: 'High' | 'Medium' | 'Low';
    sourceDeadline: string;
    completionProof?: {
        comment: string;
        filePath: string; // Mock file path
        uploadedAt: string;
    };
    managerComment?: string;
}

// ADD starting at line ~102
interface ChartData {
    name: string;
    value: number;
    color: string;
}

interface Document {
    _id: string;
    title: string;
    dept: string;
    actions: { id: string; text: string; priority: string; sourceDeadline: string }[];
}

interface TaskGroup {
    user: User;
    Pending: Task[];
    Completed: Task[];
    Approved: Task[];
}

// Define the thought process template
const THOUGHT_PROCESS_TEMPLATE = `
## Document Resolution Strategy

1. Primary Goal/Intent:
What is the core objective of this project? (e.g., Achieve 100% compliance with new safety bulletin, Prepare for Q4 external audit.)

2. Key Risks/Challenges:
What are the main potential roadblocks or complex areas in the linked documents that need careful attention? (e.g., Short deadline for high-priority actions, resource constraints.)

3. Allocation Rationale:
Why were the selected documents/actions/users chosen for this project? (i.e., Which part of the document drives the urgency/necessity?)

4. Expected Outcome:
What does a successful project look like? (e.g., All critical tasks Approved by deadline, zero maintenance incidents related to the document.)
---
(Manager's detailed description starts here...)
`;

type GroupedTasks = { [key: string]: TaskGroup };

const MOCK_DEPT = "Finance & Accounts";
const CURRENT_USER_ID = '654321012345678901230011';
const CURRENT_USER_JOB: string = 'Manager'; // 💡 Change to 'Junior Engineer' to test employee view

const MOCK_USERS_DEPT: User[] = [
    { _id: '654321012345678901230011', name: 'Alok Varma (Manager)', dept: MOCK_DEPT },
    { _id: '654321012345678901230012', name: 'Priya Reddy (JE)', dept: MOCK_DEPT },
];
const MOCK_DOCUMENTS_DEPT: Document[] = [
    {
        _id: '654321012345678901230001', title: 'Safety Bulletin 04/25', dept: MOCK_DEPT, actions: [
            { id: 'a1', text: 'Verify brake line pressure on all Kochi fleet trains.', priority: 'High', sourceDeadline: '2026-01-15T00:00:00.000Z' },
            { id: 'a2', text: 'Update maintenance logs for bogie inspection procedure.', priority: 'Medium', sourceDeadline: '2026-01-20T00:00:00.000Z' },
        ]
    },
];
// --- END MOCK/HELPER DATA ---

// Helper to group tasks by user and status
const groupTasks = (tasks: Task[]): GroupedTasks => {
    const uniqueUserIds = [...new Set(tasks.map(t => t.assignedToId))];

    const userMap = MOCK_USERS_DEPT.reduce((acc, user) => { acc[user._id] = user; return acc; }, {} as Record<string, User>);



    const grouped: GroupedTasks = uniqueUserIds.reduce((acc, userId) => {

        const user = userMap[userId] || { _id: userId, name: `User ${userId.substring(0, 8)}`, dept: 'N/A' };



        acc[userId] = {

            user,

            Pending: tasks.filter(t => t.assignedToId === userId && t.status === 'Pending'),

            Completed: tasks.filter(t => t.assignedToId === userId && t.status === 'Completed'),

            Approved: tasks.filter(t => t.assignedToId === userId && t.status === 'Approved'),

        };

        return acc;

    }, {} as GroupedTasks);



    MOCK_USERS_DEPT.forEach(user => {

        if (!grouped[user._id]) {

            grouped[user._id] = { user, Pending: [], Completed: [], Approved: [] };

        }

    });



    return grouped;

};


// MOCK Analytics Modal (Case 1)

const ProjectAnalyticsModal = ({
    isOpen,
    onClose,
    project,
    tasks
}: {
    isOpen: boolean;
    onClose: () => void;
    project: Project;
    tasks: Task[];
}) => {
    const totalTasks = tasks.length;

    const completedTasks =
        tasks.filter(t => t.status === "Completed" || t.status === "Approved").length;

    const approvedTasks =
        tasks.filter(t => t.status === "Approved").length;

    const overallProgress =
        totalTasks > 0 ? Math.round((approvedTasks / totalTasks) * 100) : 0;

    // PIE CHART DATA
    const pieData = [
        { name: "Approved", value: approvedTasks },
        { name: "Completed (Awaiting Approval)", value: completedTasks - approvedTasks },
        { name: "Pending", value: totalTasks - completedTasks }
    ];

    const COLORS = ["#16a34a", "#f59e0b", "#ef4444"];

    // USER PROGRESS CALCULATION
    const users = MOCK_USERS_DEPT;
    const grouped = groupTasks(tasks);

    const getUserProgress = (userId: string) => {
        const g = grouped[userId];
        if (!g) return 0;

        const total = g.Pending.length + g.Completed.length + g.Approved.length;
        if (total === 0) return 0;

        return Math.round((g.Approved.length / total) * 100);
    };

    const getBarColor = (progress: number) => {
        if (progress >= 75) return "bg-green-600";
        if (progress >= 40) return "bg-yellow-500";
        return "bg-red-600";
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-y-auto">

                <DialogHeader>
                    <DialogTitle className="text-2xl flex items-center gap-2 text-primary">
                        <LineChart className="h-6 w-6" /> Analytics: {project.projectName}
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-6">

                    {/* OVERALL PROJECT HEALTH */}
                    <Card>
                        <CardHeader className="p-4">
                            <CardTitle className="text-lg">Overall Project Health</CardTitle>
                        </CardHeader>

                        <CardContent className="flex justify-around items-center text-center">
                            <div>
                                <p className="text-5xl font-bold text-green-600">{overallProgress}%</p>
                                <p className="text-sm text-muted-foreground">Approved Progress</p>
                            </div>

                            <div>
                                <p className="text-3xl font-semibold">{totalTasks}</p>
                                <p className="text-sm text-muted-foreground">Total Actions</p>
                            </div>

                            <div>
                                <p className="text-3xl font-semibold">{approvedTasks}</p>
                                <p className="text-sm text-muted-foreground">Approved</p>
                            </div>

                            <div>
                                <p className="text-3xl font-semibold">{completedTasks - approvedTasks}</p>
                                <p className="text-sm text-muted-foreground">Awaiting Approval</p>
                            </div>
                        </CardContent>
                    </Card>

                    {/* PIE CHART WITH PERCENTAGES */}
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg">Task Status Distribution</CardTitle>
                        </CardHeader>

                        <CardContent className="flex justify-center">
                            <PieChart width={420} height={320}>
                                <Pie
                                    data={pieData}
                                    dataKey="value"
                                    nameKey="name"
                                    cx="50%"
                                    cy="50%"
                                    outerRadius={95}   // slightly smaller to avoid clipping
                                    label={({ name, value }) => {
                                        const total = pieData.reduce((sum, d) => sum + d.value, 0);
                                        const percent = total > 0 ? ((value / total) * 100).toFixed(0) : 0;
                                        return `${name}: ${percent}%`;
                                    }}
                                >

                                    {pieData.map((entry, index) => (
                                        <Cell
                                            key={`cell-${index}`}
                                            fill={COLORS[index % COLORS.length]}
                                        />
                                    ))}
                                </Pie>

                                <Tooltip
                                    formatter={(value: number) => {
                                        const total = pieData.reduce((sum, d) => sum + d.value, 0);
                                        const percent = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                                        return [`${value} (${percent}%)`, ""];
                                    }}
                                />

                                <Legend />
                            </PieChart>
                        </CardContent>
                    </Card>

                    {/* USER PROGRESS BARS */}
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg">User Progress Overview</CardTitle>
                            <CardDescription>
                                Progress is based on Approved actions out of total tasks assigned.
                            </CardDescription>
                        </CardHeader>

                        <CardContent className="space-y-4">
                            {users.map(user => {
                                const progress = getUserProgress(user._id);
                                const barColor = getBarColor(progress);

                                return (
                                    <div key={user._id} className="space-y-1">
                                        <div className="flex justify-between text-sm font-medium">
                                            <span>{user.name}</span>
                                            <span>{progress}%</span>
                                        </div>

                                        <div className="w-full h-3 bg-gray-200 rounded-md overflow-hidden">
                                            <div
                                                className={`h-full ${barColor}`}
                                                style={{ width: `${progress}%` }}
                                            />
                                        </div>
                                    </div>
                                );
                            })}
                        </CardContent>
                    </Card>

                </div>

                <Button onClick={onClose}>Close Analytics</Button>
            </DialogContent>
        </Dialog>
    );
};

// --- Employee Completion Modal (Case 2 & Overall) ---

const EmployeeCompleteModal = ({ isOpen, onClose, task, handleUpdate }: { isOpen: boolean, onClose: () => void, task: Task, handleUpdate: (taskId: string, newStatus: 'Completed', comment?: string, proof?: any) => void }) => {

    const [comment, setComment] = useState('');

    const [file, setFile] = useState<File | null>(null);



    const handleSubmit = () => {

        if (!comment || !file) {

            alert("Comments and proof document upload are required.");

            return;

        }



        console.log(`Submitting proof for Task ${task._id}:`, { comment, fileName: file.name });

        const proofObject = {

            comment: comment,

            filePath: 'mock/path.pdf', // Mocked path

            // uploadedAt is added inside handleTaskUpdateFlow

        };



        // MOCK: Update the task with mock proof and set status to Completed

        // In a real app, this submits to the server, which returns the file path.

        handleUpdate(task._id, 'Completed', comment, proofObject);



        onClose();

    };



    return (

        <Dialog open={isOpen} onOpenChange={onClose}>

            <DialogContent className="sm:max-w-[500px]">

                <DialogHeader>

                    <DialogTitle className="flex items-center gap-2 text-xl text-primary">

                        <CheckCircle className="h-5 w-5" /> Mark Action Completed

                    </DialogTitle>

                    <DialogDescription>

                        Provide proof and comments before submitting for manager approval.

                    </DialogDescription>

                </DialogHeader>



                <div className="space-y-4 py-4">

                    <p className="font-semibold">{task.actionText}</p>



                    <Textarea

                        placeholder="Detailed comments on completion (required)"

                        value={comment}

                        onChange={(e) => setComment(e.target.value)}

                        required

                    />



                    <label className="block text-sm font-medium text-gray-700">Upload Proof Document (PDF/Image)</label>

                    <Input

                        type="file"

                        onChange={(e) => setFile(e.target.files ? e.target.files[0] : null)}

                        required

                        className="py-1"

                    />

                </div>



                <Button onClick={handleSubmit} disabled={!comment || !file}>

                    Submit for Manager Approval

                </Button>

            </DialogContent>

        </Dialog>

    );

};


// --- Manager Review Modal (Manager Rejection) ---

const ManagerReviewModal = ({ isOpen, onClose, task, handleUpdate }: { isOpen: boolean, onClose: () => void, task: Task, handleUpdate: (taskId: string, newStatus: 'Pending' | 'Approved', comment?: string) => void }) => {

    const [managerComment, setManagerComment] = useState(task.managerComment || '');



    const handleReject = () => {

        if (!managerComment) {

            alert("Manager comment is required to reject the task.");

            return;

        }

        // Move back to Pending (clears completion proof on the backend)

        handleUpdate(task._id, 'Pending', managerComment);

        onClose();

    };



    const handleApprove = () => {

        // Approve and keep managerComment (optional)

        handleUpdate(task._id, 'Approved', managerComment);

        onClose();

    };



    return (

        <Dialog open={isOpen} onOpenChange={onClose}>

            <DialogContent className="sm:max-w-[600px]">

                <DialogHeader>

                    <DialogTitle className="text-xl flex items-center gap-2 text-yellow-700">

                        <Info className="h-5 w-5" /> Review & Approval

                    </DialogTitle>

                    <DialogDescription>

                        Action submitted for completion: {task.actionText}

                    </DialogDescription>

                </DialogHeader>



                <ScrollArea className="h-64 pr-4 space-y-3">

                    <h4 className="font-semibold border-b pb-1">Employee Submission</h4>

                    <p className="text-sm text-muted-foreground italic">

                        "{task.completionProof?.comment || "No comment provided."}"

                    </p>

                    <Badge variant="secondary" className="text-xs">

                        Proof File: {task.completionProof?.filePath || "N/A"}

                    </Badge>



                    <h4 className="font-semibold border-b pb-1 pt-3">Manager Feedback</h4>

                    <Textarea

                        placeholder="Add comments for approval or rejection."

                        value={managerComment}

                        onChange={(e) => setManagerComment(e.target.value)}

                    />

                </ScrollArea>



                <div className="flex justify-end gap-3">

                    <Button variant="outline" onClick={handleReject} className="border-red-500 text-red-500 hover:bg-red-50" disabled={!managerComment}>

                        Modify & Move to Pending

                    </Button>

                    <Button onClick={handleApprove} className="bg-green-600 hover:bg-green-700">

                        <CheckCheck className="h-4 w-4 mr-2" /> Final Approve

                    </Button>

                </div>

            </DialogContent>

        </Dialog>

    );

};





// --- Project Creation Form Component ---

const ProjectFormModal = ({ isOpen, onClose, refreshProjects }: { isOpen: boolean, onClose: () => void, refreshProjects: (newId?: string) => void }) => {

    const [projectDetails, setProjectDetails] = useState({

        name: '',

        deadline: '',

        description: THOUGHT_PROCESS_TEMPLATE.trim(),

        department: MOCK_DEPT,

        documents: [] as string[],

        users: [] as string[],

    });

    const [isSaving, setIsSaving] = useState(false);



    const handleSave = async () => {

        if (!projectDetails.name || !projectDetails.deadline || !projectDetails.department) {

            alert("Please fill in project name, deadline, and department.");

            return;

        }



        setIsSaving(true);

        try {

            const payload = {

                projectName: projectDetails.name,

                initialDeadline: projectDetails.deadline,

                projectDescription: projectDetails.description,

                targetDepartment: projectDetails.department,

                relevantDocuments: projectDetails.documents,

            };



            const response = await API.post("/projects", payload);

            alert(`Project "${projectDetails.name}" saved successfully!`);

            refreshProjects(response.data.data._id);

            onClose();

        } catch (error) {

            console.error("Failed to save project:", (error as any).response?.data || error);

            alert("Failed to save project. Check console for details.");

        } finally {

            setIsSaving(false);

            setProjectDetails({ name: '', deadline: '', description: THOUGHT_PROCESS_TEMPLATE.trim(), department: MOCK_DEPT, documents: [], users: [] });

        }

    };



    return (

        <Dialog open={isOpen} onOpenChange={onClose}>

            <DialogContent className="sm:max-w-[750px]">

                <DialogHeader>

                    <DialogTitle className="text-2xl flex items-center gap-2 text-primary">

                        <List className="h-6 w-6" /> Create New Project

                    </DialogTitle>

                </DialogHeader>



                <ScrollArea className="h-[450px] pr-4">

                    <div className="grid gap-4 py-4">

                        {/* 1. Project Details */}

                        <h4 className="font-semibold text-lg border-b pb-1">Project Metadata</h4>

                        <Input placeholder="Project Name (e.g., Q4 Safety Audit Prep)" onChange={e => setProjectDetails({ ...projectDetails, name: e.target.value })} />

                        <div className="grid grid-cols-2 gap-4">

                            <Input type="date" title="Initial Deadline" onChange={e => setProjectDetails({ ...projectDetails, deadline: e.target.value })} />

                            <Select onValueChange={(val) => setProjectDetails({ ...projectDetails, department: val })} defaultValue={MOCK_DEPT}>

                                <SelectTrigger><SelectValue placeholder="Target Department" /></SelectTrigger>

                                <SelectContent><SelectItem value={MOCK_DEPT}>{MOCK_DEPT}</SelectItem></SelectContent>

                            </Select>

                        </div>

                        <Textarea
                            placeholder="Project Description"
                            value={projectDetails.description} // Use the state value
                            onChange={e => setProjectDetails({ ...projectDetails, description: e.target.value })}
                            className="font-mono text-sm h-40" // Add styling for template clarity
                        />


                        {/* 2. Document Selection */}

                        <h4 className="font-semibold text-lg border-b pb-1 mt-4">Link Source Documents</h4>

                        <Select onValueChange={(docId) => setProjectDetails(prev => ({ ...prev, documents: [...prev.documents, docId] }))}>

                            <SelectTrigger>

                                <SelectValue placeholder="Select Documents to Link (Dept Filtered)" />

                            </SelectTrigger>

                            <SelectContent>

                                {MOCK_DOCUMENTS_DEPT.map(doc => (

                                    <SelectItem key={doc._id} value={doc._id}>{doc.title}</SelectItem>

                                ))}

                            </SelectContent>

                        </Select>

                        <div className="flex flex-wrap gap-2">

                            {projectDetails.documents.map(docId => (

                                <Badge key={docId} variant="secondary" className="bg-blue-100 text-blue-800">

                                    <FileText className="h-3 w-3 mr-1" /> {MOCK_DOCUMENTS_DEPT.find(d => d._id === docId)?.title || docId.substring(0, 8) + '...'}

                                </Badge>

                            ))}

                        </div>



                        {/* 3. User Assignment */}

                        <h4 className="font-semibold text-lg border-b pb-1 mt-4">Assign Team Members</h4>

                        <Select onValueChange={(userId) => setProjectDetails(prev => ({ ...prev, users: [...prev.users, userId] }))}>

                            <SelectTrigger>

                                <SelectValue placeholder="Select Users (Same Department Only)" />

                            </SelectTrigger>

                            <SelectContent>

                                {MOCK_USERS_DEPT.map(user => (

                                    <SelectItem key={user._id} value={user._id}>{user.name}</SelectItem>

                                ))}

                            </SelectContent>

                        </Select>

                        <div className="flex flex-wrap gap-2">

                            {projectDetails.users.map(userId => (

                                <Badge key={userId} variant="outline">

                                    <UserIcon className="h-3 w-3 mr-1" /> {MOCK_USERS_DEPT.find(u => u._id === userId)?.name || userId.substring(0, 8) + '...'}

                                </Badge>

                            ))}

                        </div>

                    </div>

                </ScrollArea>



                <Button onClick={handleSave} className="mt-4" disabled={isSaving}>

                    {isSaving ? "Saving..." : "Save Project to Database"}

                </Button>

            </DialogContent>

        </Dialog>

    );

};





// --- Task Assignment Modal ---

const AssignActionModal = ({ isOpen, onClose, userId, projectId, refreshTasks }: { isOpen: boolean, onClose: () => void, userId: string, projectId: string, refreshTasks: (id: string) => void }) => {

    const user = MOCK_USERS_DEPT.find(u => u._id === userId);

    const [selectedDocId, setSelectedDocId] = useState(MOCK_DOCUMENTS_DEPT[0]?._id || '');

    const [selectedActionId, setSelectedActionId] = useState(MOCK_DOCUMENTS_DEPT[0]?.actions[0]?.id || '');

    const [isAssigning, setIsAssigning] = useState(false);



    const doc = MOCK_DOCUMENTS_DEPT.find(d => d._id === selectedDocId);

    const action = doc?.actions.find(a => a.id === selectedActionId);



    const handleAssign = async () => {

        if (!action || !user || !projectId) return;



        setIsAssigning(true);

        try {

            const payload = {

                projectId: projectId,

                assignedToId: userId,

                sourceDocumentId: selectedDocId,

                actionText: action.text,

                sourceDeadline: action.sourceDeadline,

                status: 'Pending',

                priority: action.priority,

            };



            await API.post("/tasks", payload);

            alert(`Action assigned to ${user.name}!`);

            refreshTasks(projectId);

            onClose();

        } catch (error) {

            console.error("Failed to assign task:", (error as any).response?.data || error);

            alert("Failed to assign task. Check console.");

        } finally {

            setIsAssigning(false);

        }

    };



    return (

        <Dialog open={isOpen} onOpenChange={onClose}>

            <DialogContent className="sm:max-w-[500px]">

                <DialogHeader>

                    <DialogTitle className="flex items-center gap-2 text-primary">

                        <Plus className="h-5 w-5" /> Assign Document Action to {user?.name}

                    </DialogTitle>

                    <DialogDescription>

                        Select an extracted action from a linked document and assign it as a task.

                    </DialogDescription>

                </DialogHeader>



                <div className="grid gap-4 py-4">

                    {/* 1. Document Selection (Mocks filtered documents linked to the project) */}

                    <Select onValueChange={setSelectedDocId} value={selectedDocId}>

                        <SelectTrigger><SelectValue placeholder="Select Source Document" /></SelectTrigger>

                        <SelectContent>

                            {MOCK_DOCUMENTS_DEPT.map(doc => (

                                <SelectItem key={doc._id} value={doc._id}>{doc.title}</SelectItem>

                            ))}

                        </SelectContent>

                    </Select>



                    {/* 2. Action Selection */}

                    <Select onValueChange={setSelectedActionId} value={selectedActionId}>

                        <SelectTrigger><SelectValue placeholder="Select Action Required" /></SelectTrigger>

                        <SelectContent>

                            {doc?.actions.map(a => (

                                <SelectItem key={a.id} value={a.id}>

                                    {a.text} <Badge variant={a.priority === 'High' ? 'destructive' : 'default'} className="ml-2">{a.priority}</Badge>

                                </SelectItem>

                            ))}

                        </SelectContent>

                    </Select>



                    {action && <p className="text-sm text-gray-600 mt-2 p-2 border rounded-md bg-muted">Priority: {action.priority}</p>}

                </div>



                <Button onClick={handleAssign} disabled={isAssigning}>

                    {isAssigning ? "Assigning..." : "Assign Action as Task"}

                </Button>

            </DialogContent>

        </Dialog>

    );

};





// --- Main Task/Project Board Component ---

const ProjectBoard = () => {

    const isManager = (CURRENT_USER_JOB === 'Manager');

    const isEmployee = (CURRENT_USER_JOB === 'Junior Engineer');

    const currentUserId = CURRENT_USER_ID;



    const [isFormOpen, setIsFormOpen] = useState(false);

    const [tasks, setTasks] = useState<Task[]>([]);

    const [projects, setProjects] = useState<Project[]>([]);

    const [selectedProject, setSelectedProject] = useState<Project | null>(null);

    const [loadingProjects, setLoadingProjects] = useState(true);

    const [loadingTasks, setLoadingTasks] = useState(false);



    // Modal States

    const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);

    const [targetUserId, setTargetUserId] = useState('');

    const [isCompleteModalOpen, setIsCompleteModalOpen] = useState(false);

    const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);

    const [selectedTask, setSelectedTask] = useState<Task | null>(null);

    const [isAnalyticsModalOpen, setIsAnalyticsModalOpen] = useState(false);





    // --- API HANDLERS ---



    const fetchProjects = useCallback(async (newProjectIdToSelect: string | null = null) => {

        setLoadingProjects(true);

        try {

            const response = await API.get("/projects/my-projects");

            const fetchedProjects = response.data.data as Project[];

            setProjects(fetchedProjects);



            if (fetchedProjects.length > 0) {

                const projectToSelect = fetchedProjects.find(p => p._id === newProjectIdToSelect) || fetchedProjects[0];

                setSelectedProject(projectToSelect);

            } else {

                setSelectedProject(null);

                setTasks([]);

            }

        } catch (error) {

            console.error("Failed to fetch manager projects:", (error as any).response?.data || error);

        } finally {

            setLoadingProjects(false);

        }

    }, []);



    const fetchTasks = useCallback(async (projectId: string) => {

        if (!projectId) return;

        setLoadingTasks(true);

        try {

            const response = await API.get(`/tasks/${projectId}`);

            // 💡 Mocked data now includes sourceDocumentId

            setTasks(response.data.data as Task[]);

        } catch (error) {

            console.error(`Failed to fetch tasks for project ${projectId}:`, (error as any).response?.data || error);

            setTasks([]);

        } finally {

            setLoadingTasks(false);

        }

    }, []);



    // 💡 Overall Flow Update: Task movement handler (now handles proof/rejection/approval)

    const handleTaskUpdateFlow = useCallback(async (

        taskId: string,

        newStatus: 'Pending' | 'Completed' | 'Approved',

        comment?: string,

        proof?: { filePath: string, comment: string } // Used for Employee flow

    ) => {

        const updatePayload: any = { status: newStatus };



        // 1. Prepare Payload based on Status

        if (newStatus === 'Completed' && proof) {

            const fullProof = {

                ...proof,

                uploadedAt: new Date().toISOString()

            };

            updatePayload.completionProof = fullProof;

            // Optimistic update for UI feedback

            setTasks(prev => prev.map(t =>

                t._id === taskId ? { ...t, status: newStatus, completionProof: fullProof } : t

            ));

        } else if (newStatus === 'Pending' && comment) {

            // Manager Rejection: Move back to Pending and store comment

            updatePayload.managerComment = comment;

            updatePayload.completionProof = undefined; // Clear proof upon rejection

        } else if (newStatus === 'Approved') {

            // Manager Approval: Store manager comment if available

            updatePayload.managerComment = comment;

        }



        // 2. Call API

        try {

            const response = await API.patch(`/tasks/${taskId}/status`, updatePayload);

            console.log(`Task status set to ${newStatus}.`, response.data.data);



            // Re-fetch to synchronize state after API update

            if (selectedProject) fetchTasks(selectedProject._id);



        } catch (error) {

            console.error("Failed to update task status:", (error as any).response?.data || error);

            alert(`Failed to update task status: ${newStatus}. See console.`);

        }

    }, [selectedProject, fetchTasks]);



    // --- INITIAL DATA LOADING ---

    useEffect(() => {

        fetchProjects();

    }, [fetchProjects]);



    useEffect(() => {

        if (selectedProject) {

            fetchTasks(selectedProject._id);

        }

    }, [selectedProject, fetchTasks]);





    // --- VIEW DATA PREPARATION ---

    const groupedTasks = groupTasks(tasks);

    const boardUsers = Object.values(groupedTasks).map(group => group.user);



    // Renders a single task card

    const TaskCard = ({ task }: { task: Task }) => {

        const isAssignedToCurrentUser = task.assignedToId === currentUserId;

        const getDocTitle = (docId: string) => MOCK_DOCUMENTS_DEPT.find(d => d._id === docId)?.title || `Doc ID: ${docId.substring(0, 8)}...`;



        return (

            <Card className="p-3 mb-2 shadow-sm border-l-4 border-primary/50">

                <p className={`text-sm font-medium ${task.status === 'Approved' ? 'line-through text-gray-500' : 'text-foreground'}`}>

                    {task.actionText}

                </p>

                <div className="flex justify-between items-center text-xs text-muted-foreground mt-1">

                    <span className="flex items-center gap-1">

                        <Clock className="h-3 w-3" /> Deadline: {task.sourceDeadline ? new Date(task.sourceDeadline).toLocaleDateString() : 'N/A'}

                    </span>

                    <Badge variant={task.priority === 'High' ? 'destructive' : 'default'} className="h-4">

                        {task.priority || 'Medium'}

                    </Badge>

                </div>

                <p className="text-[10px] text-gray-500 truncate">Source: {getDocTitle(task.sourceDocumentId)}</p>



                {/* Action Buttons & Status Indicators */}

                <div className="flex gap-1 mt-2">



                    {/* 1. Employee Action: COMPLETE (If Pending and assigned to current user) */}

                    {task.status === 'Pending' && isEmployee && isAssignedToCurrentUser && (

                        <Button

                            variant="outline"

                            size="sm"

                            onClick={() => { setSelectedTask(task); setIsCompleteModalOpen(true); }}

                        >

                            Mark Completed

                        </Button>

                    )}



                    {/* 2. Manager Action: REVIEW (If Completed and Manager) */}

                    {task.status === 'Completed' && isManager && (

                        <Button

                            variant="default" // Fixed variant

                            size="sm"

                            onClick={() => { setSelectedTask(task); setIsReviewModalOpen(true); }}

                            className="bg-yellow-500 hover:bg-yellow-600 text-white" // Warning color

                        >

                            Review & Approve

                        </Button>

                    )}



                    {/* 3. Approved/Review Badge */}

                    {task.status === 'Approved' && (

                        <Badge variant="outline" className="bg-green-100 text-green-700">

                            <CheckCheck className="h-3 w-3 mr-1" /> Approved

                        </Badge>

                    )}



                    {/* If Employee is Assigned and task is COMPLETED, show status */}

                    {task.status === 'Completed' && isEmployee && isAssignedToCurrentUser && (

                        <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">

                            Awaiting Approval

                        </Badge>

                    )}

                </div>

            </Card>

        );

    };





    return (

        <Layout>

            <div className="space-y-4">

                <h1 className="text-3xl font-bold">Document-Driven Project Board</h1>

                <p className="text-muted-foreground">User Role: {CURRENT_USER_JOB} | Manage tasks derived from critical KMRL documents and assign them to your team.</p>

            </div>



            <div className="grid grid-cols-12 gap-6 mt-6">



                {/* --- LEFT SIDE (70%): Task Board --- */}

                <div className="col-span-9 space-y-4">

                    <div className="flex justify-between items-center">

                        <h2 className="text-2xl font-semibold">

                            Active Project: {selectedProject?.projectName || "Select a Project"}

                        </h2>

                        {isManager && ( // Case 2: Only show button for Manager

                            <div className="flex gap-2">

                                <Button variant="secondary" onClick={() => selectedProject && setIsAnalyticsModalOpen(true)}>

                                    <BarChart className="h-4 w-4 mr-2" /> View Analytics

                                </Button>

                                <Button onClick={() => setIsFormOpen(true)}>

                                    <Plus className="h-4 w-4 mr-2" /> Add New Project

                                </Button>

                            </div>

                        )}

                    </div>



                    {/* Task Board Grid */}

                    {selectedProject ? (

                        <div className="space-y-8">

                            {boardUsers.length > 0 ? (

                                boardUsers.map(user => (

                                    // 💡 EMPLOYEE VIEW: Only show row if manager OR if tasks are assigned to the current employee

                                    (isManager || groupedTasks[user._id]?.Pending.length > 0 || groupedTasks[user._id]?.Completed.length > 0) && (

                                        <div key={user._id}>

                                            <h3 className="text-xl font-bold border-b pb-1 mb-3 flex items-center gap-2">

                                                <UserIcon className="h-5 w-5 text-gray-600" /> {user.name}

                                                <Badge variant="secondary" className="text-xs">{user.dept}</Badge>

                                            </h3>



                                            <div className="grid grid-cols-3 gap-4">

                                                {/* Column 1: PENDING */}

                                                <Card>

                                                    <CardHeader className="bg-red-50 p-3 border-b">

                                                        <CardTitle className="text-lg flex justify-between items-center text-red-700">

                                                            Pending

                                                            {isManager && ( // Case 2: Only manager can see '+'

                                                                <Button

                                                                    variant="ghost"

                                                                    size="icon"

                                                                    onClick={() => { setTargetUserId(user._id); setIsAssignModalOpen(true); }}

                                                                    title={`Assign task to ${user.name}`}

                                                                >

                                                                    <Plus className="h-4 w-4 text-red-700" />

                                                                </Button>

                                                            )}

                                                        </CardTitle>

                                                    </CardHeader>

                                                    <CardContent className="p-3 min-h-[100px]">

                                                        {groupedTasks[user._id]?.Pending.map(task => <TaskCard key={task._id} task={task} />)}

                                                        {groupedTasks[user._id]?.Pending.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No tasks pending.</p>}

                                                    </CardContent>

                                                </Card>



                                                {/* Column 2: COMPLETED */}

                                                <Card>

                                                    <CardHeader className="bg-yellow-50 p-3 border-b">

                                                        <CardTitle className="text-lg flex items-center text-yellow-700">

                                                            <CheckCircle className="h-5 w-5 mr-2" /> Completed

                                                        </CardTitle>

                                                    </CardHeader>

                                                    <CardContent className="p-3 min-h-[100px]">

                                                        {groupedTasks[user._id]?.Completed.map(task => <TaskCard key={task._id} task={task} />)}

                                                        {groupedTasks[user._id]?.Completed.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">Awaiting completion.</p>}

                                                    </CardContent>

                                                </Card>



                                                {/* Column 3: APPROVED */}

                                                <Card>

                                                    <CardHeader className="bg-green-50 p-3 border-b">

                                                        <CardTitle className="text-lg flex items-center text-green-700">

                                                            <CheckCheck className="h-5 w-5 mr-2" /> Approved

                                                        </CardTitle>

                                                    </CardHeader>

                                                    <CardContent className="p-3 min-h-[100px]">

                                                        {groupedTasks[user._id]?.Approved.map(task => <TaskCard key={task._id} task={task} />)}

                                                        {groupedTasks[user._id]?.Approved.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">Awaiting approval.</p>}

                                                    </CardContent>

                                                </Card>

                                            </div>

                                        </div>

                                    )

                                ))

                            ) : (

                                <p className="p-10 text-center text-lg text-muted-foreground">No assigned tasks in this project.</p>

                            )}

                        </div>

                    ) : (

                        <p className="p-10 text-center text-xl text-muted-foreground">

                            {loadingProjects ? "Loading projects..." : "No active projects found. Click 'Add New Project' to begin."}

                        </p>

                    )}

                </div>



                {/* --- RIGHT SIDE (30%): Project List --- */}

                <div className="col-span-3">

                    <Card className="shadow-lg">

                        <CardHeader>

                            <CardTitle className="text-xl">My Projects</CardTitle>

                            <CardDescription>Select a project to view its tasks.</CardDescription>

                        </CardHeader>

                        <CardContent className="space-y-2">

                            {loadingProjects ? (

                                <p className="text-sm text-center text-muted-foreground">Loading...</p>

                            ) : projects.length === 0 ? (

                                <p className="text-sm text-center text-muted-foreground">No projects created yet.</p>

                            ) : (

                                projects.map(project => (

                                    <div

                                        key={project._id}

                                        onClick={() => setSelectedProject(project)}

                                        className={`p-3 border rounded-lg cursor-pointer transition-all ${selectedProject?._id === project._id ? 'bg-primary/10 border-primary' : 'hover:bg-muted'}`}

                                    >

                                        <p className="font-semibold">{project.projectName}</p>

                                        <p className="text-xs text-muted-foreground flex items-center">

                                            <Clock className="h-3 w-3 mr-1" /> Deadline: {new Date(project.initialDeadline).toLocaleDateString()}

                                        </p>

                                    </div>

                                ))

                            )}

                        </CardContent>

                    </Card>

                </div>

            </div>



            {/* --- MODALS --- */}



            {/* 1. Manager: Add Project */}

            {isManager && (

                <ProjectFormModal

                    isOpen={isFormOpen}

                    onClose={() => setIsFormOpen(false)}

                    refreshProjects={fetchProjects}

                />

            )}



            {/* 2. Manager: Assign Task */}

            {isManager && isAssignModalOpen && selectedProject && targetUserId && (

                <AssignActionModal

                    isOpen={isAssignModalOpen}

                    onClose={() => setIsAssignModalOpen(false)}

                    userId={targetUserId}

                    projectId={selectedProject._id}

                    refreshTasks={fetchTasks}

                />

            )}



            {/* 3. Employee: Mark Completed (Requires Proof) */}

            {isCompleteModalOpen && selectedTask && (

                <EmployeeCompleteModal

                    isOpen={isCompleteModalOpen}

                    onClose={() => setIsCompleteModalOpen(false)}

                    task={selectedTask}

                    handleUpdate={handleTaskUpdateFlow}

                />

            )}



            {/* 4. Manager: Review & Reject/Approve */}

            {isManager && isReviewModalOpen && selectedTask && (

                <ManagerReviewModal

                    isOpen={isReviewModalOpen}

                    onClose={() => setIsReviewModalOpen(false)}

                    task={selectedTask}

                    handleUpdate={handleTaskUpdateFlow}

                />

            )}



            {/* 5. Manager: Analytics */}

            {isManager && isAnalyticsModalOpen && selectedProject && (

                <ProjectAnalyticsModal

                    isOpen={isAnalyticsModalOpen}

                    onClose={() => setIsAnalyticsModalOpen(false)}

                    project={selectedProject}

                    tasks={tasks}

                />

            )}

        </Layout>

    );

};

export default ProjectBoard;