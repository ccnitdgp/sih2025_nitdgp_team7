// src/pages/CalendarPage.jsx (New Dedicated Page)

import { Layout } from "@/components/Layout";
import { useEffect, useState, useCallback } from "react";
import API from "../../utils/api";
import SimpleActionCalendar from "./homeCalendar"; 
import { Calendar as CalendarIcon } from "lucide-react";


const CalendarPage = () => {
    const [documents, setDocuments] = useState([]); 
    const [loading, setLoading] = useState(true);

    // This function must replicate the fetching and transformation 
    // from your original Documents page to get the 'allActions' array.
    const fetchAndTransformDocuments = useCallback(async () => {
        setLoading(true);
        try {
            // --- 1. Fetching Data ---
            const generalResponse = await API.get("/messages/search", { params: { dateRange: 'alltime' } }); 
            const maximoResponse = await API.get("messages/maximo/documents", { params: {} });
            const allFetchedData = [...generalResponse.data, ...maximoResponse.data];
            
            // --- 2. Transforming Data (Necessary to populate 'allActions') ---
            const transformedDocs = allFetchedData.map(doc => {
                 const isGmail = doc.source === "gmail";
                 const isMaximo = doc.source === "MAXIMO";
                 
                 let rawActions = [];
                 if (isGmail) {
                    rawActions = doc.analysis?.raw.data?.actions_required || [];
                 } else if (isMaximo) {
                    rawActions = doc.raw_analysis?.data?.actions_required || [];
                 } else { // WhatsApp, Drive, etc.
                    rawActions = doc.analysis?.raw.data?.actions_required || [];
                 }
                 
                 let name = "Untitled";
                 if (isGmail) name = doc.subject || "Untitled Email";
                 else if (isMaximo) name = doc.title || `Maximo Document: ${doc.source_id}`;
                 else name = doc.fileName || "Untitled Document";

                 // Return only the minimal fields needed for the calendar helper
                 return { 
                    id: doc._id || doc.source_id, 
                    name, 
                    allActions: rawActions, // Crucial for calendar events
                    source: doc.source 
                 };
            });

            setDocuments(transformedDocs);
        } catch (error) {
            console.error("Failed to fetch documents for calendar:", error);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchAndTransformDocuments();
    }, [fetchAndTransformDocuments]);

    return (
                <div className="space-y-6">
                <h1 className="text-3xl font-bold flex items-center gap-2">
                    <CalendarIcon className="h-7 w-7 text-primary" /> Action Deadlines Calendar
                </h1>
                <p className="text-muted-foreground"> Visualize all required action deadlines across your systems (Messages, Email, Maximo). </p>
                
                {/* Use the simpler, native component */}
                <SimpleActionCalendar documentsData={documents} loading={loading} />
            </div>
    );
};

export default CalendarPage;