import React, { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API from "../../utils/api"
import { User, Shield, Clock, Upload, Edit, Save, Settings, Lock, Bell, Users, Landmark, ChevronLeft, Briefcase } from 'lucide-react';

// 1. IMPORT THE IMAGE FILE FROM YOUR ASSETS FOLDER
import hierarchyImage from '@/assets/hierarchy_chart.png';

// 2. USE THE IMPORTED MODULE AS THE URL SOURCE
const HIERARCHY_CHART_URL = hierarchyImage;

interface UserType {
    id: string;
    fullName: string;
    email: string;
    picture?: string;
    profileCompleted: boolean;
    jobTitle: string;
    employeeId: string;
    workLocation: string;
    department: string;
    preferredLanguage: string;
    phoneNumber: string;
    role: string;
    lastLogin: string;
    status: string;
    uploadsCount: number;
    is2FAEnabled: boolean;
    profilePicUrl: string;
}

const Card = ({ children, className = '' }: { children: React.ReactNode, className?: string }) => (
    <div className={`bg-[hsl(var(--card))] p-6 rounded-[var(--radius)] shadow-soft ${className}`}>
        {children}
    </div>
);

const ProfileStatCard = ({ title, value, icon: Icon, comparison = '' }: {
    title: string, value: string, icon: React.ComponentType<{ className?: string }>
        , comparison?: string
}) => (<Card className="flex flex-col space-y-2 h-full">
    <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-[hsl(var(--muted-foreground))]">{title}</h3>
        <Icon className="w-5 h-5 text-[hsl(var(--primary-dark))]" />
    </div>
    <p className="text-2xl font-bold text-[hsl(var(--foreground))]">{value}</p>
    {comparison && (
        <p className="text-xs text-[hsl(var(--success))] font-semibold mt-1">
            {comparison}
        </p>
    )}
</Card>
);

// --- Hierarchy Modal Component ---
const HierarchyModal = ({ isOpen, onClose, imageUrl }: { isOpen: boolean, onClose: () => void, imageUrl: string }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 sm:p-8">
            <div className="bg-[hsl(var(--background))] rounded-[var(--radius)] shadow-elevated w-full max-w-5xl h-full max-h-[90vh] overflow-hidden flex flex-col">
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b border-[hsl(var(--border))]">
                    <h2 className="text-xl font-bold text-[hsl(var(--foreground))] flex items-center">
                        <Users className="w-5 h-5 mr-3 text-[hsl(var(--primary))]" />
                        Organizational Hierarchy
                    </h2>
                    <button
                        onClick={onClose}
                        className="p-2 rounded-full text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))] transition-fast"
                        aria-label="Close hierarchy chart"
                    >
                        <ChevronLeft className="w-6 h-6 rotate-90" />
                    </button>
                </div>

                {/* Content: Image */}
                <div className="flex-1 overflow-y-auto p-4 sm:p-6 text-center">
                    <p className="text-sm text-[hsl(var(--muted-foreground))] mb-4">
                        View the reporting structure.
                    </p>
                    {/* The image is loaded here using the imported path */}
                    <img
                        src={imageUrl}
                        alt="Organizational Hierarchy Chart"
                        className="w-full h-auto object-contain rounded-[var(--radius)] shadow-lg"
                        style={{ maxWidth: '100%', maxHeight: '100%' }}
                    />
                </div>
            </div>
        </div>
    );
};
// --- End Hierarchy Modal Component ---


type GenericChangeHandler = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;

const DetailField = ({ label, value, name, type = 'text', onChange, isEditing, required = false }: { label: string, value: string, name: keyof UserType, type?: string, onChange: GenericChangeHandler, isEditing: boolean, required?: boolean }) => (
    <div className="flex flex-col sm:flex-row sm:items-center py-3 border-b border-[hsl(var(--border))] last:border-b-0">
        <label htmlFor={name} className="w-full sm:w-1/3 text-sm font-medium text-[hsl(var(--muted-foreground))] mb-1 sm:mb-0">
            {label}
            {required && <span className="text-[hsl(var(--destructive))] ml-1">*</span>}
        </label>
        <div className="w-full sm:w-2/3">
            {isEditing ? (
                <input
                    type={type}
                    id={name}
                    name={name as string}
                    value={value}
                    onChange={onChange as (e: React.ChangeEvent<HTMLInputElement>) => void}
                    required={required}
                    className="w-full border border-[hsl(var(--input))] rounded-[var(--radius)] p-2 text-sm focus:ring-2 focus:ring-[hsl(var(--ring))] focus:border-[hsl(var(--primary))] transition duration-150"
                    disabled={!isEditing && label === "Email Address"}
                />
            ) : (
                <p className="text-sm text-[hsl(var(--foreground))] font-medium">{value || 'N/A'}</p>
            )}
        </div>
    </div>
);

const DetailSelect = ({ label, value, name, options, onChange, isEditing, required = false }: { label: string, value: string, name: keyof UserType, options: { value: string, label: string }[], onChange: GenericChangeHandler, isEditing: boolean, required?: boolean }) => (
    <div className="flex flex-col sm:flex-row sm:items-center py-3 border-b border-[hsl(var(--border))] last:border-b-0">
        <label htmlFor={name} className="w-full sm:w-1/3 text-sm font-medium text-[hsl(var(--muted-foreground))] mb-1 sm:mb-0">
            {label}
            {required && <span className="text-[hsl(var(--destructive))] ml-1">*</span>}
        </label>
        <div className="w-full sm:w-2/3">
            {isEditing ? (
                <div className="relative">
                    <select
                        id={name}
                        name={name as string}
                        value={value}
                        onChange={onChange as (e: React.ChangeEvent<HTMLSelectElement>) => void} // Cast specific element type here
                        required={required}
                        className="w-full border border-[hsl(var(--input))] rounded-[var(--radius)] p-2 text-sm focus:ring-2 focus:ring-[hsl(var(--ring))] focus:border-[hsl(var(--primary))] transition duration-150 appearance-none bg-white pr-8"
                    >
                        {options.map(option => (
                            <option key={option.value} value={option.value}>{option.label}</option>
                        ))}
                    </select>
                    <Landmark className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--muted-foreground))]" />
                </div>
            ) : (
                <p className="text-sm text-[hsl(var(--foreground))] font-medium">{value || 'N/A'}</p>
            )}
        </div>
    </div>
);

// --- Main Component ---

const ProfileComp = () => {
    const navigate = useNavigate();

    const [userData, setUserData] = useState<UserType | null>(null);
    const [editableData, setEditableData] = useState<Partial<UserType> | null>(null);
    const [isLoadingInitial, setIsLoadingInitial] = useState(true);

    const [isEditing, setIsEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');

    const [showHierarchyModal, setShowHierarchyModal] = useState(false); // Hierarchy state

    const isMandatorySetup = userData ? !userData.profileCompleted : false;

    useEffect(() => {
        const loadUser = async () => {
            try {
                const response = await API.get('/gmail/auth/me');
                const fetchedUser = response.data;

                if (!fetchedUser || !fetchedUser.loggedIn) {
                    setIsLoadingInitial(false);
                    return;
                }

                const mappedData: UserType = {
                    id: fetchedUser._id || 'user-001',
                    fullName: fetchedUser.name || '',
                    email: fetchedUser.email || '',
                    picture: fetchedUser.picture,
                    profileCompleted: fetchedUser.profileCompleted || false,
                    jobTitle: fetchedUser.jobTitle || '',
                    employeeId: fetchedUser.employeeId || '',
                    workLocation: fetchedUser.workLocation || '',
                    department: fetchedUser.department || '',
                    preferredLanguage: fetchedUser.preferredLanguage || 'English',
                    phoneNumber: fetchedUser.phoneNumber || '',
                    role: fetchedUser.profileCompleted ? (fetchedUser.jobTitle || 'User') : 'Pending',
                    lastLogin: new Date().toLocaleDateString() + " at " + new Date().toLocaleTimeString(),
                    status: fetchedUser.profileCompleted ? 'Active' : 'Pending Setup',
                    uploadsCount: fetchedUser.uploadsCount || 0,
                    is2FAEnabled: fetchedUser.is2FAEnabled || false,
                    profilePicUrl: fetchedUser.picture || 'https://placehold.co/100x100/4F46E5/ffffff?text=JD',
                };

                setUserData(mappedData);
                setEditableData(mappedData);

                if (!mappedData.profileCompleted) {
                    setIsEditing(true);
                }
            } catch (error) {
                console.error("Failed to fetch user data:", error);
            } finally {
                setIsLoadingInitial(false);
            }
        };
        loadUser();
    }, []);

    const handleInputChange: GenericChangeHandler = useCallback((e) => {
        const { name, value } = e.target;
        setEditableData(prev => ({ ...prev, [name]: value }));
        setErrorMessage('');
    }, []);

    const handleSave = useCallback(async () => {
        setErrorMessage('');

        if (!editableData) return;
        if (!editableData.jobTitle || !editableData.employeeId || !editableData.workLocation || !editableData.department) {
            setErrorMessage('Please fill in all mandatory organizational fields (Job Title, Employee ID, Department, Work Location).');
            return;
        }

        setIsLoading(true);

        try {
            const response = await API.put('/gmail/auth/profile', editableData);
            const finalData: UserType = {
                ...(userData as UserType),
                ...editableData,
                profileCompleted: true,
                status: 'Active',
                role: editableData.jobTitle || 'User',
            } as UserType;

            setUserData(finalData);
            setIsEditing(false);

            if (isMandatorySetup) {
                navigate('/');
            }
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
        } catch (error: any) {
            console.error("Profile save failed:", error.response?.data || error);
            setErrorMessage(error.response?.data?.error || 'Failed to save profile. Please try again.');
        } finally {
            setIsLoading(false);
        }
    }, [editableData, isMandatorySetup, navigate, userData]);

    const handleCancel = useCallback(() => {
        if (isMandatorySetup) {
            setErrorMessage('Profile completion is mandatory. Please fill in the required details.');
            return;
        }
        setEditableData(userData);
        setIsEditing(false);
        setErrorMessage('');
    }, [userData, isMandatorySetup]);

    const languageOptions = [
        { value: 'English', label: 'English' },
        { value: 'Malayalam', label: 'Malayalam' },
        { value: 'Bilingual (English/Malayalam)', label: 'Bilingual (English/Malayalam)' },
    ];

    if (isLoadingInitial || !userData) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-[hsl(var(--background))]">
                <div className="flex items-center space-x-3 text-[hsl(var(--primary))] font-semibold text-lg">
                    <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Loading user data...</span>
                </div>
                {/* 4. Render the Modal (Needs to be here too if there's any chance of quick action) */}
            </div>
        );
    }

    const profileStats = [
        { title: 'User Role', value: userData.role, icon: Users, comparison: 'Internal permissions' },
        { title: 'Last Login', value: userData.lastLogin.split(' at ')[0], icon: Clock, comparison: 'Most recent activity' },
        { title: 'Account Status', value: userData.status, icon: Shield, comparison: userData.profileCompleted ? 'Verified & Secure' : 'Incomplete setup' },
        { title: 'Total Uploads', value: `${userData.uploadsCount} Files`, icon: Upload, comparison: '+5 vs last month' },
    ];

    const currentEditableData = editableData as UserType;

    return (
        <div className="min-h-screen bg-[hsl(var(--background))] p-4 sm:p-8 font-[var(--font-body)]">
            <div className="gradient-primary text-[hsl(var(--primary-foreground))] rounded-[var(--radius)] shadow-elevated p-6 sm:p-10 mb-8 relative overflow-hidden">
                <div className="relative z-10 flex flex-col sm:flex-row justify-between items-start sm:items-center">
                    <div>
                        <h1 className="text-3xl sm:text-4xl tracking-tight mb-2 font-[var(--font-heading)]">
                            {isMandatorySetup ? 'Mandatory Profile Setup' : 'My Profile'}
                        </h1>
                        <p className="text-[hsl(var(--primary-foreground))]/80 text-lg">
                            {isMandatorySetup
                                ? 'Please complete the organizational details to activate your DocHub account.'
                                : 'Manage your personal information, security, and preferences.'
                            }
                        </p>

                        {/* 3. Hierarchy Button Placement */}
                        <button
                            onClick={() => setShowHierarchyModal(true)}
                            className="mt-4 px-4 py-2 bg-[hsl(var(--surface))] text-[hsl(var(--primary))] font-semibold rounded-full shadow-md hover:bg-[hsl(var(--surface-muted))] transition-fast flex items-center text-sm"
                        >
                            <Briefcase className="w-4 h-4 mr-2" />
                            View Hierarchy
                        </button>

                    </div>
                    {!isEditing && !isMandatorySetup && (
                        <button
                            onClick={() => setIsEditing(true)}
                            className="mt-4 sm:mt-0 px-6 py-2 bg-[hsl(var(--surface))] text-[hsl(var(--primary))] font-semibold rounded-full shadow-md hover:bg-[hsl(var(--surface-muted))] transition-fast flex items-center"
                        >
                            <Edit className="w-4 h-4 mr-2" />
                            Edit Profile
                        </button>
                    )}
                </div>
            </div>

            {errorMessage && (
                <div className="bg-[hsl(var(--destructive)/0.1)] border border-[hsl(var(--destructive))] text-[hsl(var(--destructive))] p-3 rounded-[var(--radius)] mb-6 font-medium">
                    {errorMessage}
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {profileStats.map((stat, index) => (
                    <ProfileStatCard key={index} {...stat} />
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Account Details Card */}
                <div className="lg:col-span-2">
                    <Card className="p-8">
                        <h2 className="text-xl font-bold text-[hsl(var(--foreground))] border-b border-[hsl(var(--border))] pb-4 mb-6 flex items-center">
                            <User className="w-5 h-5 mr-3 text-[hsl(var(--primary))]" />
                            Personal & Organizational Information
                        </h2>

                        {/* Profile Picture Section*/}
                        <div className="flex flex-col sm:flex-row items-center mb-8 pb-4 border-b border-[hsl(var(--border))]">
                            <img
                                src={userData.profilePicUrl}
                                alt="Profile"
                                className="w-24 h-24 rounded-full object-cover ring-4 ring-[hsl(var(--primary-light))]/50 mb-4 sm:mb-0"
                            />
                            {isEditing && (
                                <div className="sm:ml-8">
                                    <button
                                        className="px-4 py-2 bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] text-sm font-medium rounded-full hover:bg-[hsl(var(--primary-dark))] transition-fast shadow-md"
                                    >
                                        Change Photo
                                    </button>
                                    <p className="text-xs text-[hsl(var(--muted-foreground))] mt-1">PNG, JPG up to 5MB</p>
                                </div>
                            )}
                        </div>

                        <div className="space-y-2">
                            <DetailField
                                label="Full Name"
                                value={currentEditableData.fullName}
                                name="fullName"
                                onChange={handleInputChange}
                                isEditing={isEditing}
                                required={false}
                            />
                            <DetailField
                                label="Email Address"
                                value={currentEditableData.email}
                                name="email"
                                type="email"
                                onChange={handleInputChange}
                                isEditing={isEditing}
                            />
                            <DetailField
                                label="Job Title"
                                value={currentEditableData.jobTitle}
                                name="jobTitle"
                                onChange={handleInputChange}
                                isEditing={isEditing}
                                required={isMandatorySetup}
                            />
                            <DetailField
                                label="Employee ID"
                                value={currentEditableData.employeeId}
                                name="employeeId"
                                onChange={handleInputChange}
                                isEditing={isEditing}
                                required={isMandatorySetup}
                            />
                            <DetailField
                                label="Department"
                                value={currentEditableData.department}
                                name="department"
                                onChange={handleInputChange}
                                isEditing={isEditing}
                                required={isMandatorySetup}
                            />
                            <DetailField
                                label="Work Location"
                                value={currentEditableData.workLocation}
                                name="workLocation"
                                onChange={handleInputChange}
                                isEditing={isEditing}
                                required={isMandatorySetup}
                            />
                            <DetailField
                                label="Phone Number"
                                value={currentEditableData.phoneNumber}
                                name="phoneNumber"
                                type="tel"
                                onChange={handleInputChange}
                                isEditing={isEditing}
                                required={false}
                            />
                        </div>

                        {/* Action Buttons */}
                        {isEditing && (
                            <div className="flex justify-end space-x-4 mt-8 pt-4 border-t border-[hsl(var(--border))]">
                                {!isMandatorySetup && (
                                    <button
                                        onClick={handleCancel}
                                        disabled={isLoading}
                                        className="px-6 py-2 border border-[hsl(var(--border))] text-[hsl(var(--foreground))] font-semibold rounded-[var(--radius)] hover:bg-[hsl(var(--muted))] transition-fast"
                                    >
                                        Cancel
                                    </button>
                                )}
                                <button
                                    onClick={handleSave}
                                    disabled={isLoading}
                                    className={`px-6 py-2 text-[hsl(var(--primary-foreground))] font-semibold rounded-[var(--radius)] transition-fast flex items-center ${isLoading
                                            ? 'bg-[hsl(var(--primary-light))] cursor-not-allowed'
                                            : 'bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary-dark))] shadow-md'
                                        }`}
                                >
                                    {isLoading ? (
                                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                    ) : (
                                        <Save className="w-5 h-5 mr-2" />
                                    )}
                                    {isMandatorySetup ? 'Complete Setup & Go to Dashboard' : 'Save Changes'}
                                </button>
                            </div>
                        )}
                    </Card>
                </div>

                {/* Security & Settings Card (1/3 width on large screens) */}
                <div className="lg:col-span-1">
                    <Card className="p-6 h-full">
                        <h2 className="text-xl font-bold text-[hsl(var(--foreground))] border-b border-[hsl(var(--border))] pb-4 mb-6 flex items-center">
                            <Settings className="w-5 h-5 mr-3 text-[hsl(var(--primary))]" />
                            Security & Preferences
                        </h2>

                        <ul className="space-y-4">
                            <li className="p-2 rounded-[var(--radius)]">
                                <DetailSelect
                                    label="Preferred Doc Language"
                                    value={currentEditableData.preferredLanguage}
                                    name="preferredLanguage"
                                    options={languageOptions}
                                    onChange={handleInputChange as (e: React.ChangeEvent<HTMLSelectElement>) => void}
                                    isEditing={isEditing}
                                    required={isMandatorySetup}
                                />
                            </li>

                            {/* Notification Settings */}
                            <li className="flex justify-between items-center cursor-pointer hover:bg-[hsl(var(--muted))] p-2 rounded-[var(--radius)] transition-fast">
                                <div className="flex items-center">
                                    <Bell className="w-5 h-5 text-[hsl(var(--muted-foreground))] mr-3" />
                                    <span className="text-sm font-medium text-[hsl(var(--foreground))]">Notification Settings</span>
                                </div>
                                <span className="text-xs text-[hsl(var(--primary))] font-semibold">Configure</span>
                            </li>

                            {/* Change Password */}
                            <li className="flex justify-between items-center cursor-pointer hover:bg-[hsl(var(--muted))] p-2 rounded-[var(--radius)] transition-fast">
                                <div className="flex items-center">
                                    <Lock className="w-5 h-5 text-[hsl(var(--muted-foreground))] mr-3" />
                                    <span className="text-sm font-medium text-[hsl(var(--foreground))]">Change Password</span>
                                </div>
                                <span className="text-xs text-[hsl(var(--primary))] font-semibold">Manage</span>
                            </li>

                            {/* Two-Factor Authentication */}
                            <li className="flex justify-between items-center p-2 rounded-[var(--radius)]">
                                <div className="flex items-center">
                                    <Shield className="w-5 h-5 text-[hsl(var(--muted-foreground))] mr-3" />
                                    <span className="text-sm font-medium text-[hsl(var(--foreground))]">Two-Factor Auth</span>
                                </div>
                                {/* Uses Success/Destructive colors for badges */}
                                <div className={`text-xs font-semibold px-3 py-1 rounded-full ${userData.is2FAEnabled
                                        ? 'bg-[hsl(var(--success)/0.1)] text-[hsl(var(--success))]'
                                        : 'bg-[hsl(var(--destructive)/0.1)] text-[hsl(var(--destructive))]'
                                    }`}>
                                    {userData.is2FAEnabled ? 'Enabled' : 'Disabled'}
                                </div>
                            </li>


                            {/* Log Out */}
                            <li className="pt-4 border-t border-[hsl(var(--border))]">
                                <button
                                    className="w-full text-left p-2 text-sm font-semibold text-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive)/0.05)] rounded-[var(--radius)] transition-fast"
                                    onClick={async () => {
                                        try {
                                            await API.post("/gmail/auth/google/logout", {}, { withCredentials: true });
                                            window.location.reload();
                                        } catch (err) {
                                            console.error("Logout failed:", err);
                                        }
                                    }}
                                >
                                    Sign Out
                                </button>
                            </li>
                        </ul>
                    </Card>
                </div>
            </div>

            {/* 4. Render the Modal */}
            <HierarchyModal
                isOpen={showHierarchyModal}
                onClose={() => setShowHierarchyModal(false)}
                imageUrl={HIERARCHY_CHART_URL}
            />
        </div>
    );
};

export default ProfileComp;