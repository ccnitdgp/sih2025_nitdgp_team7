/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useState, useEffect } from "react";
import {
  CheckCircle2,
  Clock,
  AlertCircle,
  CalendarDays,
  Plus,
  X,
} from "lucide-react";
import API from "../../utils/api"; // Ensure this import path is correct

// Define a type for the essential user data we need
interface CurrentUser {
  jobTitle: string;
  employeeId: string;
  department: string;
}

// --- TYPES ---
interface Alert {
  type: string;
  message: string;
  priority?: "High" | "Medium" | "Low";
}

interface Action {
  id: string;
  task: string;
  status: "Pending" | "In Progress" | "Completed";
  deadline: string;
}

interface Station {
  name: string;
  x: string;
  y: string;
  supervisor: string;
  alerts: Alert[];
  actions: Action[];
}

export default function SmartMap() {
  // --- DATA ---
  const stations: Station[] = [
    {
      name: "Aluva",
      x: "54%",
      y: "9%",
      supervisor: "Rahul Menon",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Inspect terminal track end buffers",
          status: "Pending",
          deadline: "Today, 14:00",
        },
        {
          id: "2",
          task: "Restock token vending machines (Entry A)",
          status: "Completed",
          deadline: "Today, 10:00",
        },
        {
          id: "3",
          task: "Verify Feeder Bus schedule sync",
          status: "In Progress",
          deadline: "Today, 15:30",
        },
      ],
    },
    {
      name: "Pulinchodu",
      x: "53%",
      y: "12%",
      supervisor: "Anoop P.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Clear drainage near Pillar 45",
          status: "Pending",
          deadline: "Tomorrow, 09:00",
        },
        {
          id: "2",
          task: "Routine escalator maintenance",
          status: "In Progress",
          deadline: "Today, 12:00",
        },
      ],
    },
    {
      name: "Companypady",
      x: "51.4%",
      y: "16%",
      supervisor: "Deepak S.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Check fire safety equipment",
          status: "Completed",
          deadline: "Yesterday",
        },
        {
          id: "2",
          task: "Update digital ad displays",
          status: "Pending",
          deadline: "Oct 24, 17:00",
        },
      ],
    },
    {
      name: "Ambattukavu",
      x: "50%",
      y: "19.6%",
      supervisor: "Nikhil Raj",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Inspect parking lot sensors",
          status: "Pending",
          deadline: "Today, 14:30",
        },
      ],
    },
    {
      name: "Muttom",
      x: "48.6%",
      y: "23.3%",
      supervisor: "Arya Menon",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Yard entry signal calibration",
          status: "In Progress",
          deadline: "Today, 13:00",
        },
        {
          id: "2",
          task: "Brief maintenance staff on shift change",
          status: "Pending",
          deadline: "Today, 18:00",
        },
      ],
    },
    {
      name: "Kalamassery",
      x: "43.3%",
      y: "28.9%",
      supervisor: "Sajith K.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Clean platform 1 solar panels",
          status: "Pending",
          deadline: "Oct 25, 08:00",
        },
        {
          id: "2",
          task: "Check AFC Gates 3 & 4",
          status: "Completed",
          deadline: "Today, 11:00",
        },
      ],
    },
    {
      name: "Cochin University",
      x: "41.1%",
      y: "31.5%",
      supervisor: "Sreenath R.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Validate student concession passes",
          status: "In Progress",
          deadline: "Ongoing",
        },
        {
          id: "2",
          task: "Security check at North Entrance",
          status: "Pending",
          deadline: "Today, 16:00",
        },
      ],
    },
    {
      name: "Pathadipalam",
      x: "40%",
      y: "35.5%",
      supervisor: "Merin Joseph",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Inspect overhead traction line",
          status: "Pending",
          deadline: "Tonight, 23:00",
        },
      ],
    },
    {
      name: "Edappally",
      x: "36.7%",
      y: "42.9%",
      supervisor: "Vidushi Agarwal",
      alerts: [
        {
          type: "Crowd",
          message: "High footfall detected near Lulu Mall exit",
          priority: "Medium",
        },
      ],
      actions: [
        {
          id: "1",
          task: "Deploy extra security at Lulu Mall Walkway",
          status: "In Progress",
          deadline: "Immediate",
        },
        {
          id: "2",
          task: "Escalator 2 servicing",
          status: "Pending",
          deadline: "Tonight, 22:00",
        },
        {
          id: "3",
          task: "Clear queue at Ticket Counter 1",
          status: "Pending",
          deadline: "Today, 17:45",
        },
      ],
    },
    {
      name: "Changampuzha Park",
      x: "34.8%",
      y: "46.8%",
      supervisor: "Dilshad P.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Water park garden maintenance",
          status: "Completed",
          deadline: "Today, 10:00",
        },
        {
          id: "2",
          task: "Check cultural center audio system",
          status: "Pending",
          deadline: "Oct 26, 15:00",
        },
      ],
    },
    {
      name: "Palarivattom",
      x: "32%",
      y: "50.7%",
      supervisor: "Sreejith V.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Pipeline inspection near bypass pillar",
          status: "In Progress",
          deadline: "Today, 16:00",
        },
        {
          id: "2",
          task: "Ticket scanner software update",
          status: "Pending",
          deadline: "Oct 27, 02:00",
        },
      ],
    },
    {
      name: "Jawaharlal Nehru Stadium",
      x: "31.5%",
      y: "55%",
      supervisor: "Fayaz Ali",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Prepare for ISL Match crowd control",
          status: "Pending",
          deadline: "Oct 28, 18:00",
        },
        {
          id: "2",
          task: "Test emergency floodlights",
          status: "Completed",
          deadline: "Today, 12:00",
        },
      ],
    },
    {
      name: "Kaloor",
      x: "30.9%",
      y: "58.7%",
      supervisor: "Rohit Krishna",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Private Bus Stand connectivity check",
          status: "Pending",
          deadline: "Today, 14:00",
        },
        {
          id: "2",
          task: "Clean washrooms Level 2",
          status: "In Progress",
          deadline: "Today, 14:30",
        },
      ],
    },
    {
      name: "North Town Hall",
      x: "27.3%",
      y: "62.1%",
      supervisor: "Vinu N.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Coordinate with Railway Station feeder",
          status: "In Progress",
          deadline: "Today, 15:45",
        },
      ],
    },
    {
      name: "MG Road",
      x: "23.1%",
      y: "66.1%",
      supervisor: "Christy Varghese",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Deep clean Platform 2 (West)",
          status: "Pending",
          deadline: "Tonight, 23:30",
        },
        {
          id: "2",
          task: "Inspect AC Ducts in concourse",
          status: "In Progress",
          deadline: "Today, 16:00",
        },
        {
          id: "3",
          task: "Remove unauthorized posters outside",
          status: "Completed",
          deadline: "Today, 09:00",
        },
      ],
    },
    {
      name: "Maharaja's College",
      x: "22.8%",
      y: "69.8%",
      supervisor: "Ananya Devi",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Check library drop-box facility",
          status: "Pending",
          deadline: "Today, 17:00",
        },
        {
          id: "2",
          task: "Monitor ground entry crowding",
          status: "In Progress",
          deadline: "Ongoing",
        },
      ],
    },
    {
      name: "Ernakulam South",
      x: "24.5%",
      y: "73.3%",
      supervisor: "Sreenath K.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Sync with Railway Station arrival times",
          status: "Pending",
          deadline: "Today, 18:00",
        },
        {
          id: "2",
          task: "Fix display board at Entry B",
          status: "Pending",
          deadline: "Today, 16:00",
        },
      ],
    },
    {
      name: "Kadavanthra",
      x: "28.2%",
      y: "74.7%",
      supervisor: "Lakshmi B.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Indoor stadium parking audit",
          status: "Completed",
          deadline: "Today, 11:00",
        },
        {
          id: "2",
          task: "Sanitize railings",
          status: "In Progress",
          deadline: "Today, 15:00",
        },
      ],
    },
    {
      name: "Elamkulam",
      x: "32.8%",
      y: "74.8%",
      supervisor: "Vishnu P.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Inspect track alignment (routine)",
          status: "Pending",
          deadline: "Oct 25, 01:00",
        },
      ],
    },
    {
      name: "Vyttila",
      x: "36.9%",
      y: "74.4%",
      supervisor: "Kiran Raj",
      alerts: [
        {
          type: "Integration",
          message: "Water Metro feeder delay reported",
          priority: "Low",
        },
      ],
      actions: [
        {
          id: "1",
          task: "Verify Water Metro connectivity signs",
          status: "Pending",
          deadline: "Today, 16:00",
        },
        {
          id: "2",
          task: "Mobility Hub bus bay coordination",
          status: "In Progress",
          deadline: "Ongoing",
        },
        {
          id: "3",
          task: "Repair Lift #4",
          status: "Pending",
          deadline: "Tomorrow, 10:00",
        },
      ],
    },
    {
      name: "Thaikoodam",
      x: "39.7%",
      y: "76.5%",
      supervisor: "Harish M.",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Check bridge underside lighting",
          status: "Pending",
          deadline: "Today, 19:00",
        },
      ],
    },
    {
      name: "Petta",
      x: "46.2%",
      y: "80.2%",
      supervisor: "Jishnu Bose",
      alerts: [],
      actions: [
        {
          id: "1",
          task: "Tripunithura extension signal check",
          status: "In Progress",
          deadline: "Today, 14:00",
        },
        {
          id: "2",
          task: "Terminal cleaning audit",
          status: "Completed",
          deadline: "Today, 08:30",
        },
      ],
    },
  ];

  const [stationsData, setStationsData] = useState<Station[]>(stations);
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);

  const [loggedInUser, setLoggedInUser] = useState<CurrentUser | null>(null);
  const [loadingUser, setLoadingUser] = useState(true);
  const isManager = loggedInUser?.jobTitle === "Manager"; // Manager check

  // --- NEW STATES FOR LOGGING ---
  const [isLoggingAlert, setIsLoggingAlert] = useState(false);
  const [newAlertComment, setNewAlertComment] = useState("");

  // --- EFFECT: Fetch user on component mount ---
  useEffect(() => {
    const fetchUser = async () => {
      setLoadingUser(true);
      try {
        // Using API.fetchUser() as defined in your context
        const user: any = await API.fetchUser();
        setLoggedInUser({
          jobTitle: user.jobTitle,
          employeeId: user.employeeId,
          department: user.department,
        });
      } catch (error) {
        console.error("Error fetching logged-in user data:", error);
      } finally {
        setLoadingUser(false);
      }
    };
    fetchUser();
  }, []);

  // --- LOGIC: Log New Alert ---
  const logNewAlert = () => {
    if (!selectedStation || !newAlertComment.trim()) {
      alert("Please enter a comment for the new alert.");
      return;
    }

    const newAlert: Alert = {
      type: "Manager Log", // Fixed type
      message: newAlertComment.trim(),
      priority: "High", // ALWAYS set as high priority
    };

    // 1. Update the main stations data state
    setStationsData((prevStations) => {
      // Find the index of the station being updated
      const stationIndex = prevStations.findIndex(
        (s) => s.name === selectedStation.name
      );

      if (stationIndex === -1) return prevStations;

      // Create a copy of the station and add the new alert to the start of the array
      const updatedStation = {
        ...prevStations[stationIndex],
        alerts: [newAlert, ...prevStations[stationIndex].alerts],
      };

      // Update the main array
      const newStations = [...prevStations];
      newStations[stationIndex] = updatedStation;

      // 2. Update the selectedStation state to reflect the change immediately in the panel
      setSelectedStation(updatedStation);

      return newStations;
    });

    // 3. Reset logging state
    setNewAlertComment("");
    setIsLoggingAlert(false);
  };

  // Helper to get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-emerald-100 text-emerald-700 border-emerald-200";
      case "In Progress":
        return "bg-blue-100 text-blue-700 border-blue-200";
      case "Pending":
        return "bg-amber-50 text-amber-700 border-amber-200";
      default:
        return "bg-slate-100 text-slate-700";
    }
  };

  // Helper for deadline urgency color
  const getDeadlineColor = (text: string) => {
    if (text.includes("Immediate") || text.includes("Overdue"))
      return "text-red-600 font-bold";
    if (text.includes("Today") || text.includes("Tonight"))
      return "text-orange-600 font-semibold";
    return "text-slate-500";
  };

  // --- RENDER: LOADING SCREEN ---
  if (loadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 via-white to-blue-50 py-12">
        <div className="flex items-center space-x-3 text-slate-800 font-semibold text-lg">
          <Clock className="w-5 h-5 animate-spin" />
          <span>Loading user credentials...</span>
        </div>
      </div>
    );
  }
  // --- END RENDER: LOADING SCREEN ---

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-indigo-50 via-white to-blue-50 py-12">
      {/* --- DASHBOARD WIDGET CONTAINER --- */}
      <div className="relative w-[950px] bg-white rounded-[2.5rem] shadow-2xl border border-white/50 ring-1 ring-slate-900/5 overflow-hidden">
        {/* Header Overlay */}
        <div className="absolute top-0 left-0 w-full p-6 flex justify-between items-start z-10 pointer-events-none">
          <div>
            <h1 className="text-2xl font-black text-slate-800 tracking-tight">
              KOCHI METRO
            </h1>
            <div className="flex items-center gap-2 mt-1">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                Live Operations
              </p>
            </div>
          </div>
          {/* Legend */}
          <div className="bg-white/80 backdrop-blur-sm p-3 rounded-xl shadow-sm border border-slate-100 flex gap-4 pointer-events-auto">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-600">
              <span className="w-3 h-3 rounded-full bg-blue-600"></span> Active
            </div>
            <div className="flex items-center gap-2 text-xs font-medium text-slate-600">
              <span className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></span>{" "}
              Alert
            </div>
          </div>
        </div>

        {/* --- MAP AREA --- */}
        <div className="relative bg-slate-50 group cursor-grab active:cursor-grabbing">
          {/* Map Image */}
          <img
            src="/metro-map.png"
            alt="Kochi Metro Map"
            className="w-full h-auto object-contain mix-blend-multiply opacity-90"
          />

          {/* --- INTERACTIVE MARKERS --- */}
          {stationsData.map((station) => {
            const hasAlert = station.alerts.length > 0;
            const isSelected = selectedStation?.name === station.name;

            return (
              <div
                key={station.name}
                onClick={() => setSelectedStation(station)}
                className="absolute group/marker z-20"
                style={{
                  left: station.x,
                  top: station.y,
                  transform: "translate(-50%, -50%)",
                }}
              >
                {/* 1. HOVER TOOLTIP */}
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 opacity-0 group-hover/marker:opacity-100 transition-all duration-200 transform group-hover/marker:translate-y-0 translate-y-2 pointer-events-none">
                  <div className="bg-slate-900 text-white text-xs font-bold py-1.5 px-3 rounded-lg shadow-xl whitespace-nowrap relative">
                    {station.name}
                    <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-900"></div>
                  </div>
                </div>

                {/* 2. THE DOT */}
                <div
                  className={`
                  relative w-4 h-4 rounded-full border-[3px] border-white shadow-lg cursor-pointer transition-all duration-300 ease-out
                  ${
                    isSelected
                      ? "scale-[2.5] z-50"
                      : "group-hover/marker:scale-150"
                  }
                  ${
                    hasAlert
                      ? "bg-red-500 shadow-red-500/40"
                      : "bg-blue-600 shadow-blue-600/40"
                  }
                `}
                >
                  {hasAlert && (
                    <span className="absolute -inset-4 rounded-full bg-red-500 opacity-20 animate-ping"></span>
                  )}
                  {!hasAlert && (
                    <span className="absolute -inset-1 rounded-full bg-blue-400 opacity-0 group-hover/marker:opacity-20 transition-opacity"></span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* --- GLASSMORPHIC SIDE PANEL --- */}
        <div
          className={`absolute top-0 right-0 h-full w-[400px] bg-white/80 backdrop-blur-xl shadow-2xl border-l border-white/50 transform transition-transform duration-500 cubic-bezier(0.2, 0.8, 0.2, 1) z-40
            ${selectedStation ? "translate-x-0" : "translate-x-full"}`}
        >
          {selectedStation && (
            <div className="flex flex-col h-full">
              {/* Panel Header */}
              <div className="p-8 pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-3xl font-black text-slate-800 tracking-tight">
                      {selectedStation.name}
                    </h2>
                    <div className="h-1 w-12 bg-blue-600 rounded-full mt-2"></div>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedStation(null);
                      setIsLoggingAlert(false);
                    }}
                    className="p-2 bg-slate-100 hover:bg-red-50 hover:text-red-500 rounded-full transition-colors"
                  >
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Scrollable Body */}
              <div className="flex-1 overflow-y-auto p-8 pt-2 space-y-6">
                {/* Info Card */}
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-blue-200">
                    <svg
                      className="w-6 h-6"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                      />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wide">
                      Supervisor
                    </p>
                    <p className="text-lg font-bold text-slate-800">
                      {selectedStation.supervisor}
                    </p>
                  </div>
                </div>

                {/* Status / Alerts Section */}
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-3 flex items-center gap-2">
                    Alerts & Notifications
                  </h3>

                  {selectedStation.alerts.length === 0 ? (
                    <div className="flex items-center gap-3 p-4 bg-emerald-50 border border-emerald-100 rounded-xl">
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                      <span className="text-sm font-semibold text-emerald-700">
                        No active alerts
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {selectedStation.alerts.map((alert, index) => (
                        <div
                          key={index}
                          className={`flex gap-3 p-4 rounded-xl border ${
                            alert.priority === "High"
                              ? "bg-red-50 border-red-100"
                              : "bg-yellow-50 border-yellow-100"
                          }`}
                        >
                          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span
                                className={`text-xs font-bold px-1.5 py-0.5 rounded uppercase ${
                                  alert.priority === "High"
                                    ? "text-red-700 bg-red-100"
                                    : "text-yellow-700 bg-yellow-100"
                                }`}
                              >
                                {alert.type}
                              </span>
                              {alert.priority === "High" && (
                                <span className="text-[10px] font-bold text-red-500 animate-pulse">
                                  CRITICAL
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-red-900 font-medium leading-tight">
                              {alert.message}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* --- NEW ACTIONS SECTION WITH DEADLINES --- */}
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-3 flex items-center gap-2">
                    Operational Tasks
                  </h3>

                  {selectedStation.actions.length === 0 ? (
                    <p className="text-sm text-slate-400 italic">
                      No pending actions scheduled.
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {selectedStation.actions.map((action) => (
                        <div
                          key={action.id}
                          className="group bg-white p-4 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-all"
                        >
                          <div className="flex justify-between items-start mb-2">
                            <span
                              className={`text-[10px] font-bold px-2 py-1 rounded-full border uppercase tracking-wide ${getStatusColor(
                                action.status
                              )}`}
                            >
                              {action.status}
                            </span>
                            {/* Deadline Badge */}
                            <div
                              className={`flex items-center gap-1.5 text-xs ${getDeadlineColor(
                                action.deadline
                              )}`}
                            >
                              <CalendarDays className="w-3.5 h-3.5" />
                              {action.deadline}
                            </div>
                          </div>
                          <p className="text-sm font-semibold text-slate-700 leading-snug group-hover:text-blue-600 transition-colors">
                            {action.task}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Footer - Conditional Rendering for Manager/Logging */}
              <div className="p-6 bg-slate-50 border-t border-slate-100">
                {/* 1. New Alert Input (Visible only when isLoggingAlert is true) */}
                {isLoggingAlert ? (
                  <div className="space-y-3">
                    <textarea
                      value={newAlertComment}
                      onChange={(e) => setNewAlertComment(e.target.value)}
                      placeholder={`Log critical alert for ${selectedStation.name} (High Priority)`}
                      rows={3}
                      className="w-full p-3 border border-red-300 rounded-lg focus:ring-red-500 focus:border-red-500 text-sm"
                    />
                    <div className="flex justify-between gap-3">
                      <button
                        onClick={() => setIsLoggingAlert(false)}
                        className="flex-1 py-3 text-slate-700 bg-white border border-slate-300 font-bold rounded-xl hover:bg-slate-100 transition-colors shadow-sm text-sm justify-center flex items-center gap-2"
                      >
                        <X className="w-4 h-4" /> Cancel
                      </button>
                      <button
                        onClick={logNewAlert}
                        disabled={!newAlertComment.trim()}
                        className="flex-1 py-3 bg-red-600 text-white font-black rounded-xl hover:bg-red-700 transition-colors shadow-lg shadow-red-200 text-sm justify-center flex items-center gap-2 disabled:opacity-50"
                      >
                        <AlertCircle className="w-4 h-4" /> Log Critical Alert
                      </button>
                    </div>
                  </div>
                ) : (
                  // 2. Log New Button (Visible only to Managers and when not logging)
                  isManager && (
                    <button
                      onClick={() => setIsLoggingAlert(true)}
                      className="w-full py-3 bg-slate-800 text-white font-bold rounded-xl hover:bg-red-600 transition-colors shadow-lg shadow-slate-200 text-sm flex items-center justify-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> Log New Critical Alert
                    </button>
                  )
                )}

                {/* Fallback button for non-managers */}
                {!isManager && !isLoggingAlert && (
                  <button className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl transition-colors shadow-lg shadow-blue-200 text-sm flex items-center justify-center gap-2 opacity-50 cursor-not-allowed">
                    Operational Panel (Manager Only)
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
