// components/ui/ShareNotificationModal.jsx

import React, { useState, useEffect, useCallback } from 'react';
import { Share, Loader2, Clock } from 'lucide-react'; 
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './dialog'; 
import { Button } from './button';
import API from '../../utils/api'; 
const ShareNotificationModal = ({ isOpen, onClose, document }) => {
    const [selectedDept, setSelectedDept] = useState('');
    const [departmentUsers, setDepartmentUsers] = useState([]);
    const [selectedAction, setSelectedAction] = useState('');
    const [selectedRecipient, setSelectedRecipient] = useState(null);
    const [notificationDetails, setNotificationDetails] = useState({ 
        priority: document?.priority || 'Medium', 
        deadline: '' 
    });
    const [loadingUsers, setLoadingUsers] = useState(false);
    const [isSharing, setIsSharing] = useState(false);

    // Effect to reset state when the document changes or modal opens/closes
    useEffect(() => {
        if (isOpen && document) {
            setSelectedDept('');
            setDepartmentUsers([]);
            setSelectedRecipient(null);
            setSelectedAction('');
            setNotificationDetails({ 
                priority: document.priority || 'Medium', 
                deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] 
            });
        }
    }, [isOpen, document]);

    const getAvailableActions = (dept) => {
        console.log(document);
        const actions = document?.allActions || [];
        return actions.filter(a => a.assigned_department === dept);
    };

    // Fetches users based on the selected department (GET /messages/users-by-department)
    const fetchUsersByDepartment = useCallback(async (department, action) => {
        if (!department || !action) {
        setDepartmentUsers([]);
        setSelectedRecipient(null);
        return;
    }
        
        setLoadingUsers(true);
        try {
            // ✅ Connects to the actual backend endpoint: GET /messages/users-by-department
            const response = await API.get("/messages/users-by-department", {
            params: { department, action } 
        });
            setDepartmentUsers(response.data);
            
            // Auto-select the first user if available
            setSelectedRecipient(response.data[0] || null);
        } catch (error) {
            console.error("Failed to fetch users:", error);
            alert("Failed to load users for the selected department. The backend might be unreachable or returned an error.");
            setDepartmentUsers([]);
            setSelectedRecipient(null);
        } finally {
            setLoadingUsers(false);
        }
    }, []);

    const handleDepartmentSelect = (e) => {
        const department = e.target.value;
    setSelectedDept(department);
    setSelectedAction(''); 
    setSelectedRecipient(null);
    setDepartmentUsers([]);
    };

    const handleActionSelect = (e) => {
        const actionTitle = e.target.value;
        setSelectedAction(actionTitle);
        setSelectedRecipient(null); 
        setDepartmentUsers([]);
        
        if (actionTitle) {
            const allActions = getAvailableActions(selectedDept);
            const selectedActionObj = allActions.find(a => a.action === actionTitle);

            if (selectedActionObj) {
                setNotificationDetails(prev => ({
                    ...prev,
                    priority: selectedActionObj.priority || 'Medium',
                    deadline: selectedActionObj.deadline || '' 
                }));
            } else {
                 setNotificationDetails(prev => ({ ...prev, priority: 'Medium', deadline: '' }));
            }
            fetchUsersByDepartment(selectedDept, actionTitle);
        } else {
             setNotificationDetails(prev => ({ ...prev, priority: document.priority || 'Medium', deadline: '' }));
        }
    };

    const handleRecipientChange = (e) => {
        const userId = e.target.value;
        const user = departmentUsers.find(u => u._id === userId); 
        setSelectedRecipient(user || null);
    };

    // Handles the final notification submission (POST /messages/notify)
    const handleSendNotification = async () => {
        if (!document || !selectedRecipient || !selectedDept || !selectedAction) {
        alert("Please select a department, action, and recipient.");
        return;
    }

    setIsSharing(true);

    const payload = {
        documentId: document.id,
        recipientId: selectedRecipient._id, 
        actionRequiredDept: selectedDept,
        actionRequired: selectedAction,
        priority: notificationDetails.priority,
        deadline: notificationDetails.deadline, 
    };
        try {
            await API.post("/messages/notify", payload);
            alert(`Notification sent successfully to ${selectedRecipient.name} (${selectedDept})!`);
            onClose(); 
        } catch (error) {
            console.error("Failed to send notification:", error);
            alert("Failed to send notification. Please check if the API utility is configured correctly and the server is running.");
        } finally {
            setIsSharing(false);
        }
    };

    if (!document) return null;

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Notify a Colleague</DialogTitle>
                    <DialogDescription>
                        Send a targeted notification about '{document.name}'.
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-4">
                    {/* 1. Department Dropdown */}
                    <div>
                        <label className="text-sm font-medium text-gray-700 block mb-1">
                            1. Select Target Department (Flagged)
                        </label>
                        <select
                            className="w-full p-2 border border-gray-300 rounded-lg bg-white"
                            value={selectedDept}
                            onChange={handleDepartmentSelect} 
                        >
                            <option value="">--- Select Department ---</option>
                            {/* Assuming document.departments is an array of strings */}
                            {document.departments.map(dept => (
                                <option key={dept} value={dept}>{dept}</option>
                            ))}
                        </select>
                    </div>

                    {/* 🔄 Show the selected department's flagged actions (if any) */}
                    {selectedDept && (
        <div>
            <label className="text-sm font-medium text-gray-700 block mb-1">
                2. Select Required Action
            </label>
            <select
                className="w-full p-2 border border-gray-300 rounded-lg bg-white"
                value={selectedAction}
                onChange={handleActionSelect}
            >
                <option value="">--- Select Action ---</option>
                {getAvailableActions(selectedDept).map(item => (
                    <option key={item.action} value={item.action}>
                        {item.action} (P: {item.priority})
                    </option>
                ))}
            </select>
        </div>
    )}
                    {/* 2. Recipient Dropdown */}
                    {selectedDept && selectedAction && (
                        <div>
                            <label className="text-sm font-medium text-gray-700 block mb-1">
                                2. Select Recipient
                            </label>
                            <select
                                className="w-full p-2 border border-gray-300 rounded-lg bg-white"
                                value={selectedRecipient?._id || ""}
                                onChange={handleRecipientChange}
                                disabled={loadingUsers}
                            >
                                <option value="">
                                    {loadingUsers ? "Loading users..." : "--- Select User ---"}
                                </option>
                                {!loadingUsers && departmentUsers.map(user => (
                                    <option key={user._id} value={user._id}> 
                                        {user.name} ({user.jobTitle})
                                    </option>
                                ))}
                            </select>

                            {/* User Detail Preview */}
                            {selectedRecipient && (
                                <div className="mt-3 flex items-center p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                    <img 
                                        src={selectedRecipient.picture || 'https://placehold.co/40x40/cccccc/ffffff?text=U'} 
                                        alt={selectedRecipient.name} 
                                        className="h-10 w-10 rounded-full mr-3"
                                    />
                                    <div>
                                        <p className="font-semibold text-sm">{selectedRecipient.name}</p>
                                        <p className="text-xs text-gray-600">{selectedRecipient.jobTitle}</p>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                    
                    {/* 3. Action Details (Priority and Deadline) */}
                    {selectedRecipient && (
    <div className="grid grid-cols-2 gap-4">
        <div>
            <label className="text-sm font-medium text-gray-700 block mb-1">Priority (Assigned)</label>
            <select
                className="w-full p-2 border border-gray-300 rounded-lg bg-gray-100 text-gray-700 cursor-not-allowed"
                value={notificationDetails.priority}
                onChange={() => {}} 
                disabled={true}
            >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
                <option value="Normal">Normal</option>
            </select>
        </div>
        <div>
            <label className="text-sm font-medium text-gray-700 block mb-1">Deadline (Assigned)</label>
            <div className="flex items-center space-x-1">
                <Clock className='h-4 w-4 text-gray-500' /> 
                <input
                    type="text" 
                    className="w-full p-2 border border-gray-300 rounded-lg bg-gray-100 text-gray-700 cursor-not-allowed"
                    value={notificationDetails.deadline}
                    onChange={() => {}}
                    disabled={true}
                />
            </div>
        </div>
    </div>
)}

                    {/* Final Send Button */}
                    <Button 
                        onClick={handleSendNotification} 
                        disabled={!selectedRecipient || isSharing}
                        className={`w-full mt-4 flex items-center justify-center ${isSharing ? 'bg-gray-400' : 'bg-green-600 hover:bg-green-700'} text-white`}
                        title={''}
                    >
                        {isSharing ? (
                            <>
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                Sending Notification...
                            </>
                        ) : (
                            <>
                                <Share className="h-4 w-4 mr-2" />
                                Send Notification
                            </>
                        )}
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default ShareNotificationModal;