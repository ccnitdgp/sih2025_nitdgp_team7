// src/components/ui/SimpleActionCalendar.jsx

import React, { useState, useEffect, useMemo, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button"; 
import { ArrowLeft, ArrowRight, Clock, Info, Zap } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area"; 

// Import helpers
import { generateMonthGrid, transformActionsToEvents, getPriorityVariant } from "../../utils/calendarHelper"; 

const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const SimpleActionCalendar = ({ documentsData, loading }) => {
    // 💡 FIX 1: Initialize currentDate to the first day of the current month.
    const today = new Date();
    const [currentDate, setCurrentDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
    const [eventsByDate, setEventsByDate] = useState({});
    
    // State for the dialog
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [selectedDayEvents, setSelectedDayEvents] = useState([]);
    const [selectedDate, setSelectedDate] = useState(null);

    // No longer need isInitialLoad.current since initialization is static.
    // const isInitialLoad = useRef(true);

    useEffect(() => {
        if (loading || !documentsData) return;

        const allEvents = transformActionsToEvents(documentsData);
        
        // Group events by their exact deadline date string (YYYY-MM-DD)
        const groupedEvents = allEvents.reduce((acc, event) => {
            const dateStr = event.start.substring(0, 10); 
            if (!acc[dateStr]) {
                acc[dateStr] = [];
            }
            acc[dateStr].push(event);
            return acc;
        }, {});

        setEventsByDate(groupedEvents);

        // ❌ REMOVED: All the complex logic for checking futureEvents and allEvents.sort
        // The calendar will now simply render the month specified by the initial useState.

    }, [documentsData, loading]); 

    // Generate the calendar grid based on the current date state
    const calendarDays = useMemo(() => {
        // currentDate is now guaranteed to be a Date object.
        return generateMonthGrid(currentDate);
    }, [currentDate]);

    // 3. Navigation handlers
    const handlePrevMonth = () => {
        setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
    };

    const handleNextMonth = () => {
        setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
    };

    // Handler for opening the dialog and setting events
    const handleDayClick = (dateStr) => {
        const events = eventsByDate[dateStr];
        if (events && events.length > 0) {
            setSelectedDayEvents(events);
            setSelectedDate(dateStr);
            setIsDialogOpen(true);
        }
    };

    const headerMonthYear = `${currentDate.toLocaleString('default', { month: 'long' })} ${currentDate.getFullYear()}`;
    const todayStr = new Date().toISOString().substring(0, 10);

    return (
        <>
            <Card className="shadow-2xl border-2">
                <div className="p-4 bg-muted/20 border-b flex items-center justify-between rounded-t-lg">
                    <Button variant="ghost" size="icon" onClick={handlePrevMonth} aria-label="Previous Month">
                        <ArrowLeft className="h-5 w-5" />
                    </Button>
                    <h2 className="text-xl font-bold text-primary tracking-wide">
                        {headerMonthYear}
                    </h2>
                    <Button variant="ghost" size="icon" onClick={handleNextMonth} aria-label="Next Month">
                        <ArrowRight className="h-5 w-5" />
                    </Button>
                </div>

                {loading ? (
                    <p className="p-10 text-center text-lg text-muted-foreground">Loading action deadlines...</p>
                ) : (
                    <div className="p-4">
                        {/* Day Names Row (Enhanced visual style) */}
                        <div className="grid grid-cols-7 text-center font-bold text-sm uppercase tracking-wider text-primary mb-2">
                            {DAY_NAMES.map(day => (
                                <div key={day} className="py-2">{day}</div>
                            ))}
                        </div>
                        
                        {/* Date Cells Grid */}
                        <div className="grid grid-cols-7 gap-1">
                            {calendarDays.map((day, index) => {
                                const dateStr = day.toISOString().substring(0, 10);
                                const dayEvents = eventsByDate[dateStr] || [];
                                const isCurrentMonth = day.getMonth() === currentDate.getMonth();
                                const isToday = dateStr === todayStr;
                                const hasEvents = dayEvents.length > 0;

                                return (
                                    <div 
                                        key={index} 
                                        onClick={() => handleDayClick(dateStr)} // Attach click handler
                                        className={`
                                            h-28 p-1 border rounded-md overflow-hidden relative transition-all duration-200 cursor-pointer group
                                            ${isCurrentMonth ? (isToday ? "bg-blue-100 border-blue-500 shadow-md" : "bg-white hover:bg-muted/50") : "bg-muted/10 text-muted-foreground/70"}
                                            ${hasEvents && isCurrentMonth ? "border-l-4 border-l-red-500 hover:shadow-lg" : ""}
                                        `}
                                        aria-label={`${day.toLocaleDateString()} with ${dayEvents.length} actions`}
                                    >
                                        <div className={`text-sm font-bold mb-1 p-0.5 rounded-sm flex justify-between items-center ${isToday ? "text-primary bg-white/70" : "text-foreground"}`}>
                                            <span>{day.getDate()}</span>
                                            {hasEvents && <Zap className="h-3 w-3 text-red-500" />}
                                        </div>

                                        {/* Event Markers */}
                                        <ScrollArea className="h-[calc(100%-25px)]">
                                            {dayEvents.slice(0, 3).map((event) => (
                                                <Badge 
                                                    key={event.id}
                                                    variant={getPriorityVariant(event.priority)}
                                                    className="w-full truncate text-xs cursor-pointer mb-0.5 justify-start px-1"
                                                    title={event.title}
                                                >
                                                    {event.title}
                                                </Badge>
                                            ))}
                                            {dayEvents.length > 3 && (
                                                <div className="text-[10px] text-center text-primary/70 mt-0.5">
                                                    +{dayEvents.length - 3} more
                                                </div>
                                            )}
                                        </ScrollArea>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}
            </Card>

            {/* --- ACTION REQUIRED DIALOG --- */}
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogContent className="sm:max-w-[700px]">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2 text-xl font-bold text-primary">
                           <Info className="h-6 w-6" /> Actions Required on {selectedDate ? new Date(selectedDate).toLocaleDateString() : 'Date'}
                        </DialogTitle>
                        <DialogDescription>
                            Review the list of deadlines sourced from your documents.
                        </DialogDescription>
                    </DialogHeader>

                    <ScrollArea className="h-[400px] pr-4 space-y-4">
                        {selectedDayEvents.map((event, index) => (
                            <Card key={event.id} className="shadow-sm border-l-4 p-4 mb-3" 
                                style={{ borderColor: event.priority?.toLowerCase() === 'high' || event.priority?.toLowerCase() === 'critical' ? '#ef4444' : (event.priority?.toLowerCase() === 'medium' ? '#f59e0b' : '#3b82f6') }}
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="text-base font-semibold text-foreground flex items-center gap-2">
                                        <Clock className="h-4 w-4 text-muted-foreground" />
                                        {event.title}
                                    </h3>
                                    <Badge variant={getPriorityVariant(event.priority)} className="flex-shrink-0">
                                        Priority: {event.priority}
                                    </Badge>
                                </div>
                                <div className="text-sm space-y-1">
                                    <p className="text-muted-foreground">
                                        **Source:** {event.documentName} ({event.documentSource})
                                    </p>
                                    <p className="text-muted-foreground">
                                        **Assigned:** <Badge variant="secondary" className="bg-purple-100 text-purple-800">{event.assigned}</Badge>
                                    </p>
                                    {event.notes && (
                                         <p className="text-xs italic pt-1">Notes: {event.notes}</p>
                                    )}
                                </div>
                            </Card>
                        ))}
                    </ScrollArea>
                    <Button onClick={() => setIsDialogOpen(false)} className="w-full">
                        Close
                    </Button>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default SimpleActionCalendar;