import React, { useState, useEffect, useCallback } from 'react';
import { Loader2, Bell, Clock, CheckCircle, XCircle, ArrowRight, CornerDownRight, Zap, ListChecks } from 'lucide-react';
import API from '../../utils/api';
import { Card, CardContent, CardDescription, CardTitle } from './card';
import { Badge } from './badge';
import { Button } from './button';
import NotificationDetailModal from './notificationDetailModal';

const NotificationsList = ({ onTaskCompleted }) => {
    const [receivedNotifications, setReceivedNotifications] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isProcessing, setIsProcessing] = useState({});
    const [showCompleted, setShowCompleted] = useState(false);
    const [error, setError] = useState(null);
    const [selectedNotification, setSelectedNotification] = useState(null); // Stores the full object of the notification to display
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);

    const fetchReceivedNotifications = useCallback(async (isCompletedFilter) => {
        setLoading(true);
        setError(null);
        try {
            const response = await API.get("/messages/notifications", {
                params: { showCompleted: isCompletedFilter }
            });
            setReceivedNotifications(response.data);
        } catch (err) {
            console.error("Failed to fetch received notifications:", err);
            setError("Failed to load tasks. Check server connection.");
            setReceivedNotifications([]);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchReceivedNotifications(showCompleted);
    }, [fetchReceivedNotifications, showCompleted]);

    const handleComplete = async (id) => {
        setIsProcessing(prev => ({ ...prev, [id]: true }));
        try {
            await API.post(`/messages/notifications/${id}/complete`);
            fetchReceivedNotifications(showCompleted);
            if (onTaskCompleted) {
                onTaskCompleted(id);
            }

        } catch (error) {
            console.error("Failed to mark notification as complete:", error);
        } finally {
            setIsProcessing(prev => ({ ...prev, [id]: false }));
        }
    };

    const getPriorityColor = (priority) => {
        switch (priority?.toLowerCase()) {
            case 'high':
                return 'bg-red-500 hover:bg-red-600 text-white';
            case 'medium':
                return 'bg-orange-400 hover:bg-orange-500 text-white';
            case 'low':
                return 'bg-yellow-300 hover:bg-yellow-400 text-black';
            default:
                return 'bg-gray-100 text-gray-800';
        }
    };

    const getDaysRemaining = (deadline) => {
        if (!deadline) return null;
        const now = new Date();
        const futureDate = new Date(deadline);
        const diffTime = futureDate.getTime() - now.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays < 0) return { text: "Overdue", color: "text-red-600" };
        if (diffDays === 0) return { text: "Due Today", color: "text-orange-600" };
        if (diffDays <= 3) return { text: `${diffDays} days left`, color: "text-amber-600" };
        return { text: `${diffDays} days left`, color: "text-green-600" };
    };

    // Add this function inside your NotificationsList component
const handleView = (notification) => {
    setSelectedNotification(notification);
    setIsViewModalOpen(true);
};

// Add this function to close the modal
const handleCloseViewModal = () => {
    setIsViewModalOpen(false);
    setSelectedNotification(null);
};



    return (
        <div className="w-[380px] md:w-[450px] shadow-2xl rounded-lg bg-white p-3 space-y-3 overflow-hidden">
            
            {/* Header/Title and Toggle */}
            <div className="flex items-center justify-between border-b pb-3 mb-2">
                <h3 className="text-xl font-bold flex items-center text-gray-900">
                    <Bell className="h-5 w-5 mr-2 text-primary" />
                    Tasks ({showCompleted ? 'Completed' : 'Pending'})
                </h3>
                <div className='flex gap-2'>
                    <Button 
                        variant={!showCompleted ? "default" : "outline"} 
                        size="sm"
                        onClick={() => setShowCompleted(false)}
                        className='h-7 px-3 text-xs'
                    >
                        <Zap className='h-3 w-3 mr-1'/> Pending
                    </Button>
                    <Button 
                        variant={showCompleted ? "default" : "outline"} 
                        size="sm"
                        onClick={() => setShowCompleted(true)}
                        className='h-7 px-3 text-xs'
                    >
                        <ListChecks className='h-3 w-3 mr-1'/> Completed
                    </Button>
                </div>
            </div>

            {/* Content Area (Scrollable) */}
            <div className="max-h-[70vh] overflow-y-auto space-y-3 pr-2">

                {loading && (
                    <div className="text-center py-5">
                        <Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" />
                        <p className="mt-1 text-sm text-primary">Loading tasks...</p>
                    </div>
                )}

                {error && (
                    <div className="text-center py-5 text-red-600 border border-red-300 rounded-lg p-3">
                        <p className='text-sm'>{error}</p>
                    </div>
                )}

                {!loading && !error && receivedNotifications.length === 0 && (
                    <div className="text-center py-8">
                        <XCircle className="h-8 w-8 mx-auto text-gray-400" />
                        <p className="mt-2 text-sm text-gray-600">No {showCompleted ? "completed" : "pending"} tasks.</p>
                    </div>
                )}

                {receivedNotifications.map((note) => {
                    const deadlineInfo = getDaysRemaining(note.deadline);
                    const isOverdue = deadlineInfo && deadlineInfo.text === 'Overdue';
                    const isCurrentProcessing = isProcessing[note._id];
                    
                    return (
                        <Card key={note._id} className={`shadow-md hover:shadow-lg transition-shadow border-l-4 ${isOverdue && !note.isCompleted ? 'border-red-500' : ''}`} 
                            style={{ borderColor: note.isCompleted ? '#10B981' : isOverdue ? '#EF4444' : getPriorityColor(note.priority).split(' ')[0].replace('bg-', '#').replace('400', '500') }}>
                            <CardContent className="p-3 flex justify-between items-start space-x-3">
                                <div className="flex-1 space-y-1 min-w-0">
                                    <div className="flex items-center space-x-1.5">
                                        {note.isCompleted ? (
                                            <CheckCircle className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                                        ) : (
                                            <CornerDownRight className="h-4 w-4 text-gray-500 flex-shrink-0" />
                                        )}
                                        <CardTitle className={`text-base font-medium leading-tight truncate ${note.isCompleted ? 'line-through text-gray-500' : 'text-gray-900'}`} title={note.actionRequired}>
                                            {note.actionRequired}
                                        </CardTitle>
                                    </div>

                                    <CardDescription className="text-xs text-gray-600 mt-0">
                                        <span className="font-medium">From:</span> 
                                        <span className="ml-0.5 font-semibold">{note.senderId.name}</span>
                                        <Badge className="ml-1 text-[10px] text-gray-500 border border-gray-300 bg-white">
                                            {note.senderId.department}
                                        </Badge>
                                    </CardDescription>

                                    <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs mt-2">
                                        {/* Deadline Info */}
                                        <div className="flex items-center">
                                            <Clock className="h-3.5 w-3.5 mr-0.5 text-gray-500" />
                                            <span className="font-medium">Due:</span>
                                            <span className={`ml-0.5 ${isOverdue && !note.isCompleted ? 'font-bold text-red-600' : 'text-gray-700'}`}>
                                                {note.deadline ? new Date(note.deadline).toLocaleDateString() : 'N/A'}
                                            </span>
                                        </div>

                                        {/* Priority Badge */}
                                        <div className="flex items-center">
                                            <ArrowRight className="h-3.5 w-3.5 mr-0.5 text-gray-500" />
                                            <span className="font-medium">Priority:</span>
                                            <Badge className={`ml-0.5 text-[10px] ${getPriorityColor(note.priority)} h-4`}>
                                                {note.priority}
                                            </Badge>
                                        </div>
                                    </div>
                                </div>

                                {/* Action Buttons */}
                                <div className="flex flex-col items-end gap-1 flex-shrink-0">
                                    <Button 
                                    variant="outline" 
        size="sm" 
        className='h-6 text-xs px-2'
        onClick={() => handleView(note)}
                                    >
                                        View
                                    </Button>
                                    {!note.isCompleted && (
                                        <Button 
                                            variant="default" // Changed to default/primary color for small popover button
                                            size="sm" 
                                            onClick={() => handleComplete(note._id)}
                                            disabled={isCurrentProcessing}
                                            className='h-6 text-xs px-2 bg-emerald-500 hover:bg-emerald-600'
                                        >
                                            {isCurrentProcessing ? (
                                                <Loader2 className="h-3 w-3 animate-spin" />
                                            ) : (
                                                <CheckCircle className="h-3 w-3" />
                                            )}
                                        </Button>
                                    )}
                                    {note.isCompleted && (
                                        <Badge className='bg-emerald-100 text-emerald-800 text-[10px] py-0.5 h-auto'>
                                            COMPLETED
                                        </Badge>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    );
                })}
            </div>
            {isViewModalOpen && selectedNotification && (
        <NotificationDetailModal
            notification={selectedNotification}
            onClose={handleCloseViewModal}
        />
    )}
            
        </div>
    );
};

export default NotificationsList;