import React, { useEffect, useState } from "react";
import { useLang } from "@/context/langContext";

type Props = {
  defaultText: string;
  className?: string;
  as?: keyof JSX.IntrinsicElements;
};

export default function Translated({ defaultText, className, as = "span" }: Props) {
  const { translate, lang } = useLang();
  const [text, setText] = useState(defaultText);

  useEffect(() => {
    let mounted = true;

    translate(defaultText).then((translated) => {
      if (mounted) setText(translated);
    });

    return () => {
      mounted = false;
    };
  }, [defaultText, lang, translate]);

  return React.createElement(as as any, { className }, text);
}
