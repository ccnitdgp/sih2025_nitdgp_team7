import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Loader2, ExternalLink } from 'lucide-react';
// 💡 REQUIRED: Import react-markdown
import ReactMarkdown from 'react-markdown';

const ChatbotIcon = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { text: "Hello! How can I help you today?", sender: 'bot' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Ref to auto-scroll to the bottom of the chat
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // --- API HANDLERS ---

  /**
   * Fallback to Gemini API if RAG fails to find documents.
   */
  const callGeminiFallback = async (userQuery) => {
    const MODEL_NAME = 'gemini-2.5-flash'; 
    const GEMINI_API_KEY = 'AIzaSyBp2PRx0rMps34Wt5wBN-5tkrggR8r6qOk';
    
    // URL with the correct model name
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL_NAME}:generateContent?key=${GEMINI_API_KEY}`;

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: userQuery }] }]
        })
      });

      const data = await response.json();
      
      // Extracting text from Gemini response structure
      const geminiText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      return geminiText || "I'm having trouble connecting right now.";
      
    } catch (error) {
      console.error("Gemini Error:", error);
      return "I'm currently unavailable. Please try again later.";
    }
  };

  /**
   * Primary RAG API Call
   */
  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = input;
    setMessages(prev => [...prev, { text: userMessage, sender: 'user' }]);
    setInput('');
    setIsLoading(true);

    try {
      // 1. Call your RAG API
      const response = await fetch('/rag-api/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: userMessage }),
      });

      if (!response.ok) throw new Error('Network response was not ok');

      const data = await response.json();
      
      // Attempt to read the response text from various common keys
      const cleanText = data.response || data.text || data.cleanText || ""; 

      // 2. Check for the fallback condition OR API Errors
      const lowerCaseResponse = cleanText.toLowerCase();
      
      // We check if the RAG couldn't find docs OR if the API returned a Quota/429 error text
      const isErrorResponse = 
        lowerCaseResponse.includes("quota exceeded") || 
        lowerCaseResponse.includes("429") ||
        lowerCaseResponse.includes("error generating response");

      if (lowerCaseResponse.includes("i couldn't find any relevant documents") || 
          lowerCaseResponse.includes("no relevant documents found") || 
          isErrorResponse) {
        
        // --- Trigger Fallback ---
        const geminiResponse = await callGeminiFallback(userMessage);
        setMessages(prev => [...prev, { text: geminiResponse, sender: 'bot' }]);

      } else {
        // --- Show RAG Response ---
        setMessages(prev => [...prev, { text: cleanText, sender: 'bot' }]);
      }

    } catch (error) {
      console.error("Error:", error);
      setMessages(prev => [...prev, { text: "Sorry, something went wrong. Please try again.", sender: 'bot' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-50 flex flex-col items-end">
      
      {/* --- Chat Popup Window --- */}
      {isOpen && (
        <div className="mb-4 w-80 md:w-96 h-[500px] bg-white rounded-2xl shadow-2xl flex flex-col border border-gray-200 overflow-hidden animate-in fade-in slide-in-from-bottom-10 duration-200">
          
          {/* Header */}
          <div className="bg-blue-600 p-4 flex items-center justify-between shrink-0">
            <a 
              href="https://kochiai-atih.onrender.com/"
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-white font-semibold hover:text-blue-100 transition-colors group"
            >
              <span>Engage with Vaani</span>
              <ExternalLink size={16} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"/>
            </a>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-blue-100 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.map((msg, idx) => (
              <div 
                key={idx} 
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  // 💡 MODIFICATION: Added 'prose' class for markdown styling
                  className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                    msg.sender === 'user' 
                      ? 'bg-blue-600 text-white rounded-br-none' 
                      : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none shadow-sm prose'
                  }`}
                >
                  {/* 💡 MODIFICATION: Conditionally render ReactMarkdown */}
                  {msg.sender === 'bot' ? (
                      <ReactMarkdown>{msg.text}</ReactMarkdown>
                  ) : (
                      // User messages are plain text
                      <p>{msg.text}</p>
                  )}
                </div>
              </div>
            ))}
            
            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-200 p-3 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-2">
                  <Loader2 size={16} className="animate-spin text-blue-600" />
                  <span className="text-xs text-gray-500">Thinking...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-gray-100 shrink-0">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask a question..."
                className="flex-1 px-4 py-2 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send size={18} />
              </button>
            </div>
          </form>
        </div>
      )}

      {/* --- Toggle Button --- */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`h-16 w-16 rounded-full flex items-center justify-center shadow-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
          isOpen ? 'bg-red-500 hover:bg-red-600 rotate-90' : 'bg-blue-600 hover:bg-blue-700'
        }`}
        aria-label={isOpen ? "Close chat" : "Open chat"}
      >
        {isOpen ? <X size={32} className="text-white" /> : <MessageSquare size={32} className="text-white" />}
      </button>
    </div>
  );
};

export default ChatbotIcon;