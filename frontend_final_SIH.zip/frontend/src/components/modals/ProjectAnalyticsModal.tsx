// src/components/modals/ProjectAnalyticsModal.tsx

import React from "react";
import { BarChart } from "lucide-react";
import { Project, Task } from "../../types";
import { MOCK_USERS_DEPT } from "../../utils/helper";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";

interface ProjectAnalyticsModalProps {
    isOpen: boolean;
    onClose: () => void;
    project: Project;
    tasks: Task[];
}

const ProjectAnalyticsModal: React.FC<ProjectAnalyticsModalProps> = ({ isOpen, onClose, project, tasks }) => {
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.status === 'Completed' || t.status === 'Approved').length;
    const approvedTasks = tasks.filter(t => t.status === 'Approved').length;
    
    const overallProgress = totalTasks > 0 ? Math.round((approvedTasks / totalTasks) * 100) : 0;
    
    const userProgress = MOCK_USERS_DEPT.map(user => {
        const userTotal = tasks.filter(t => t.assignedToId === user._id).length;
        const userApproved = tasks.filter(t => t.assignedToId === user._id && t.status === 'Approved').length;
        return {
            name: user.name,
            progress: userTotal > 0 ? Math.round((userApproved / userTotal) * 100) : 0,
            approvedCount: userApproved,
            totalCount: userTotal
        };
    }).sort((a, b) => b.progress - a.progress);

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[800px]">
                <DialogHeader>
                    <DialogTitle className="text-2xl flex items-center gap-2 text-primary">
                        <BarChart className="h-6 w-6" /> Analytics: {project.projectName}
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-6">
                    <Card>
                        <CardHeader className="p-4">
                            <CardTitle className="text-lg">Overall Project Health</CardTitle>
                        </CardHeader>
                        <CardContent className="flex justify-around items-center text-center">
                            {/* ... (Rest of the CardContent remains the same) ... */}
                            <div>
                                <p className="text-5xl font-bold text-green-600">{overallProgress}%</p>
                                <p className="text-sm text-muted-foreground">Approved Progress</p>
                            </div>
                            <div>
                                <p className="text-3xl font-semibold">{totalTasks}</p>
                                <p className="text-sm text-muted-foreground">Total Actions</p>
                            </div>
                            <div>
                                <p className="text-3xl font-semibold">{approvedTasks}</p>
                                <p className="text-sm text-muted-foreground">Approved Actions</p>
                            </div>
                            <div>
                                <p className="text-3xl font-semibold">{completedTasks - approvedTasks}</p>
                                <p className="text-sm text-muted-foreground">Awaiting Approval</p>
                            </div>
                        </CardContent>
                    </Card>

                    <h3 className="font-semibold text-xl">Team Performance</h3>
                    <div className="space-y-2">
                        {userProgress.map(up => (
                            <div key={up.name} className="flex items-center gap-4">
                                <span className="font-medium w-40">{up.name}</span>
                                <div className="flex-1 bg-gray-200 rounded-full h-4">
                                    <div 
                                        className="bg-primary h-4 rounded-full" 
                                        style={{ width: `${up.progress}%` }}
                                    />
                                </div>
                                <span className="w-20 text-right text-sm text-muted-foreground">{up.approvedCount}/{up.totalCount} ({up.progress}%)</span>
                            </div>
                        ))}
                    </div>
                </div>
                <Button onClick={onClose}>Close Analytics</Button>
            </DialogContent>
        </Dialog>
    );
}

export default ProjectAnalyticsModal;