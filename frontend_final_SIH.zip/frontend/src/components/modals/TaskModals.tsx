// src/components/modals/TaskModals.tsx

/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import { CheckCircle, Info, CheckCheck } from "lucide-react";
import { Task, TaskStatus } from "../../types";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../ui/dialog";
import { Button } from "../ui/button";
import { Textarea } from "../ui/textarea";
import { Input } from "../ui/input";
import { ScrollArea } from "../ui/scroll-area"; 
import { Badge } from "../ui/badge";

// Type for the task update function
type HandleUpdateFn = (taskId: string, newStatus: TaskStatus, comment?: string, proof?: any) => void;

// --- Employee Completion Modal ---
interface EmployeeCompleteModalProps {
    isOpen: boolean;
    onClose: () => void;
    task: Task;
    handleUpdate: HandleUpdateFn;
}

export const EmployeeCompleteModal: React.FC<EmployeeCompleteModalProps> = ({ isOpen, onClose, task, handleUpdate }) => {
    const [comment, setComment] = useState('');
    const [file, setFile] = useState<File | null>(null);

    const handleSubmit = () => {
        if (!comment || !file) {
            alert("Comments and proof document upload are required.");
            return;
        }

        console.log(`Submitting proof for Task ${task._id}:`, { comment, fileName: file.name });
        const proofObject = {
            comment: comment,
            filePath: 'mock/path.pdf', // Mocked path
        };
        
        handleUpdate(task._id, 'Completed', comment, proofObject);
        onClose();
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 text-xl text-primary">
                        <CheckCircle className="h-5 w-5" /> Mark Action Completed
                    </DialogTitle>
                    <DialogDescription>
                        Provide proof and comments before submitting for manager approval.
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-4 py-4">
                    <p className="font-semibold">{task.actionText}</p>
                    <Textarea 
                        placeholder="Detailed comments on completion (required)" 
                        value={comment} 
                        onChange={(e) => setComment(e.target.value)} 
                        required 
                    />
                    <label className="block text-sm font-medium text-gray-700">Upload Proof Document (PDF/Image)</label>
                    <Input 
                        type="file" 
                        onChange={(e) => setFile(e.target.files ? e.target.files[0] : null)} 
                        required 
                        className="py-1"
                    />
                </div>
                
                <Button onClick={handleSubmit} disabled={!comment || !file}>
                    Submit for Manager Approval
                </Button>
            </DialogContent>
        </Dialog>
    );
};


// --- Manager Review Modal ---
interface ManagerReviewModalProps {
    isOpen: boolean;
    onClose: () => void;
    task: Task;
    handleUpdate: (taskId: string, newStatus: 'Pending' | 'Approved', comment?: string) => void;
}

export const ManagerReviewModal: React.FC<ManagerReviewModalProps> = ({ isOpen, onClose, task, handleUpdate }) => {
    const [managerComment, setManagerComment] = useState(task.managerComment || '');

    const handleReject = () => {
        if (!managerComment) {
            alert("Manager comment is required to reject the task.");
            return;
        }
        handleUpdate(task._id, 'Pending', managerComment);
        onClose();
    };

    const handleApprove = () => {
        handleUpdate(task._id, 'Approved', managerComment);
        onClose();
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                    <DialogTitle className="text-xl flex items-center gap-2 text-yellow-700">
                        <Info className="h-5 w-5" /> Review & Approval
                    </DialogTitle>
                    <DialogDescription>
                        Action submitted for completion: {task.actionText}
                    </DialogDescription>
                </DialogHeader>

                <ScrollArea className="h-64 pr-4 space-y-3">
                    <h4 className="font-semibold border-b pb-1">Employee Submission</h4>
                    <p className="text-sm text-muted-foreground italic">
                        "{task.completionProof?.comment || "No comment provided."}"
                    </p>
                    <Badge variant="secondary" className="text-xs">
                        Proof File: {task.completionProof?.filePath || "N/A"}
                    </Badge>

                    <h4 className="font-semibold border-b pb-1 pt-3">Manager Feedback</h4>
                    <Textarea 
                        placeholder="Add comments for approval or rejection." 
                        value={managerComment} 
                        onChange={(e) => setManagerComment(e.target.value)}
                    />
                </ScrollArea>

                <div className="flex justify-end gap-3">
                    <Button variant="outline" onClick={handleReject} className="border-red-500 text-red-500 hover:bg-red-50" disabled={!managerComment}>
                        Reject & Move to Pending
                    </Button>
                    <Button onClick={handleApprove} className="bg-green-600 hover:bg-green-700">
                        <CheckCheck className="h-4 w-4 mr-2" /> Final Approve
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
};