// src/components/modals/ProjectModals.tsx

/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect, useCallback } from "react";
import { List, Plus, User as UserIcon, FileText } from "lucide-react";
import API from "../../utils/api";
import { MOCK_DEPT } from "../../utils/helper";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { ScrollArea } from "../ui/scroll-area";
import { Badge } from "../ui/badge";

// Define Document structure (Simplified from Documents.jsx transformation)
interface Document {
    id: string; // The _id or source_id
    name: string; // Title
    allActions: any[]; // Used for AssignActionModal
}

// Define the structure for fetched team members
interface TeamMember {
    _id: string; // Employee ID used as unique identifier
    name: string;
    department: string;
}

// Define User structure
interface UserData {
    name: string;
    department: string;
    employeeId: string;
    // Assuming managerId is derived from employeeId/user context for project creation API
}

// --- Project Creation Form Component ---
interface ProjectFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    refreshProjects: (newId?: string) => void;
}

export const ProjectFormModal: React.FC<ProjectFormModalProps> = ({ isOpen, onClose, refreshProjects }) => {
    const [projectDetails, setProjectDetails] = useState({
        name: '',
        deadline: '',
        description: '',
        department: MOCK_DEPT,
        documents: [] as string[],
        users: [] as string[], // Holds assigned user IDs (employeeId)
    });
    const [isSaving, setIsSaving] = useState(false);
    const [loggedInUser, setLoggedInUser] = useState<UserData | null>(null);
    const [availableDocuments, setAvailableDocuments] = useState<Document[]>([]);
    const [loadingDocs, setLoadingDocs] = useState(false);
    const [availableUsers, setAvailableUsers] = useState<TeamMember[]>([]);
    const [loadingUsers, setLoadingUsers] = useState(false);


    // Document transformation logic (unmodified)
    const transformFetchedDocs = (docs: any[]): Document[] => {
        return docs.map((doc) => {
            const isMaximo = doc.source === "MAXIMO";
            let name = "Untitled Document";
            const rawActions = doc.analysis?.raw?.data?.actions_required || doc.raw_analysis?.data?.actions_required || [];

            if (doc.source === "gmail") {
                name = doc.subject || "Untitled Email";
            } else if (isMaximo) {
                name = doc.title || `Maximo Document: ${doc.source_id}`;
            } else { // Default/Drive/WhatsApp
                name = doc.fileName || "Untitled Document";
            }

            return {
                id: isMaximo ? doc.source_id : doc._id,
                name: name,
                allActions: rawActions,
            };
        });
    };


    // Fetch users by department (unmodified)
    const fetchDepartmentUsers = useCallback(async (department: string) => {
        if (!department || department === MOCK_DEPT) return;
        setLoadingUsers(true);
        try {
            const response = await API.get("/gmail/auth/by-department", {
                params: { department: department }
            });

            // Assuming response.data.data returns an array of user objects
            const users = response.data.data.filter((u: any) => u.department === department) as TeamMember[];
            setAvailableUsers(users);

        } catch (error) {
            console.error("Failed to fetch department users:", error);
            setAvailableUsers([]);
        } finally {
            setLoadingUsers(false);
        }
    }, []);

    // Fetch documents for the user's department (unmodified)
    const fetchDepartmentDocuments = useCallback(async (department: string) => {
        if (!department || department === MOCK_DEPT) return;
        setLoadingDocs(true);
        try {
            const response = await API.get("/messages/search", {
                params: { department: department }
            });
            const transformed = transformFetchedDocs(response.data);
            setAvailableDocuments(transformed);
        } catch (error) {
            console.error("Failed to fetch department documents:", error);
            setAvailableDocuments([]);
        } finally {
            setLoadingDocs(false);
        }
    }, []);


    // Effect to fetch logged-in user data, documents, AND users (unmodified)
    useEffect(() => {
        const fetchInitialData = async () => {
            if (!isOpen) return;

            try {
                const user: any = await API.fetchUser();
                setLoggedInUser(user);

                if (user.department) {
                    setProjectDetails(prev => ({
                        ...prev,
                        department: user.department,
                    }));
                    await Promise.all([
                        fetchDepartmentDocuments(user.department),
                        fetchDepartmentUsers(user.department)
                    ]);
                }
            } catch (error) {
                console.error("Failed to fetch initial data:", error);
            }
        };

        fetchInitialData();
    }, [isOpen, fetchDepartmentDocuments, fetchDepartmentUsers]);


    // UPDATED: Include assignedUserIds in the payload
    const handleSave = async () => {
        if (!projectDetails.name || !projectDetails.deadline || !projectDetails.department) {
            alert("Please fill in project name, deadline, and department.");
            return;
        }
        if (!loggedInUser || !loggedInUser.employeeId) {
            alert("Creator ID is missing. Please refresh and try again.");
            return;
        }

        setIsSaving(true);
        try {
            const payload = {
                managerId: loggedInUser.employeeId, // Use managerId for the creator as per schema logic
                projectName: projectDetails.name,
                initialDeadline: projectDetails.deadline,
                projectDescription: projectDetails.description,
                targetDepartment: projectDetails.department,
                relevantDocuments: projectDetails.documents,
                // MAP projectDetails.users array to the new schema field: assignedUserIds
                assignedUserIds: projectDetails.users,
            };

            const response = await API.post("/projects", payload);
            alert(`Project "${projectDetails.name}" saved successfully!`);
            refreshProjects(response.data.data._id);
            onClose();
        } catch (error) {
            console.error("Failed to save project:", (error as any).response?.data || error);
            alert("Failed to save project. Check console for details.");
        } finally {
            setIsSaving(false);
            setProjectDetails({
                name: '',
                deadline: '',
                description: '',
                department: loggedInUser?.department || MOCK_DEPT,
                documents: [],
                users: []
            });
            setAvailableDocuments([]);
            setAvailableUsers([]);
        }
    };

    // Helper to get selected document name (unmodified)
    const getDocumentNameById = (docId: string) => {
        return availableDocuments.find(d => d.id === docId)?.name || docId.substring(0, 8) + '...';
    };

    // Helper to get selected user name (unmodified)
    const getAssignedUserNameById = (userId: string) => {
        return availableUsers.find(u => u._id === userId)?.name || userId.substring(0, 8) + '...';
    };


    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[750px]">
                <DialogHeader>
                    <DialogTitle className="text-2xl flex items-center gap-2 text-primary">
                        <List className="h-6 w-6" /> Create New Project
                    </DialogTitle>
                </DialogHeader>

                <ScrollArea className="h-[450px] pr-4">
                    <div className="grid gap-4 py-4">
                        {/* 1. Project Details (Unmodified) */}
                        <h4 className="font-semibold text-lg border-b pb-1">Project Metadata</h4>
                        <Input
                            placeholder="Project Name (e.g., Q4 Safety Audit Prep)"
                            onChange={e => setProjectDetails({ ...projectDetails, name: e.target.value })}
                            value={projectDetails.name}
                        />
                        <div className="grid grid-cols-2 gap-4">
                            <Input type="date" title="Initial Deadline" onChange={e => setProjectDetails({ ...projectDetails, deadline: e.target.value })} value={projectDetails.deadline} />
                            <Select onValueChange={(val) => setProjectDetails({ ...projectDetails, department: val })} value={projectDetails.department}>
                                <SelectTrigger><SelectValue placeholder="Target Department" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value={projectDetails.department}>{projectDetails.department}</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <Textarea placeholder="Project Description" onChange={e => setProjectDetails({ ...projectDetails, description: e.target.value })} value={projectDetails.description} />

                        {/* 2. Document Selection (Unmodified) */}
                        <h4 className="font-semibold text-lg border-b pb-1 mt-4">Link Source Documents (Dept: {projectDetails.department})</h4>
                        {loadingDocs ? (
                            <p className="text-sm text-center text-muted-foreground">Loading documents for {projectDetails.department}...</p>
                        ) : availableDocuments.length === 0 ? (
                            <p className="text-sm text-center text-muted-foreground">No documents found for {projectDetails.department}.</p>
                        ) : (
                            <Select onValueChange={(docId) => setProjectDetails(prev => ({ ...prev, documents: [...prev.documents, docId] }))}>
                                <SelectTrigger>
                                    <SelectValue placeholder={`Select Documents to Link (${availableDocuments.length} available)`} />
                                </SelectTrigger>
                                <SelectContent>
                                    {availableDocuments
                                        // Filter out already selected documents
                                        .filter(doc => !projectDetails.documents.includes(doc.id))
                                        .map(doc => (
                                            <SelectItem key={doc.id} value={doc.id}>{doc.name}</SelectItem>
                                        ))}
                                </SelectContent>
                            </Select>
                        )}

                        <div className="flex flex-wrap gap-2">
                            {projectDetails.documents.map(docId => (
                                <Badge key={docId} variant="secondary" className="bg-blue-100 text-blue-800">
                                    <FileText className="h-3 w-3 mr-1" /> {getDocumentNameById(docId)}
                                </Badge>
                            ))}
                        </div>

                        {/* 3. User Assignment (Unmodified logic) */}
                        <h4 className="font-semibold text-lg border-b pb-1 mt-4">Assign Team Members (Dept: {projectDetails.department})</h4>
                        {loadingUsers ? (
                            <p className="text-sm text-center text-muted-foreground">Loading users for {projectDetails.department}...</p>
                        ) : availableUsers.length === 0 ? (
                            <p className="text-sm text-center text-muted-foreground">No users found in {projectDetails.department}.</p>
                        ) : (
                            <Select onValueChange={(userId) => setProjectDetails(prev => ({ ...prev, users: [...prev.users, userId] }))}>
                                <SelectTrigger>
                                    <SelectValue placeholder={`Select Users (${availableUsers.length} available)`} />
                                </SelectTrigger>
                                <SelectContent>
                                    {availableUsers
                                        .filter(user => user._id !== loggedInUser?.employeeId && !projectDetails.users.includes(user._id))
                                        .map(user => (
                                            <SelectItem key={user._id} value={user._id}>{user.name}</SelectItem>
                                        ))}
                                </SelectContent>
                            </Select>
                        )}

                        <div className="flex flex-wrap gap-2">
                            {/* Creator Badge */}
                            {loggedInUser && (
                                <Badge variant="outline" className="bg-green-100 text-green-800">
                                    <UserIcon className="h-3 w-3 mr-1" /> {loggedInUser.name} (Creator)
                                </Badge>
                            )}

                            {projectDetails.users.map(userId => (
                                <Badge key={userId} variant="outline">
                                    <UserIcon className="h-3 w-3 mr-1" /> {getAssignedUserNameById(userId)}
                                </Badge>
                            ))}
                        </div>
                    </div>
                </ScrollArea>

                <Button onClick={handleSave} className="mt-4" disabled={isSaving}>
                    {isSaving ? "Saving..." : "Save Project to Database"}
                </Button>
            </DialogContent>
        </Dialog>
    );
};


// --- Task Assignment Modal (UPDATED PROPS) ---
interface AssignActionModalProps {
    isOpen: boolean;
    onClose: () => void;
    userId: string;
    projectId: string;
    refreshTasks: (id: string) => void;
    availableDocuments: Document[];
    availableUsers: TeamMember[]; // Used for finding the assigned user's name
}

export const AssignActionModal: React.FC<AssignActionModalProps> = ({
    isOpen,
    onClose,
    userId,
    projectId,
    refreshTasks,
    availableDocuments,
    availableUsers // Destructure to access user list for name lookup
}) => {
    // UPDATED: Find user from the passed prop (availableUsers)
    const user = availableUsers.find(u => u._id === userId);

    const initialDocWithActions = availableDocuments.find(doc => doc.allActions.length > 0);

    const [selectedDocId, setSelectedDocId] = useState(initialDocWithActions?.id || '');
    const [selectedActionId, setSelectedActionId] = useState(initialDocWithActions?.allActions[0]?.id || '');
    const [isAssigning, setIsAssigning] = useState(false);

    const doc = availableDocuments.find(d => d.id === selectedDocId);
    // Note: Assuming action objects have a unique `id`, `action`, `deadline`, and `priority` property.
    const action = doc?.allActions.find((a: any) => a.id === selectedActionId);

    useEffect(() => {
        if (isOpen) {
            const newInitialDoc = availableDocuments.find(doc => doc.allActions.length > 0);
            setSelectedDocId(newInitialDoc?.id || '');
            setSelectedActionId(newInitialDoc?.allActions[0]?.id || '');
        }
    }, [isOpen, availableDocuments]);


    const handleAssign = async () => {
        if (!action || !user || !projectId) return;

        setIsAssigning(true);
        try {
            const payload = {
                projectId: projectId,
                assignedToId: userId,
                sourceDocumentId: selectedDocId,
                actionText: action.action,
                sourceDeadline: action.deadline,
                status: 'Pending',
                priority: action.priority,
            };

            await API.post("/tasks", payload);
            alert(`Action assigned to ${user.name}!`);
            refreshTasks(projectId);
            onClose();
        } catch (error) {
            console.error("Failed to assign task:", (error as any).response?.data || error);
            alert("Failed to assign task. Check console.");
        } finally {
            setIsAssigning(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 text-primary">
                        <Plus className="h-5 w-5" /> Assign Document Action to {user?.name}
                    </DialogTitle>
                    <DialogDescription>
                        Select an extracted action from a linked document and assign it as a task.
                    </DialogDescription>
                </DialogHeader>

                <div className="grid gap-4 py-4">
                    {/* 1. Document Selection */}
                    <Select onValueChange={setSelectedDocId} value={selectedDocId}>
                        <SelectTrigger><SelectValue placeholder="Select Source Document" /></SelectTrigger>
                        <SelectContent>
                            {availableDocuments.map(d => (
                                <SelectItem key={d.id} value={d.id} disabled={d.allActions.length === 0}>
                                    {d.name} {d.allActions.length === 0 && '(No Actions)'}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>

                    {/* 2. Action Selection */}
                    <Select onValueChange={setSelectedActionId} value={selectedActionId} disabled={!doc || doc.allActions.length === 0}>
                        <SelectTrigger><SelectValue placeholder="Select Action Required" /></SelectTrigger>
                        <SelectContent>
                            {doc?.allActions.map((a: any) => (
                                <SelectItem key={a.id} value={a.id}>
                                    {a.action} <Badge variant={a.priority === 'High' ? 'destructive' : 'default'} className="ml-2">{a.priority}</Badge>
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>

                    {action && <p className="text-sm text-gray-600 mt-2 p-2 border rounded-md bg-muted">Deadline: {action.deadline || 'N/A'}</p>}
                </div>

                <Button onClick={handleAssign} disabled={isAssigning || !action}>
                    {isAssigning ? "Assigning..." : "Assign Action as Task"}
                </Button>
            </DialogContent>
        </Dialog>
    );
};