import { useTranslation } from "react-i18next";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard, FileText, FolderOpen, Users, BarChart3,
  Settings, Search, Tags, Shield, ChevronLeft, ChevronRight, Puzzle, Archive,
  UploadCloud, Map // <--- Imported Map Icon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface SidebarProps {
  isOpen: boolean;
  onToggle?: () => void;
  className?: string;
}

export const Sidebar = ({ isOpen, onToggle, className }: SidebarProps) => {
  const { t } = useTranslation();

  const navigationItems = [
    { id: "dashboard", icon: LayoutDashboard, href: "/", color: "text-primary" },
    { id: "integrations", icon: Puzzle, href: "/settings?tab=integrations", color: "text-orange-600" },
    { id: "summariq", icon: FileText, href: "/documents", color: "text-cyan-600" },
    { id: "smartMap", icon: Map, href: "/map", color: "text-yellow-600" },
    { id: "fileUpload", icon: UploadCloud, href: "/proposal", color: "text-blue-600" },
    { id: "project", icon: FolderOpen, href: "/project", color: "text-purple-600" },
    { id: "shelfy", icon: Archive, href: "/categories", color: "text-pink-600" },
  ];

  const managementItems = [
    { id: "analytics", icon: BarChart3, href: "/analytics", color: "text-emerald-600" },
    { id: "settings", icon: Settings, href: "/settings", color: "text-gray-600" },
  ];

  return (
    <aside
      className={cn(
        "relative flex flex-col bg-surface border-r border-border shadow-soft transition-smooth",
        isOpen ? "w-64" : "w-16",
        className
      )}
    >
      <Button
        variant="ghost"
        size="icon"
        onClick={onToggle}
        className="absolute -right-3 top-6 z-10 h-6 w-6 rounded-full border border-border bg-surface shadow-md hover:shadow-lg"
      >
        {isOpen ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
      </Button>

      <div className="flex-1 overflow-y-auto py-6">
        {/* Main Navigation */}
        <div className="px-3">
          {isOpen && (
            <h2 className="mb-4 px-3 text-sm font-semibold text-muted-foreground">
              {t('sidebar.navigationTitle')}
            </h2>
          )}
          <nav className="space-y-2">
            {navigationItems.map((item) => (
              <NavLink
                key={item.href}
                to={item.href}
                data-tour={item.id}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-smooth hover:bg-muted/50",
                    isActive ? "bg-primary/10 text-primary shadow-sm" : "text-foreground hover:text-primary"
                  )
                }
              >
                <item.icon className={cn("h-5 w-5 flex-shrink-0", item.color)} />
                {isOpen && (
                  <span>
                    {item.id === "smartMap" 
                      ? "SmartMap Insight" 
                      : t(`sidebar.navItems.${item.id}`)
                    }
                  </span>
                )}
                
              </NavLink>
            ))}
          </nav>
        </div>

        {/* Management Section */}
        <div className="mt-8 px-3">
          {isOpen && (
            <h2 className="mb-4 px-3 text-sm font-semibold text-muted-foreground">
              {t('sidebar.managementTitle')}
            </h2>
          )}
          <nav className="space-y-2">
            {managementItems.map((item) => (
              <NavLink
                key={item.href}
                to={item.href}
                data-tour={item.id}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-smooth hover:bg-muted/50",
                    isActive ? "bg-primary/10 text-primary shadow-sm" : "text-foreground hover:text-primary"
                  )
                }
              >
                <item.icon className={cn("h-5 w-5 flex-shrink-0", item.color)} />
                {isOpen && <span>{t(`sidebar.mgmtItems.${item.id}`)}</span>}
              </NavLink>
            ))}
          </nav>
        </div>
      </div>

      {/* Footer */}
      {isOpen && (
        <div className="border-t border-border p-4">
          <p className="text-xs text-muted-foreground">
            {t('sidebar.footer')}
          </p>
        </div>
      )}
    </aside>
  );
};