import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../utils/api";
import { useLang } from "@/context/langContext";
import { Bell, Search, Settings, User, Menu, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import NotificationsList from './ui/viewNotifications';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import logo from "@/assets/logo-kmrl.png";

interface HeaderProps {
  onToggleSidebar?: () => void;
}

interface UserType {
  name: string;
  email: string;
  picture?: string;
  profileCompleted?: boolean;
  jobTitle?: string;
  employeeId?: string;
  workLocation?: string;
  department?: string;
  preferredLanguage?: string;
}



export const Header = ({ onToggleSidebar }: HeaderProps) => {
  const navigate = useNavigate();
  const [user, setUser] = useState<UserType | null>(null);
  // Renamed to openNotifications to avoid conflict with dropdown 'open'
  const [openNotifications, setOpenNotifications] = useState(false);
  const [pendingCount, setPendingCount] = useState(5);
  //const { t, i18n } = useTranslation();//remove later
  const { setLang, lang } = useLang();

  useEffect(() => {
  const loadUser = async () => {
    try {
      const fetchedUser = await API.fetchUser();
      setUser(fetchedUser);

      const isOtpVerified =
        sessionStorage.getItem("otp_verified_session") === "true";

      // ✅ ALWAYS force OTP after fresh login
      if (fetchedUser?.email && !isOtpVerified) {
        navigate("/otp-verification", { replace: true });
        return;
      }

      // ✅ If OTP done but profile incomplete → go to profile
      if (isOtpVerified && fetchedUser?.email && !fetchedUser.profileCompleted) {
        navigate("/profile", { replace: true });
        return;
      }

    } catch (err) {
      console.error("User fetch failed:", err);
    }
  };

  loadUser();
}, [navigate]);


  useEffect(() => {
    const fetchInitialCount = async () => {
        try {
          const response = await API.get("/messages/notifications", {
            params: { showCompleted: false }
          });
          setPendingCount(response.data.length);
        } catch (error) {
          console.error("Failed to fetch notification count:", error);
          setPendingCount(0);
        }
    };
    if (user) {
        fetchInitialCount();
    }
    
}, [user]);

  const userInitial = user?.name ? user.name.charAt(0).toUpperCase() : null;
  
  const handleTaskCompletion = () => {
    setPendingCount(prev => Math.max(0, prev - 1));
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-surface shadow-soft">
      <div className="container flex h-16 items-center gap-4 px-4">
        {/* Mobile menu */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={onToggleSidebar}
        >
          <Menu className="h-5 w-5" />
        </Button>

        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-0.1">
            <h1 className="text-xl font-extrabold bg-gradient-to-r from-[#4f46e5] via-[#3b82f6] to-[#8b5cf6] bg-clip-text text-transparent">
              Patram
            </h1>
            <img src={logo} alt="Infinity Logo" className="h-20 w-20 object-contain" />
          </div>
        </div>

        {/* Search */}
        <div className="flex flex-1 items-center gap-4 md:gap-6">
          <div className="relative hidden md:flex flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search documents, files, and more..."
              className="w-full pl-9 bg-muted/30 border-muted"
            />
          </div>
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="md:hidden">
            <Search className="h-5 w-5" />
          </Button>

          {/* 1. Notifications Dropdown (Popover functionality) */}
          <DropdownMenu open={openNotifications} onOpenChange={setOpenNotifications}>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative"
              >
                <Bell className="h-5 w-5" />
                {pendingCount > 0 && (
                  <span className="absolute -right-2 -top-2 px-1.5 py-0.5 min-w-[20px] rounded-full bg-red-500 text-xs text-white font-bold flex items-center justify-center leading-none">
                    {pendingCount}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="p-0 w-auto" align="end" forceMount>
              <NotificationsList onTaskCompleted={handleTaskCompletion} />
              <div className="border-t pt-1 pb-2 flex justify-center">
                <Button variant="link" size="sm" onClick={() => {
                  setOpenNotifications(false);
                }}>
                </Button>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/settings")}
          >
            <Settings className="h-5 w-5" />
          </Button>

          {/* Language Switcher Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <Languages className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>

            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Language</DropdownMenuLabel>
              <DropdownMenuSeparator />

              <DropdownMenuItem onClick={() => setLang("en")}>English</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLang("hi")}>हिन्दी</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLang("ml")}>മലയാളം</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>


          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="relative h-9 w-9 rounded-full"
                data-tour="login"
              >
                <Avatar className="h-9 w-9">
                  {user?.picture ? (
                    <AvatarImage src={user.picture} alt="Profile" />
                  ) : user ? (
                    <AvatarFallback className="red text-primary-foreground">
                      {userInitial}
                    </AvatarFallback>
                  ) : (
                    <AvatarFallback>
                      <User className=" red h-5 w-5" />
                    </AvatarFallback>
                  )}
                </Avatar>
              </Button>
            </DropdownMenuTrigger>

            <DropdownMenuContent className="w-56" align="end" forceMount>
              {user ? (
                <>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.name}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>

                  <DropdownMenuSeparator />

                  <DropdownMenuItem onClick={() => navigate("/profile")}>
                    Profile Settings
                  </DropdownMenuItem>
                  <DropdownMenuItem>Help & Support</DropdownMenuItem>

                  <DropdownMenuSeparator />

                  <DropdownMenuItem
                    className="text-destructive"
                    onClick={async () => {
                      try {
                        await API.post("/gmail/auth/google/logout", {}, { withCredentials: true });
                        setUser(null);
                        sessionStorage.removeItem('otp_verified_session'); // Clear session on logout
                        window.location.reload();
                      } catch (err) {
                        console.error("Logout failed:", err);
                      }
                    }}
                  >
                    Sign out
                  </DropdownMenuItem>
                </>
              ) : (
                <>
                  <DropdownMenuLabel className="font-normal">
                    <p className="text-sm font-medium leading-none">Welcome Guest</p>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />

                  <DropdownMenuItem
                    onClick={() => {
                      const backend =
                      window.location.hostname === "localhost"
                        ? "http://localhost:5000"
                        : "https://kmrl-backend-1.onrender.com";

                      window.location.href = `${backend}/api/gmail/auth/google`;
                    }}
                  >
                    Login/Register
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

        </div>
      </div>
    </header>
  );
};