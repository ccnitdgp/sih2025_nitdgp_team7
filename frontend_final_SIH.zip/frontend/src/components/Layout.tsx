import { useState } from "react";
import { Header } from "./Header";
import { Sidebar } from "./Sidebar";
import ChatbotIcon from "./Chatbot";

interface LayoutProps {
  children: React.ReactNode;
}


export const Layout = ({ children }: LayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isChatOpen, setIsChatOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header onToggleSidebar={toggleSidebar} />
      
      <div className="flex h-[calc(100vh-var(--header-height))]">
        <Sidebar isOpen={sidebarOpen} onToggle={toggleSidebar} />
        
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto p-6">
            {children}
          </div>
        </main>
      </div>

      {isChatOpen}
      <ChatbotIcon onClick={toggleChat} />
    </div>
  );
};