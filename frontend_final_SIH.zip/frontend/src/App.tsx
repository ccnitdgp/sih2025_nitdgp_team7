import { useEffect } from "react";
import API from "./utils/api";

import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import { LangProvider } from "./context/langContext";
import Index from "./pages/Index";
import Documents from "./pages/Documents";
import Manager from "./pages/Manager"; 
import Upload from "./pages/Upload";
import Map from "./pages/MetroMap"; // <--- Importing the MetroMap page
import Categories from "./pages/Categories";
import Users from "./pages/Users";
import FinanceAnalytics from "./pages/Analytics";
import Security from "./pages/Security";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";
import Dashboard from "./pages/Dashboard";
import Tour from "./components/Tour";
import File from "./pages/File";
import ProfilePage from "./pages/Profile";
import ProjectBoard from "./components/ui/ProjectBoard";
import OtpVerificationPage from "./pages/OtpVerificationPage";

import Proposal from "./pages/Proposal";
import VendorPortal from "./pages/VendorPortal";

const queryClient = new QueryClient();

const App = () => {

  // Restore active user on frontend load
  useEffect(() => {
    API.fetchUser();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <LangProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/file" element={<File />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/whatsapp" element={<Dashboard />} />
              <Route path="/documents" element={<Documents />} />
              <Route path="/manager" element={<Manager />} />
              <Route path="/upload" element={<Upload />} />
              <Route path="/map" element={<Map />} /> {/* <--- Added SmartMap Route */}
              <Route path="/categories" element={<Categories />} />
              <Route path="/otp-verification" element={<OtpVerificationPage />} />
              <Route path="/proposal" element={<Proposal />} />
              <Route path="/proposal/:token" element={<VendorPortal />} />
              <Route path="/users" element={<Users />} />
              <Route path="/analytics" element={<FinanceAnalytics />} />
              <Route path="/security" element={<Security />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/project" element={<ProjectBoard />} />
              <Route path="*" element={<NotFound />} />
            </Routes>

            <Tour />
          </BrowserRouter>
        </LangProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;