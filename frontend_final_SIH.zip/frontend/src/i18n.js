import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Import your translation files
import translationEN from './locales/en/translation.json';
import translationHI from './locales/hi/translation.json';
import translationML from './locales/ml/translation.json';

const resources = {
  en: {
    translation: translationEN
  },
  hi: {
    translation: translationHI
  },
  ml: {
    translation: translationML
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en', // default language
    debug: true, 
    interpolation: {
      escapeValue: false 
    },
    backend: {
      // Path where your translation files are located
      loadPath: '/locales/{{lng}}/{{ns}}.json',
    },
  });

export default i18n;