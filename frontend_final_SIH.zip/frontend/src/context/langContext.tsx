import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import axios from "axios";

const LangContext = createContext({
  lang: "en",
  setLang: (lang: string) => {},
  translate: async (text: string) => text
});

export const LangProvider = ({ children }: { children: React.ReactNode }) => {
  const [lang, setLang] = useState("en");

  const translate = useCallback(
    async (text: string) => {
      if (lang === "en") return text;

      try {
        const res = await axios.post("http://localhost:5000/api/translate", {
          text,
          targetLang: lang
        }, { withCredentials: true });

        return res.data.translated || text;
      } catch (err) {
        console.error("❌ Translation failed for:", text, err);
        return text;
      }
    },
    [lang]
  );

  return (
    <LangContext.Provider value={{ lang, setLang, translate }}>
      {children}
    </LangContext.Provider>
  );
};

export const useLang = () => useContext(LangContext);
