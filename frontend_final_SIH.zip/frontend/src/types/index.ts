// src/types/index.ts

export interface Project {
    _id: string;
    projectName: string;
    initialDeadline: string;
    managerId: string;
    targetDepartment: string;
    assignedUserIds: string[];
}

export interface User {
    _id: string;
    name: string;
    dept: string;
}

export interface Task {
    _id: string;
    projectId: string;
    assignedToId: string; 
    sourceDocumentId: string; 
    actionText: string;
    status: 'Pending' | 'Completed' | 'Approved';
    priority: 'High' | 'Medium' | 'Low';
    sourceDeadline: string;
    completionProof?: { 
        comment: string; 
        filePath: string; 
        uploadedAt: string;
    };
    managerComment?: string;
}

export interface Document {
    _id: string;
    title: string;
    dept: string;
    actions: { id: string; text: string; priority: string; sourceDeadline: string }[];
}

export interface TaskGroup {
    user: User;
    Pending: Task[];
    Completed: Task[];
    Approved: Task[];
}

export type GroupedTasks = { [key: string]: TaskGroup };

// Re-export shared types for convenience
export type TaskStatus = Task['status'];