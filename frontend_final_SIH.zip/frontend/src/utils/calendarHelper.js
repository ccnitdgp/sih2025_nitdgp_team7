// src/utils/calendarHelpers.js

/**
 * Ensures the date is explicitly treated as a number for safe comparison.
 * FIX for TypeScript error: "The left-hand side of an arithmetic operation must be..."
 */
const safeGetTime = (dateString) => {
    const date = new Date(dateString);
    // Use isNaN to check for 'Invalid Date' and return 0 or a safe fallback if needed
    return isNaN(date.getTime()) ? 0 : date.getTime();
};

export const generateMonthGrid = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();

    // Start on the first day of the month
    const firstDayOfMonth = new Date(year, month, 1);
    // Calculate the start of the week for the first day (Sun=0, Mon=1, etc.)
    const startDayOfWeek = firstDayOfMonth.getDay(); 

    // Find the date corresponding to the first cell of the calendar grid
    const startDate = new Date(firstDayOfMonth);
    startDate.setDate(firstDayOfMonth.getDate() - startDayOfWeek);

    const days = [];
    // Generate 6 weeks (42 days) to ensure the full month is shown
    for (let i = 0; i < 42; i++) {
        const currentDate = new Date(startDate);
        currentDate.setDate(startDate.getDate() + i);
        days.push(currentDate);
    }
    return days;
};

/**
 * Transforms the documents data (with nested actions) into a flat list of calendar events.
 * @param {Array} documents - The transformed documents array from your fetchDocuments logic.
 * @returns {Array} - Array of calendar event objects.
 */
// export const transformActionsToEvents = (documents) => {
//     const events = [];

//     documents.forEach((doc) => {
//         // Only include actions with a valid deadline
//         const validActions = doc.allActions.filter(
//             (action) => action.deadline && action.deadline.toLowerCase() !== 'n/a'
//         );

//         validActions.forEach((action, index) => {
//             // Create the event object
//             events.push({
//                 id: `${doc.id}-action-${index}`,
//                 title: action.action || `Action for ${doc.name}`,
//                 start: action.deadline, // FullCalendar uses 'start' for the date
//                 priority: action.priority || 'Normal',
//                 assigned: action.assigned_department || 'Unassigned',
//                 documentName: doc.name,
//                 documentSource: doc.source,
//                 documentId: doc.id,
//             });
//         });
//     });

//     // Sort events by date using the safe method to prevent errors
//     events.sort((a, b) => safeGetTime(a.start) - safeGetTime(b.start));

//     return events;
// };
const generateRandomRecentDate = () => {
    const today = new Date();
    // 30 days in milliseconds
    const thirtyDaysAgo = today.getTime() - (30 * 24 * 60 * 60 * 1000); 
    
    // Generate a timestamp between 30 days ago and today
    const randomTime = thirtyDaysAgo + Math.random() * (today.getTime() - thirtyDaysAgo);
    
    const randomDate = new Date(randomTime);
    
    // Set the time to a safe, constant local time (e.g., 10 AM)
    randomDate.setHours(10, 0, 0, 0); 
    
    // Return an ISO string that starts the day cleanly
    return randomDate.toISOString(); 
};
export const transformActionsToEvents = (documents) => {
    const events = [];

    documents.forEach((doc) => {
        doc.allActions.forEach((action, index) => {
            
            let finalDeadline = action.deadline;
            
            const isDeadlineMissing = !action.deadline || 
                                      action.deadline.toLowerCase() === 'n/a' || 
                                      new Date(action.deadline).toString() === 'Invalid Date';

            if (isDeadlineMissing) {
                // Assign a temporary, random, recent date
                finalDeadline = generateRandomRecentDate();
                
                action.action = action.action; 
                action.priority = "Normal"; 
            }

            // Only push the action if it now has a valid/placeholder date
            if (finalDeadline) {
                events.push({
                    id: `${doc.id}-action-${index}`,
                    title: action.action || `Action for ${doc.name}`,
                    start: finalDeadline,
                    priority: action.priority || 'Normal',
                    assigned: action.assigned_department || 'Unassigned',
                    documentName: doc.name,
                    documentSource: doc.source,
                    documentId: doc.id,
                });
            }
        });
    });

    events.sort((a, b) => safeGetTime(a.start) - safeGetTime(b.start));

    return events;
};
/**
 * Returns the shadcn/ui badge variant based on priority.
 */
export const getPriorityVariant = (priority) => {
    const p = priority?.toLowerCase();
    if (p === "high" || p === "critical") return "destructive";
    if (p === "medium") return "secondary";
    return "outline";
};

/**
 * Returns the hexadecimal color code for FullCalendar events.
 */
export const getEventColor = (priority) => {
    const p = priority?.toLowerCase();
    if (p === "high" || p === "critical") return "#ef4444"; // Tailwind red-500
    if (p === "medium") return "#a1a1aa"; // Tailwind gray-400
    return "#3b82f6"; // Tailwind blue-500
};