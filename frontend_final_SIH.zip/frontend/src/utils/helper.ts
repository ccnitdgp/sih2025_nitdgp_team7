// src/utils/helpers.ts

import { Task, User, Document, GroupedTasks } from "../types";

// --- MOCK/HELPER DATA ---
export const MOCK_DEPT = "Rolling Stock Maintenance";
export const CURRENT_USER_ID = '654321012345678901230011'; 
// 💡 Change to 'Junior Engineer' to test employee view
export const CURRENT_USER_JOB: string = 'Manager'; 

export const MOCK_USERS_DEPT: User[] = [
    { _id: '654321012345678901230011', name: 'Alok Varma (Manager)', dept: MOCK_DEPT },
    { _id: '654321012345678901230012', name: 'Priya Reddy (JE)', dept: MOCK_DEPT },
];

export const MOCK_DOCUMENTS_DEPT: Document[] = [
    { _id: '654321012345678901230001', title: 'Safety Bulletin 04/25', dept: MOCK_DEPT, actions: [
      { id: 'a1', text: 'Verify brake line pressure on all Kochi fleet trains.', priority: 'High', sourceDeadline: '2026-01-15T00:00:00.000Z' },
      { id: 'a2', text: 'Update maintenance logs for bogie inspection procedure.', priority: 'Medium', sourceDeadline: '2026-01-20T00:00:00.000Z' },
    ]},
];
// --- END MOCK/HELPER DATA ---


// Helper to group tasks by user and status
export const groupTasks = (tasks: Task[]): GroupedTasks => {
    const uniqueUserIds = [...new Set(tasks.map(t => t.assignedToId))];
    const userMap = MOCK_USERS_DEPT.reduce((acc, user) => { acc[user._id] = user; return acc; }, {} as Record<string, User>);

    const grouped: GroupedTasks = uniqueUserIds.reduce((acc, userId) => {
        const user = userMap[userId] || { _id: userId, name: `User ${userId.substring(0, 8)}`, dept: 'N/A' };
        
        acc[userId] = {
            user,
            Pending: tasks.filter(t => t.assignedToId === userId && t.status === 'Pending'),
            Completed: tasks.filter(t => t.assignedToId === userId && t.status === 'Completed'),
            Approved: tasks.filter(t => t.assignedToId === userId && t.status === 'Approved'),
        };
        return acc;
    }, {} as GroupedTasks);
    
    // Add users with no tasks
    MOCK_USERS_DEPT.forEach(user => {
        if (!grouped[user._id]) {
            grouped[user._id] = { user, Pending: [], Completed: [], Approved: [] };
        }
    });

    return grouped;
};