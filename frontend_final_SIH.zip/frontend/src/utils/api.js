import axios from "axios";

const API = axios.create({
  baseURL: "https://kmrl-backend-1.onrender.com/api",
  withCredentials: true
});

// Add token automatically if present
API.interceptors.request.use((req) => {
  const token = localStorage.getItem("token");
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
  return req;
});

/* Global method for fetching logged-in user */
API.fetchUser = async () => {
  try {
    const res = await API.get("/gmail/auth/me", { withCredentials: true });
    return res.data.loggedIn ? res.data : null;
  } catch (err) {
    return null;
  }
};

export default API;
