import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    // --- START OF PROXY CONFIG ---
    proxy: {
      // 1. Proxy for your local backend (solves localhost:5000 CORS)
      "/api": {
        target: "http://localhost:5000",
        changeOrigin: true,
        secure: false,
      },
      // 2. Proxy for the RAG API (solves remote Cloud Run CORS)
      "/rag-api": {
        target: "https://rag-based-api-681627636377.asia-south1.run.app",
        changeOrigin: true,
        secure: false,
        // This removes '/rag-api' from the path before sending to Google Cloud
        rewrite: (path) => path.replace(/^\/rag-api/, ""), 
      },
    },
    // --- END OF PROXY CONFIG ---
  },
  plugins: [react(), mode === "development" && componentTagger()].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
}));