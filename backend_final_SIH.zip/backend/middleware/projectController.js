// controllers/projectController.js

const Project = require('../models/Project');

// POST /api/projects
exports.createProject = async (req, res) => {
    try {
        const { projectName, initialDeadline, projectDescription, relevantDocuments, targetDepartment } = req.body;
        // Assuming 'req.user.id' is set by an authentication middleware (the managerId)

        const newProject = await Project.create({
            projectName,
            initialDeadline,
            projectDescription,
            relevantDocuments,
            targetDepartment,
            managerId: req.user.id, // Must be fetched from authentication token/session
        });

        res.status(201).json({ success: true, data: newProject });
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
};

exports.getManagerProjects = async (req, res) => {
    try {
        // Assuming 'req.user.id' is the authenticated manager's ID
        const projects = await Project.find({ managerId: req.user.id })
            .select('projectName initialDeadline targetDepartment') // Only fetch necessary fields
            .sort({ createdAt: -1 });

        res.status(200).json({ success: true, data: projects });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Server Error' });
    }
};