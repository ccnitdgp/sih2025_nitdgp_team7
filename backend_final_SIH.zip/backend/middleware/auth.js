const User = require("../models/User");

module.exports = async function (req, res, next) {
  // OAuth auth is tracked via session
  if (!req.session || !req.session.email) {
    return res.status(401).json({ msg: "Not authenticated" });
  }

  try {
    const user = await User.findOne({ email: req.session.email });

    if (!user || !user.googleConnected) {
      return res.status(401).json({ msg: "OAuth not connected for this user" });
    }

    req.user = user; // attach full user document
    next();
  } catch (err) {
    return res.status(500).json({ msg: "Server error validating OAuth session" });
  }
};