// controllers/taskController.js

const Task = require('../models/Task');

// POST /api/tasks
exports.createTask = async (req, res) => {
    try {
        // Note: The actionText and sourceDeadline usually come from a document lookup service
        const newTask = await Task.create(req.body);

        res.status(201).json({ success: true, data: newTask });
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
};

exports.getTasksByProject = async (req, res) => {
    try {

        const tasks = await Task.find({ 
            projectId: req.params.projectId 
            // In a real app, you might add: assignedToId: { $in: [usersInDepartment] }
        })
        // .populate('assignedToId', 'name') // Pull user name for display
        // .populate('sourceDocumentId', 'fileName') // Pull document name/ID for display
        .sort({ status: 1, createdAt: 1 });
        console.log(tasks);

        res.status(200).json({ success: true, data: tasks });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Server Error' });
    }
};

exports.updateTaskStatus = async (req, res) => {
    const { status } = req.body;
    const update = { status };
    
    if (status === 'Completed') {
        update.completedAt = new Date();
    }
    if (status === 'Approved') {
        update.approvedAt = new Date();
    }

    try {
        const task = await Task.findByIdAndUpdate(req.params.id, update, { new: true });
        if (!task) {
            return res.status(404).json({ success: false, error: 'Task not found' });
        }
        res.status(200).json({ success: true, data: task });
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
};