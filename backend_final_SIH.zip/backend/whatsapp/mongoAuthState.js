const {
  BufferJSON,
  initAuthCreds,
} = require("@whiskeysockets/baileys");
const WhatsappSession = require("../models/WhatsappSession");

const CREDS_KEY_ID = "credentials_store"; // Constant used for the main credential document

/**
 * Creates a MongoDB-based authentication state store for Baileys.
 * @param {string} userId - The unique identifier for the user/session.
 * @returns {Promise<{state: {creds: any, keys: any}, saveCreds: () => Promise<void>}>}
 */
async function useMongoAuthState(userId) {
  // 1. Fetch the existing credentials record (the main document)
  let credsRecord = await WhatsappSession.findOne({
    userId: userId,
    key: CREDS_KEY_ID,
  });
  let creds;

  if (credsRecord && credsRecord.value) {
    try {
      creds = JSON.parse(credsRecord.value, BufferJSON.reviver);
    } catch (e) {
      console.error(
        `[MongoAuth] Failed to parse credentials for user ${userId}. Starting fresh.`,
        e
      );
      creds = initAuthCreds();
    }
  } else {
    creds = initAuthCreds();
  } // --- Keys Storage ---

  const keys = {
    // GET: Baileys provides type ('pre-key', 'session', etc.) and an array of IDs (numbers or strings)
    get: async (type, ids) => {
      const data = {};
      // Ensure ids are non-empty and converted to strings for the query
      const stringIds = ids.map((id) => id.toString()).filter((id) => id);

      if (stringIds.length === 0) return data;

      const records = await WhatsappSession.find({
        userId: userId,
        type: type,
        key: { $in: stringIds },
      });

      for (const record of records) {
        try {
          data[record.key] = JSON.parse(record.value, BufferJSON.reviver);
        } catch (e) {
          console.error(
            `[MongoAuth] Error parsing key data for ${type}:${record.key}`,
            e.message
          );
        }
      }
      return data;
    },

    // SET: Baileys passes an object containing key updates { 'type': { 'id': 'value' } }
    set: async (data) => {
      const operations = [];
      for (const type in data) {
        for (const id in data[type]) {
          const value = data[type][id];

          // CRITICAL: Ensure ID is a string for MongoDB key field consistency
          const stringKey = id.toString(); // Serialize the key/value data

          const jsonValue = JSON.stringify(value, BufferJSON.replacer);

          operations.push(
            WhatsappSession.updateOne(
              { userId: userId, type: type, key: stringKey },
              { $set: { value: jsonValue, updatedAt: new Date() } },
              { upsert: true }
            )
          );
        }
      }
      // Execute all updates simultaneously
      await Promise.all(operations);
      // Removed success log from keys.set to reduce console spam during heavy sync
    },

    // DEL: Baileys passes an object of key removals { 'type': [ 'id1', 'id2' ] }
    del: async (data) => {
      const operations = [];
      for (const type in data) {
        // Ensure keys are strings for deletion query
        const keysToDelete = data[type]
          .map((key) => key.toString())
          .filter((key) => key);

        if (keysToDelete.length > 0) {
          operations.push(
            WhatsappSession.deleteMany({
              userId: userId,
              type: type,
              key: { $in: keysToDelete },
            })
          );
        }
      }
      await Promise.all(operations);
    },
  }; // --- Credentials Saving --- // This function is triggered by sock.ev.on("creds.update")

  const saveCreds = async () => {
    try {
      const jsonValue = JSON.stringify(creds, BufferJSON.replacer);
      await WhatsappSession.findOneAndUpdate(
        { userId: userId, key: CREDS_KEY_ID },
        {
          $set: {
            value: jsonValue,
            type: "creds",
            updatedAt: new Date(),
          },
        },
        { upsert: true, new: true }
      );
      console.log(
        `[MONGO] Credentials (creds.update) saved successfully for user ${userId}.`
      );
    } catch (error) {
      console.error(
        `[MONGO ERROR] CRITICAL: Failed to save credentials for ${userId}:`,
        error.message
      );
      throw error;
    }
  };

  return {
    state: { creds, keys },
    saveCreds,
  };
}

module.exports = useMongoAuthState;
