const {
  makeWASocket,
  DisconnectReason,
  fetchLatestBaileysVersion,
  isJidBroadcast,
  jidEncode,
} = require("@whiskeysockets/baileys");
const useMongoAuthState = require("./mongoAuthState");
const { getUniqueDepartments } = require('../utils/departmentUtils');

const qrcode = require("qrcode");
const fs = require("fs");
const path = require("path");
const FormData = require("form-data");
const fetch = require("node-fetch");
const pino = require("pino");
const Message = require("../models/Message");
const WhatsappSession = require("../models/WhatsappSession");

const clients = {};
const initialisingClients = {};

// --- Helper Functions ---

async function analyzeWithKMRLApi(filePath) {
  const form = new FormData();
  form.append("file", fs.createReadStream(filePath));

  const response = await fetch(
    "https://kmrl-analyzer-681627636377.asia-south1.run.app/process_document",
    {
      method: "POST",
      body: form,
      headers: form.getHeaders(),
    }
  );

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`KMRL API error: ${text}`);
  }
  return response.json();
}

// --- Client Management ---

async function createClient(userId) {
  if (!userId) {
    console.error(
      "ERROR: createClient called with a null or undefined userId."
    );
    return Promise.reject(
      new Error("A valid User ID is required to create a WhatsApp client.")
    );
  }

  if (clients[userId]) {
    return clients[userId];
  }
  if (initialisingClients[userId]) {
    return initialisingClients[userId];
  }

  const clientPromise = new Promise(async (resolve, reject) => {
    try {
      // ⭐ 1. Setup Auth State (Using MongoDB) ⭐
      const { state, saveCreds } = await useMongoAuthState(userId);

      const logger = pino({ level: "info" });
      const { version } = await fetchLatestBaileysVersion();


      
      // 2. Client Initialization (makeWASocket)
      const sock = makeWASocket({
        version,
        logger,
        auth: state,
        browser: ["Chrome (Linux)", "", ""],
        shouldSyncHistoryMessage: () => false, // Disables downloading chat history
        linkPreviewImageThumbnail: false,
        patchMessageBeforeSending: (msg) => {
          return msg;
        },
        ignoreIsPatchSync: () => true,
      });

      const clientWrapper = { client: sock, qr: null }; 

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
          console.log(
            `📌 QR code received for user ${userId}. Scan to authenticate!`
          );
          const qrCodeImage = await qrcode.toDataURL(qr);
          clientWrapper.qr = qrCodeImage;
          if (!clients[userId]) {
            resolve(clientWrapper);
          }
        }

        if (connection === "close") {
          const shouldReconnect =
            lastDisconnect.error?.output?.statusCode !==
            DisconnectReason.loggedOut;

          if (!shouldReconnect) {
            console.log(
              `Client for user ${userId} was logged out. Cleaning up MongoDB records.`
            );
            try {
              // Delete ALL session data (credentials and keys) for this user
              await WhatsappSession.deleteMany({ userId });
            } catch (err) {
              console.error(
                "Failed to clean up MongoDB session on logout:",
                err
              );
            }
          }

          delete clients[userId];
          delete initialisingClients[userId];

          if (shouldReconnect) {
            // Reconnect logic
            createClient(userId);
          } else {
            reject(new Error("Logged out/Auth failure"));
          }
        } else if (connection === "open") {
          console.log(`✅ WhatsApp client ready for user ${userId}`);
          clientWrapper.qr = null;
          clients[userId] = clientWrapper;
          delete initialisingClients[userId];
          resolve(clientWrapper);
        }
      });

      sock.ev.on("messages.upsert", async ({ messages, type }) => {
        console.log("--- messages.upsert event fired --- Type:", type);

        if (type !== "notify") return;

        const maxRetries = 2;
        for (const msg of messages) {
          let attempt = 0;
          while (attempt < maxRetries) {
            try {
              console.log(
                `Processing message: ${msg.key.id} (Attempt ${attempt + 1})`
              );

              // Ensure remoteJid exists and the message is not from the current user or a broadcast
              if (
                !msg.key.remoteJid ||
                msg.key.fromMe ||
                isJidBroadcast(msg.key.remoteJid)
              ) {
                break;
              }

              const messageContent = msg.message;
              if (!messageContent) break;

              const mediaTypes = [
                "imageMessage",
                "documentMessage",
                "videoMessage",
                "audioMessage",
              ];
              const isMedia = mediaTypes.some((t) => messageContent[t]);

              if (isMedia) {
                console.log("📁Media Received");
                const buffer =
                  await require("@whiskeysockets/baileys").downloadMediaMessage(
                    msg,
                    "buffer"
                  );

                // ... [Media handling logic remains the same] ...
                const mediaBase64 = buffer.toString("base64");
                const mediaKey = mediaTypes.find((t) => messageContent[t]);
                const mediaObject = messageContent[mediaKey];

                const mimeType = mediaObject.mimetype;
                const extension = mimeType.split("/")[1] || "bin";
                const fileName =
                  mediaObject.fileName || `${Date.now()}.${extension}`;

                // --- TEMPORARY FILE HANDLING FOR KMRL API ---
                const userDir = path.join("uploads", userId.toString());

                if (!fs.existsSync(userDir))
                  fs.mkdirSync(userDir, { recursive: true });

                const tempFilePath = path.join(userDir, fileName);
                fs.writeFileSync(tempFilePath, buffer);
                // --- END TEMPORARY FILE HANDLING ---

                const savedMsg = await Message.create({
                  userId,
                  from: jidEncode(msg.key.remoteJid, "s.whatsapp.net"),
                  type: "media",
                  fileName,
                  mimeType: mimeType,
                  mediaData: mediaBase64, // Media Content
                  path: tempFilePath, // Temporary path saved for analysis step
                });

                if (["pdf", "txt", "png", "jpg", "jpeg"].includes(extension)) {
                  try {
                    let isRelevant = false;
                    const apiData = await analyzeWithKMRLApi(tempFilePath);
                    console.log(apiData);
                    const rawRelevant = apiData?.data?.is_relevant || apiData?.is_relevant;

                    if (typeof rawRelevant === "string") {
                       isRelevant = rawRelevant.trim().toLowerCase() === "yes" || rawRelevant.trim().toLowerCase() === "true";
                      } else {
                       isRelevant = Boolean(rawRelevant);
                     }
                    savedMsg.analysis = {
                      isRelevant: isRelevant,
                      summary: apiData?.data?.summary || "",
                      raw: apiData,
                    };

                    const actions = 
            apiData?.data?.actions_required || apiData?.actions_required || [];
            
        const flaggedDepartments = getUniqueDepartments(actions);
        savedMsg.flaggedDepartments = flaggedDepartments;

                    // Cleanup the temporary file and DB path field
                    if (fs.existsSync(tempFilePath))
                      fs.unlinkSync(tempFilePath);
                    savedMsg.path = undefined;
                    await savedMsg.save();

                    

                    if (!savedMsg.analysis.isRelevant) {
                      await Message.findByIdAndDelete(savedMsg._id);
                      console.log(`❌ Irrelevant media deleted: ${fileName}`);
                    }
                  } catch (err) {
                    console.error("KMRL API Analysis failed:", err.message);
                    // Cleanup on failure
                    if (fs.existsSync(tempFilePath))
                      fs.unlinkSync(tempFilePath);
                    savedMsg.path = undefined;
                    await savedMsg.save();
                  }
                } else {
                  // For non-analyzed media, clean up the temp file and the path field
                  if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);
                  savedMsg.path = undefined;
                  await savedMsg.save();
                }
              } else {
                const text =
                  msg.message?.conversation ||
                  msg.message?.extendedTextMessage?.text ||
                  "";

                if (text) {
                  const savedMsg = await Message.create({
                    userId,
                    from: jidEncode(msg.key.remoteJid, "s.whatsapp.net"),
                    type: "text",
                    body: text,
                  });
                  console.log(`💬 Text received: ${text}`);
                  await Message.findByIdAndDelete(savedMsg._id);
                  console.log(`🗑️ Text message auto-deleted: ${text}`);
                }
              }

              break; // Message successfully processed, break out of retry loop
            } catch (err) {
              // Log the error and retry if not max attempts
              console.error(
                `Message processing error on attempt ${attempt + 1}:`,
                err.message
              );
              attempt++;
              if (attempt < maxRetries) {
                // Wait briefly before retrying decryption/processing
                await new Promise((resolve) => setTimeout(resolve, 1000));
              } else {
                console.error(
                  `Message processing failed permanently for ID ${msg.key.id}`
                );
              }
            }
          }
        }
      });
    } catch (err) {
      // Main client initialization catch block
      console.error(`Failed to create client for user ${userId}:`, err);
      delete initialisingClients[userId];
      reject(err);
    }
  });

  initialisingClients[userId] = clientPromise;
  return clientPromise;
}

function getClient(userId) {
  return clients[userId];
}

module.exports = { createClient, getClient };
