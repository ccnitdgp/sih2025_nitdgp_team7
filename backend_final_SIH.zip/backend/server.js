const { listMessages } = require("./lib/gmailService");
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const cookieSession = require("cookie-session");
const { processMaximoDocuments } = require("./routes/maximo");
const cron = require("node-cron");
require("dotenv").config();

const whatsappRoutes = require("./routes/whatsappRoutes");
const messageRoutes = require("./routes/messageRoutes");

const gmailAuthRoutes = require("./routes/auth");
const gmailRoutes = require("./routes/gmail");

const negotiationRoutes = require("./routes/negotiation");
const projectRoutes = require("./routes/projects");
const taskRoutes = require("./routes/tasks");
const smsRoutes = require("./routes/smsRoutes");



const { getActiveUsers, addActiveUser } = require("./lib/activeUsers");
const { loadTokens, createOAuthClient } = require("./lib/googleAuth");
const { ingestMessageForUser } = require("./lib/gmailIngestor");
const { ingestDriveForUser } = require("./lib/driveIngestor");

const User = require("./models/User");

const app = express();

/* -------------------------------------------------------
   ✅✅✅ REQUIRED TRUST PROXY FOR RENDER / COOKIES
------------------------------------------------------- */
app.set("trust proxy", 1);

/* -------------------------------------------------------
   ✅✅✅ CORS — THIS FIXES YOUR ERROR
------------------------------------------------------- */
const allowedOrigins = [
  "http://localhost:8080",
  "https://kmrlwebsite.vercel.app"
];

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error("CORS Not Allowed"));
      }
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
    allowedHeaders: ["Content-Type", "Authorization"]
  })
);

/* -------------------------------------------------------
   NO CHANGE IN THIS WARNA MAARUNGI */
app.use((req,res,next)=> {
  if(req.method==="OPTIONS"){
    res.sendStatus(200);
  }
  else{
    next();
  }
});
/* -------------------------------------------------------
   NO CHANGE IN THIS WARNA MAARUNGI
------------------------------------------------------- */

app.use(express.json());



/* -------------------------------------------------------
   ✅✅✅ COOKIE SESSION — PRODUCTION SAFE
------------------------------------------------------- */
app.use(
  cookieSession({
    name: "session",
    keys: [process.env.SESSION_SECRET || "supersecret"],
    maxAge: 24 * 60 * 60 * 1000,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production", // ✅ true on Render
    sameSite: process.env.NODE_ENV === "production" ? "none" : "lax"
  })
);

/* -------------------------------------------------------
   ✅ ROUTES
------------------------------------------------------- */
app.use("/api/translate", require("./routes/translate"));
app.use("/api/gmail/auth", gmailAuthRoutes);
app.use("/api/whatsapp", whatsappRoutes);
app.use("/api/messages", messageRoutes);
app.use("/api/gmail", gmailRoutes);
app.use("/api/gmail/ingest", require("./routes/ingest"));
app.use("/api/drive", require("./routes/drive"));
app.use("/api/projects", projectRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/negotiation", negotiationRoutes);
app.use("/api/sms", smsRoutes);


/* -------------------------------------------------------
   ✅ MONGO CONNECTION
------------------------------------------------------- */
mongoose
  .connect(process.env.MONGO_URI)
  .then(async () => {
    console.log("📦 MongoDB connected");

    try {
      const connected = await User.find({ googleConnected: true });
      connected.forEach(u => addActiveUser(u.email));
      console.log("🔁 Restored active users:", getActiveUsers());
    } catch (e) {
      console.error("⚠️ Failed restoring active users:", e.message);
    }

    app.listen(5000, () =>
      console.log("🚀 Server running on port 5000")
    );

    /* -------------------------------------------------------
       ✅ CRON JOB
    ------------------------------------------------------- */
    const cronExpr = "* * * * *";
    console.log(`⏱️ Cron ingestion scheduled (${cronExpr})`);

    cron.schedule(
      cronExpr,
      async () => {
        console.log("📥 [CRON] Starting selective Gmail + Drive ingestion...");

        const active = getActiveUsers();
        console.log("👥 Active users:", active);

        if (active.length === 0) {
          console.log("⏳ No active users, skipping ingestion.");
          return;
        }

        for (const email of active) {
          try {
            const tokens = await loadTokens(email);
            if (!tokens) {
              console.log(`⚠️ No tokens for ${email}, skipping.`);
              continue;
            }

            const client = createOAuthClient();
            client.setCredentials(tokens);

            const msgs = await listMessages(client, "is:unread", 500);

            console.log("📬 Message IDs:", msgs.map(m => m.id));

            if (!msgs || msgs.length === 0) {
              console.log(`📭 No unread emails for ${email}`);
            } else {
              console.log(`📩 Found ${msgs.length} unread emails for ${email}`);
            }

          } catch (err) {
            console.error(`❌ Error ingesting for ${email}:`, err.message);
          }
        }

        try {
          console.log("🏭 [CRON] Starting Maximo document ingestion...");
          await processMaximoDocuments();
          console.log("✅ Maximo ingestion finished.");
        } catch (err) {
          console.error("❌ Error during Maximo ingestion:", err.message);
        }

        console.log("📥 [CRON] Selective ingestion finished.");
      },
      {
        scheduled: true,
        timezone: "Asia/Kolkata",
      }
    );
  })
  .catch((err) => console.error("❌ MongoDB connection error:", err));