// models/Task.js (or TaskSchema.js)

const mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
    // --- Linkage ---
    projectId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Project',
        required: true,
    },
    sourceDocumentId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Document',
        required: true,
    },
    
    // --- Action & Assignment ---
    actionText: {
        type: String,
        required: true,
    },
    sourceDeadline: {
        type: Date,
        required: false, // Optional, since some actions may not have a deadline
    },
    assignedToId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    
    // --- Workflow Status ---
    status: {
        type: String,
        required: true,
        enum: ['Pending', 'Completed', 'Approved'],
        default: 'Pending',
    },
    
    // --- Status History Timestamps ---
    completedAt: {
        type: Date,
    },
    approvedAt: {
        type: Date,
    },
}, { timestamps: true });

module.exports = mongoose.model('Task', TaskSchema);