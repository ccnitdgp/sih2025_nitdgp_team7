// models/emailModel.js
const mongoose = require('mongoose');

const attachmentSchema = new mongoose.Schema({
  filename: String,
  size: Number,
  mimeType: String,
  mediaData: String
});

const emailSchema = new mongoose.Schema({
  messageId: { type: String, required: true, index: true, unique: true }, // each email once
  threadId: String,
  userEmail: { type: String, required: true, index: true },
  from: String,
  to: [String],
  cc: [String],
  bcc: [String],
  subject: String,
  date: Date,
  snippet: String,
  body: String,
  attachments: [attachmentSchema],
  ingestedAt: { type: Date, default: Date.now },
  flaggedDepartments: { 
        type: [String], 
        required: true, 
        default: [],
        index: true
    },

  analysis: {
    is_relevant: { type: Boolean, required: true },

    summary: { type: String, required: true },

    actions_required: [{
      action: { type: String, required: true },
      priority: { type: String, enum: ['High', 'Medium', 'Low'], required: true },
      deadline: { type: String, required: true },
      notes: { type: String, required: true }
    }],

    document_category: { type: String, required: true },

    important_dates: [{
      label: { type: String, required: true },
      date: { type: String, required: true }
    }],

    unique_string: { type: String, required: true, index: true },

    raw: Object,
    sourceTags: [String]
  }
});

module.exports = mongoose.model('Email', emailSchema);
