const mongoose = require("mongoose");

const NegotiationSchema = new mongoose.Schema({
  token: { type: String, required: true, unique: true }, // The Magic Link ID
  project_name: { type: String, required: true },
  vendor_email: { type: String, required: true },
  budget: { type: String, required: true },
  deadline: { type: Date },
  status: { 
    type: String, 
    enum: ['WAITING_FOR_PITCH', 'NEGOTIATION_ACTIVE', 'APPROVED'], 
    default: 'WAITING_FOR_PITCH' 
  },
  
  // Chat History
  messages: [{
    sender: { type: String, enum: ['MANAGER', 'VENDOR'] },
    text: String,
    timestamp: { type: Date, default: Date.now }
  }],

  // Vendor's Proposal
  vendor_pitch: {
    quote: String,
    remarks: String,
    submitted_at: Date
  },

  created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Negotiation", NegotiationSchema);
