const mongoose = require('mongoose');

const DocumentRecordSchema = new mongoose.Schema({
    source: { 
        type: String, 
        required: true, 
        enum: ['MAXIMO', 'WHATSAPP', 'EMAIL', 'DRIVE'],
        index: true
    },
    source_id: { 
        type: String, 
        required: true, 
        unique: true, 
        index: true 
    },
    related_wo_id: { type: String, index: true },
    related_asset_num: { type: String, index: true },
    title: { type: String, required: true },
    raw_text_source: { type: String },
    summary: { type: String },
    actions_required: { type: [String], default: [] },
    priority: { 
        type: String, 
        enum: ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'],
        index: true 
    },
    deadline: { type: Date, nullable: true },
    flaggedDepartments: { 
        type: [String], 
        default: [], 
        index: true
    },
    station_related: { type: String, index: true },
    is_relevant: { type: Boolean, default: true },
    raw_analysis: { type: Object },
    
}, { timestamps: true });
DocumentRecordSchema.index({ 
    summary: 'text', 
    raw_text_source: 'text', 
    actions_required: 'text' 
});

module.exports = mongoose.model('DocumentRecord', DocumentRecordSchema);