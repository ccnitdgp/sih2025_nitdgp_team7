const mongoose = require("mongoose");

const driveSchema = new mongoose.Schema({
  fileId: { type: String, required: true, index: true },
  userEmail: { type: String, required: true, index: true },

  fileName: String,
  mimeType: String,
  size: Number,
  path: String,
  modifiedTime: Date,
  lastProcessedModifiedTime: { type: String },

  flaggedDepartments: { 
        type: [String], 
        required: true, 
        default: [],
        index: true
    },

  analysis: {
    is_relevant: { type: Boolean, required: true },

    summary: { type: String, required: true },

    actions_required: [{
      action: { type: String, required: true },
      priority: { type: String, enum: ['High', 'Medium', 'Low'], required: true },
      deadline: { type: String, required: true },
      notes: { type: String, required: true }
    }],

    document_category: { type: String, required: true },

    important_dates: [{
      label: { type: String, required: true },
      date: { type: String, required: true }
    }],

    unique_string: { type: String, required: true, index: true },

    raw: Object,
    sourceTags: [String]
  },
    ingestedAt: { type: Date, default: Date.now }
});


module.exports = mongoose.model("DriveFile", driveSchema);
