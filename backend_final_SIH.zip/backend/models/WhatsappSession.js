const mongoose = require("mongoose");

const whatsappSessionSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  value: { type: String, required: false }, 
  type: { type: String, required: true }, 
  key: { type: String, required: true },
  updatedAt: { type: Date, default: Date.now },
});
whatsappSessionSchema.index({ userId: 1, type: 1, key: 1 }, { unique: true });
module.exports = mongoose.model("WhatsappSession", whatsappSessionSchema);
