// models/Project.js (or ProjectSchema.js)

const mongoose = require('mongoose');

const ProjectSchema = new mongoose.Schema({
    // --- Metadata ---
    projectName: {
        type: String,
        required: true,
        trim: true,
    },
    projectDescription: {
        type: String,
        required: true,
    },
    initialDeadline: {
        type: Date,
        required: true,
    },
    targetDepartment: {
        type: String,
        required: true,
        // Ensures only valid KMRL departments can be assigned
        enum: ['Operations & Maintenance', 'Procurement & Supply Chain', 'Engineering & Projects', 'Human Resources', 'Finance & Accounts'], 
    },
    
    // --- User & Linkage ---
    managerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // Reference to your User model (who created it)
        required: true,
    },
    
    // List of Document IDs related to this project (from the Documents page)
    relevantDocuments: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Document', // Reference to your existing Document storage model
    }],
    
    // --- Timestamps ---
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    }
}, { timestamps: true });

module.exports = mongoose.model('Project', ProjectSchema);