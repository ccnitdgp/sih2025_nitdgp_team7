const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema({
    documentId: { type: mongoose.Schema.Types.ObjectId, type: mongoose.Schema.Types.ObjectId, required: true, index: true },
    senderId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    recipientId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    actionRequiredDept: { type: String, required: true },
    priority: { type: String, enum: ["High", "Medium", "Low", "Normal"], default: "Normal" },
    deadline: { type: String, required: false },
    actionRequired: { type: String, required: true },    
    isCompleted: { type: Boolean, default: false, index: true },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Notification", notificationSchema);