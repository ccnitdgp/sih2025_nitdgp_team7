const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  from: String,
  type: String,
  body: String,
  fileName: String,
  mimeType: String,
  path: String,
  fileSize: { type: Number, default: 0 }, 
  mediaData: { type: String, required: false },
  tags: [{ type: String }],
  date: { type: Date, default: Date.now },
  flaggedDepartments: { 
        type: [String], 
        required: true, 
        default: [],
        index: true,
    },
  analysis: {
    isRelevant: { type: Boolean, default: null },
    summary: { type: String, default: "" },
    raw: mongoose.Schema.Types.Mixed
  },
});

messageSchema.index({ 
  fileName: 'text', 
  'analysis.summary': 'text' 
});

module.exports = mongoose.model("Message", messageSchema);