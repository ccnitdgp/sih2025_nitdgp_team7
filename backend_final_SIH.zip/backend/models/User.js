const mongoose = require("mongoose");

const tokenSchema = new mongoose.Schema({
  access_token: String,
  refresh_token: String,
  scope: String,
  token_type: String,
  expiry_date: Number
});

const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, required: true, unique: true },
  picture: String,
  googleTokens: tokenSchema,
  googleConnected: { type: Boolean, default: false },
  password: { type: String, required: true },
  whatsappSession: { type: Object, default: {} },
  createdAt: { type: Date, default: Date.now },

  jobTitle: { type: String, default: "" },
  employeeId: { type: String, default: "" },
  workLocation: { type: String, default: "" },
  phoneNumber: { type: String, default: "" },
  department: { type: String, default: "" },
  preferredLanguage: { type: String, default: "English" },
  profileCompleted: { type: Boolean, default: false }
});

module.exports = mongoose.model("User", userSchema);