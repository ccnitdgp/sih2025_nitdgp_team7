const FIXED_DEPARTMENTS = [
    "Operations & Maintenance",
    "Engineering & Projects",
    "Procurement & Supply Chain",
    "Human Resources",
    "Finance & Accounts"
];

const getUniqueDepartments = (actions) => {
    console.log("Actions",actions);
    if (!Array.isArray(actions) || actions.length === 0) return [];

    const departments = actions
        .map(a => a.assigned_department)
        .filter(dept => dept)
        .flatMap(deptString =>
            typeof deptString === 'string'
                ? deptString.split(',').map(d => d.trim()).filter(d => d)
                : []
        );
        console.log("Dept",departments);
    const validDepartments = departments.filter(d => FIXED_DEPARTMENTS.includes(d));
    console.log("valid dept",validDepartments);
    return [...new Set(validDepartments)];
};

module.exports = { getUniqueDepartments, FIXED_DEPARTMENTS };