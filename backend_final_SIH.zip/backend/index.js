/* =========================================
   STANDALONE NEGOTIATION SERVER (Port 5001)
   ========================================= */

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

// Import the Route and Model
const negotiationRoutes = require("./routes/negotiation");
const Negotiation = require("./models/Negotiation");

const app = express();

// 1. NUCLEAR CORS (Allow Everything)
app.use(cors({
  origin: true,
  credentials: true
}));

// 2. Body Parser
app.use(express.json());

// 3. Debug Logger (See every request in console)
app.use((req, res, next) => {
  console.log(`[5001] Request received: ${req.method} ${req.url}`);
  next();
});

// 4. Mount the Negotiation Route
// URL will be: http://localhost:5001/api/negotiation/...
app.use("/api/negotiation", negotiationRoutes);

// 5. Test Route (To verify server is running)
app.get("/", (req, res) => {
  res.send("✅ Negotiation Server is Running on Port 5001");
});

// 6. Connect Database & Start Server
const PORT = 5001;

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("📦 [5001] MongoDB Connected");
    app.listen(PORT, () => {
      console.log(`🚀 Negotiation Server running at: http://localhost:${PORT}`);
    });
  })
  .catch((err) => console.error("❌ DB Connection Error:", err));