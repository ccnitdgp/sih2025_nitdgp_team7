const express = require("express");
const router = express.Router();

const { createOAuthClient, loadTokens } = require("../lib/googleAuth");
const { ingestAllUsers, ingestMessageForUser } = require("../lib/gmailIngestor");

/**
 * Ingest ALL users who have connected Gmail
 */
router.post("/all", async (req, res) => {
  try {
    const results = await ingestAllUsers();
    res.json({ ok: true, results });
  } catch (err) {
    console.error("Ingest /all error:", err);
    res.status(500).json({ ok: false, error: err.message || err });
  }
});

/**
 * Ingest all unread messages for a single user
 */
router.post("/user", async (req, res) => {
  try {
    const email = req.headers["x-user-email"] || req.body.email;

    if (!email) {
      return res.status(400).json({
        ok: false,
        error: "Provide email in x-user-email header or body.email",
      });
    }

    const tokens = await loadTokens(email);
    if (!tokens) {
      return res.status(404).json({
        ok: false,
        error: `No Gmail OAuth tokens found for ${email}`,
      });
    }

    const client = createOAuthClient();
    client.setCredentials(tokens);

    // PROCESS **ALL UNREAD MESSAGES**
    const results = await ingestAllUsers(client, email);

    res.json({ ok: true, ingested: results });
  } catch (err) {
    console.error("Ingest /user error:", err);
    res.status(500).json({ ok: false, error: err.message || err });
  }
});

module.exports = router;