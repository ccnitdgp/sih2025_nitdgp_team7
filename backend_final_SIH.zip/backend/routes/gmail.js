const express = require("express");
const router = express.Router();
const Email = require("../models/emailModel");

const { createOAuthClient, loadTokens } = require("../lib/googleAuth");
const { 
    listMessages, 
    getMessage, 
    getBody, 
    saveAttachments 
} = require("../lib/gmailService");


async function authRequired(req, res, next) {
    try {
        const email = req.session?.email || req.headers["x-user-email"];
        if (!email) {
            return res.status(401).json({ error: "Not logged in" });
        }

        const tokens = await loadTokens(email);
        if (!tokens) {
            return res.status(401).json({ error: "No Gmail permission saved" });
        }

        const client = createOAuthClient();
        client.setCredentials(tokens);

        req.gmail = client;
        req.userEmail = email;

        next();
    } catch (err) {
        console.error("authRequired error:", err);
        res.status(500).json({ error: "Auth middleware failed", details: err.message });
    }
}

router.get("/db/emails", async (req, res) => {
  try {
    // Optional filter
    const userEmail = req.query?.email;

    let filter = {};

    if (userEmail) {
      filter.userEmail = userEmail;
    }

    const emails = await Email.find(filter).sort({ date: -1 });

    res.json(emails);
  } catch (err) {
    console.error("Error fetching DB emails:", err);
    res.status(500).json({ error: "Failed to fetch emails from DB" });
  }
});

router.get("/list", authRequired, async (req, res) => {
    try {
        const msgs = await listMessages(req.gmail, req.query.q || "");
        res.json(msgs);
    } catch (err) {
        console.error("Error in /list:", err);
        res.status(500).json({ error: "Failed to list emails", details: err.message });
    }
});

router.get("/message/:id", authRequired, async (req, res) => {
    try {
        const msg = await getMessage(req.gmail, req.params.id);

        res.json({
            id: msg.id,
            headers: msg.payload.headers,
            body: getBody(msg.payload),
            snippet: msg.snippet
        });
    } catch (err) {
        console.error("Error in /message/:id:", err);
        res.status(500).json({ error: "Failed to get message", details: err.message });
    }
});


router.post("/message/:id/attachments", authRequired, async (req, res) => {
    try {
        const msg = await getMessage(req.gmail, req.params.id);
        const saved = await saveAttachments(req.gmail, msg);
        res.json({ saved });
    } catch (err) {
        console.error("Error in attachments:", err);
        res.status(500).json({ error: "Failed to save attachments", details: err.message });
    }
});

module.exports = router;
