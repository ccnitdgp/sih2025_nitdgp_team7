const express = require("express");
const auth = require("../middleware/auth");
const WhatsappSession = require("../models/WhatsappSession");
const { createClient, getClient } = require("../whatsapp/clientManager");
const router = express.Router();

// Get QR for user
router.get("/qr", auth, async (req, res) => {
  const userId = req.user.id;
  const client = await createClient(userId);
  res.json({ qr: client.qr });
});

// Get status (connected or waiting for QR)
router.get("/status", auth, async (req, res) => {
  const userId = req.user.id;
  const clientWrapper = getClient(userId) || (await createClient(userId).catch(err => {
    console.error(err);
    return null;
  }));

  if (!clientWrapper || !clientWrapper.client) {
    return res.json({
      status: "not_initialized",
      message: "Client is not running/Failed to initialize.",
    });
  }
  const isConnected = !!getClient(userId);

  if (isConnected) {
    return res.json({
      status: "connected",
      user: clientWrapper.client.user, 
    });
  }

  if (clientWrapper.qr) {
    return res.json({
      status: "qr",
      qr: clientWrapper.qr,
    });
  }
  return res.json({ status: "loading", message: `Client is initializing...` });
});


// Disconnect WhatsApp and clear session
router.post("/disconnect", auth, async (req, res) => {
  const userId = req.user.id;
  const clientObj = getClient(userId);

  if (!clientObj)
    return res.status(404).json({ error: "No active WhatsApp session found" });

  try {
    await clientObj.client.logout();
    delete clients[userId]; 

    res.json({ message: "WhatsApp disconnected successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to disconnect WhatsApp" });
  }
});

module.exports = router;