console.log(">>> LOADED GMAIL AUTH ROUTER FROM:", __filename);

const express = require("express");
const router = express.Router();
const { google } = require("googleapis");

const { 
  createOAuthClient, 
  getAuthUrl, 
  saveTokens 
} = require("../lib/googleAuth");

const { addActiveUser, removeActiveUser } = require("../lib/activeUsers");


const User = require("../models/User");  

router.get("/google", (req, res) => {
  res.redirect(getAuthUrl());
});

router.get("/google/callback", async (req, res) => {
  try {
    const code = req.query.code;
    if (!code) return res.status(400).send("Missing code");

    const client = createOAuthClient();

    // Exchange code for tokens
    const { tokens } = await client.getToken(code);
    client.setCredentials(tokens);

    // Get Google user profile
    const oauth2 = google.oauth2({ version: "v2", auth: client });
    const userInfo = await oauth2.userinfo.get();

    const { email, name, picture } = userInfo.data;

    if (!email) {
      return res.status(500).send("Could not fetch email");
    }

    // === SAVE USER + TOKENS IN MONGO ===
    await User.findOneAndUpdate(
      { email },
      {
        name,
        email,
        picture,
        googleConnected: true,
        googleTokens: tokens      //store tokens here
      },
      { upsert: true, new: true }
    );

    // SESSION save
    req.session.email = email;

    addActiveUser(email);

    return res.redirect(process.env.FRONTEND_URL);

  } catch (err) {
    console.error("OAuth Callback Error:", err.response?.data || err);
    res.status(500).json({
      message: "OAuth Error",
      error: err.message,
      responseData: err.response?.data || null
    });
  }
});


router.put("/profile", async (req, res) => {
    const email = req.session?.email;
    if (!email) {
        return res.status(401).json({ error: "Unauthorized: User not logged in." });
    }

    const {
        jobTitle,
        employeeId,
        workLocation,
        department,
        preferredLanguage,
        phoneNumber
    } = req.body;

    if (!jobTitle || !employeeId || !workLocation || !department) {
        return res.status(400).json({ 
            error: "Mandatory fields missing.",
            requiredFields: ["jobTitle", "employeeId", "workLocation", "department"] 
        });
    }

    try {
        // Update the User document in MongoDB
        const updatedUser = await User.findOneAndUpdate(
            { email },
            {
                $set: {
                    jobTitle,
                    employeeId,
                    workLocation,
                    department,
                    preferredLanguage,
                    phoneNumber,
                    profileCompleted: true 
                }
            },
            { new: true, select: "-googleTokens" } 
        );

        if (!updatedUser) {
            return res.status(404).json({ error: "User not found." });
        }

        res.json({ 
            success: true, 
            message: "Profile updated successfully.",
            user: updatedUser 
        });

    } catch (err) {
        console.error("Profile Update Error:", err);
        res.status(500).json({ error: "Failed to update profile due to a server error." });
    }
});

router.get("/me", async (req, res) => {
  try {
    const email = req.session?.email;
    if (!email) return res.json({ loggedIn: false });

    //Re-register active user on server restart
    const { addActiveUser } = require("../lib/activeUsers");
    addActiveUser(email);   // <--- IMPORTANT FIX

    const user = await User.findOne({ email }).select("-googleTokens");

    if (!user) return res.json({ loggedIn: false });

    return res.json({
      loggedIn: true,
      name: user.name,
      email: user.email,
      picture: user.picture,
      googleConnected: user.googleConnected,
      profileCompleted: user.profileCompleted || false,
      jobTitle: user.jobTitle || '',
      employeeId: user.employeeId || '',
      workLocation: user.workLocation || '',
      department: user.department || '',
      preferredLanguage: user.preferredLanguage || '',
      phoneNumber: user.phoneNumber || '',
    });
  } catch (err) {
    res.status(500).json({ loggedIn: false, error: err.message });
  }
});


router.post("/google/logout", async (req, res) => {
  try {
    const email = req.session?.email || req.headers["x-user-email"];
    if (!email) {
      return res.status(400).json({ ok: false, error: "Not logged in" });
    }

    removeActiveUser(email);

    await User.findOneAndUpdate(
      { email },
      { $unset: { googleTokens: "" }, $set: { googleConnected: false } }
    );

    req.session = null;

    return res.json({ ok: true, message: "Signed out successfully" });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});


module.exports = router;