const express = require("express");
const router = express.Router();

const { loadTokens, createOAuthClient } = require("../lib/googleAuth");
const { ingestDriveForUser } = require("../lib/driveIngestor");

router.post("/ingest", async (req, res) => {
  try {
    const email = req.headers["x-user-email"];
    if (!email) return res.status(400).json({ error: "Missing x-user-email header" });

    const tokens = await loadTokens(email);
    const client = createOAuthClient();
    client.setCredentials(tokens);

    const result = await ingestDriveForUser(client, email);
    res.json({ ok: true, result });

  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

module.exports = router;
