const express = require("express");
const router = express.Router();
const axios = require("axios");

router.post("/", async (req, res) => {
  try {
    const { text, targetLang } = req.body;

    if (!text || !targetLang) {
      return res.status(400).json({ error: "Missing text or targetLang" });
    }

    //console.log("🌐 Google Translate Request:", { text, targetLang });

    const apiKey = process.env.GOOGLE_TRANSLATE_API_KEY;

    const url = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;

    const response = await axios.post(url, {
      q: text,
      target: targetLang,
      format: "text"
    });

    const translated = response.data?.data?.translations?.[0]?.translatedText;

    //console.log("✅ Google Translate Response:", translated);

    res.json({ translated });
  } catch (err) {
    console.error("❌ Google Translate API Error:", err.response?.data || err.message);
    res.status(500).json({ error: "Translation failed" });
  }
});

module.exports = router;
