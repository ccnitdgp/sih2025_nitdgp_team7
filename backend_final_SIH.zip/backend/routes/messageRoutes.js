const express = require("express");
const auth = require("../middleware/auth");
const Message = require("../models/Message");
const Email = require("../models/emailModel");
const Notification = require("../models/Notification"); 
const User = require("../models/User"); 
const { getMaximoDocuments, getMaximoCount } = require('./maximo');
const router = express.Router();

// Download media (WhatsApp + Gmail unified)
router.get("/download/:id", async (req, res) => {
    try {
        const id = req.params.id;
        
        const message = await Message.findById(id);
        if (message && message.type === "media" && message.mediaData) {
            const buffer = Buffer.from(message.mediaData, "base64");
            return res.set({
                "Content-Type": message.mimeType,
                "Content-Disposition": `attachment; filename="${message.fileName}"`,
                "Content-Length": buffer.length,
            }).end(buffer);
        }

        const emailDoc = await Email.findById(id);

        if (!emailDoc) {
            return res.status(404).json({ msg: "File not found in WhatsApp or Gmail" });
        }
        if (!emailDoc.attachments || emailDoc.attachments.length === 0) {
            return res.status(404).json({ msg: "No attachments found for Gmail email" });
        }
        const att = emailDoc.attachments[0];
        if (!att.mediaData) {
            return res.status(404).json({ msg: "Attachment content missing" });
        }

        let fixedBase64 = att.mediaData.replace(/-/g, "+").replace(/_/g, "/");
        while (fixedBase64.length % 4 !== 0) fixedBase64 += "=";
        const buffer = Buffer.from(fixedBase64, "base64");

        return res.set({
            "Content-Type": att.mimeType || "application/octet-stream",
            "Content-Disposition": `attachment; filename="${att.filename}"`,
            "Content-Length": buffer.length,
        }).end(buffer);

    } catch (err) {
        console.error("DOWNLOAD ERROR:", err);
        res.status(500).send("Server error");
    }
});

// POST /messages/notify - To create a cross-department notification
router.post("/notify", auth, async (req, res) => {
    const senderId = req.user.id; 
    const { 
        documentId, 
        recipientId, 
        actionRequiredDept, 
        actionRequired,
        priority, 
        deadline 
    } = req.body;

    if (!documentId || !recipientId || !actionRequiredDept || !actionRequired) {
        return res.status(400).json({ message: "Missing required notification fields." });
    }

    try {
        const newNotification = new Notification({
            documentId,
            senderId,
            recipientId,
            actionRequiredDept,
            actionRequired,
            priority,
            deadline: deadline ? new Date(deadline) : undefined,
            isCompleted: false,
        });

        await newNotification.save();
        
        res.status(201).json({ 
            message: "Notification created successfully.", 
            notification: newNotification 
        });

    } catch (err) {
        console.error("Error creating notification:", err);
        res.status(500).send("Server error during notification creation.");
    }
});

// GET /messages/users-by-department
router.get("/users-by-department", auth, async (req, res) => {
    const department = req.query.department;
    const action = req.query.action; 
    if (!department || !action) { 
        return res.status(400).json({ message: "Department and action query parameters are required." });
    }

    try {
        const filter = { 
            department: department,
        };
        
        const users = await User.find(filter)
            .select("name jobTitle picture department _id")
            .lean();

        res.json(users);
    } catch (err) {
        console.error("Error fetching users by department:", err);
        res.status(500).send("Server error fetching user list.");
    }
});

// GET /messages/notifications (Point 5 Implementation)
router.get("/notifications", auth, async (req, res) => {
    const recipientId = req.user.id;
    const showCompleted = req.query.showCompleted === 'true'; 

    try {
        const filter = { recipientId: recipientId };
        if (showCompleted) {
            filter.isCompleted = true; 
        } 
        else {
            filter.isCompleted = false;
        }

        const notifications = await Notification.find(filter)
            .sort({ createdAt: -1 })
            .populate("senderId", "name department") 
            .lean();
        
        res.json(notifications);

    } catch (err) {
        console.error("Error fetching notifications:", err);
        res.status(500).send("Server error fetching notifications.");
    }
});

// POST /messages/notifications/:id/complete (Point 6 Implementation)
router.post("/notifications/:id/complete", auth, async (req, res) => {
    const notificationId = req.params.id;
    const userId = req.user.id;

    try {
        const notification = await Notification.findById(notificationId);

        if (!notification) {
            return res.status(404).json({ message: "Notification not found." });
        }

        if (notification.recipientId.toString() !== userId) {
            return res.status(403).json({ message: "You are not authorized to complete this notification." });
        }
        
        notification.isCompleted = true;
        await notification.save();

        res.json({ message: "Notification marked as completed.", notification });

    } catch (err) {
        console.error(`Error completing notification ${notificationId}:`, err);
        res.status(500).send("Server error during completion.");
    }
});


router.get("/search", auth, async (req, res) => {
    const userDepartment = req.user?.department; 
    
    if (!userDepartment) {
        return res.status(401).json({ message: "User department not found. Cannot perform search." });
    }

    const visibilityFilter = {
        flaggedDepartments: { $in: [userDepartment] }
    };

    try {
        const { q, type, date } = req.query;
        
        let messageQuery = { 
            type: "media",
            ...visibilityFilter
        };

        if (q) {
            messageQuery.$text = { $search: q };
        }

        if (type && type !== 'all') {
            messageQuery.mimeType = { $regex: type, $options: 'i' };
        }
        
        let dateFilter = {};
        if (date && date !== 'alltime') {
            const startDate = new Date();
            if (date === 'today') startDate.setHours(0, 0, 0, 0);
            else if (date === 'thisweek') startDate.setDate(startDate.getDate() - 7);
            else if (date === 'thismonth') startDate.setMonth(startDate.getMonth() - 1);
            else if (date === 'thisyear') startDate.setFullYear(startDate.getFullYear() - 1);
            dateFilter.date = { $gte: startDate };
        }
        
        if (dateFilter.date) {
            messageQuery.date = dateFilter.date;
        }

        let findQuery = Message.find(messageQuery);

        if (q) {
            findQuery = findQuery.sort({ score: { $meta: "textScore" } });
        } else {
            findQuery = findQuery.sort({ date: -1 });
        }
        
        const whatsappMessages = await findQuery
            .limit(100) 
            .lean()
            .populate("userId", "name");

        
        let gmailFilter = {
            ...visibilityFilter
        };

        if (q) {
            gmailFilter.$or = [
                { subject: { $regex: q, $options: "i" } },
                { body: { $regex: q, $options: "i" } },
                { "analysis.summary": { $regex: q, $options: "i" } }
            ];
        }

        if (dateFilter.date) {
            gmailFilter.date = dateFilter.date;
        }

        const gmailMessages = await Email.find(gmailFilter)
            .limit(100) 
            .sort({ date: -1 })
            .lean();

        gmailMessages.forEach((m) => (m.source = "gmail"));
        whatsappMessages.forEach((m) => (m.source = "whatsapp"));

        const combined = [
            ...whatsappMessages,
            ...gmailMessages
        ].sort((a, b) => new Date(b.date) - new Date(a.date));

        res.json(combined);

    } catch (err) {
        console.error(err);
        res.status(500).send("Server Error");
    }
});

router.get('/maximo/documents', async (req, res) => {
    try {
        const documents = await getMaximoDocuments(req.query.limit);
        return res.json(documents);
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.get('/maximo/count', async (req, res) => {
    try {
        const count = await getMaximoCount();
        return res.json(count); // Returns a number directly
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

module.exports = router;