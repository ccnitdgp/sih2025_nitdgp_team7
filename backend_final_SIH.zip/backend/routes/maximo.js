const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const DocumentRecord = require('../models/maximo');
const { getUniqueDepartments } = require('../utils/departmentUtils');
const MOCK_MAXIMO_API_BASE = process.env.MOCK_MAXIMO_API_BASE || 'https://maximo.onrender.com/api/maximo';
const KMRL_ANALYSIS_API = "https://kmrl-analyzer-681627636377.asia-south1.run.app/process_document";
const MAXIMO_API_KEY = process.env.MAXIMO_API_KEY;
const TEMP_UPLOAD_DIR = path.join(__dirname, '..', 'maximo_temp');
let lastFetchTime = null;

if (!fs.existsSync(TEMP_UPLOAD_DIR)) {
    fs.mkdirSync(TEMP_UPLOAD_DIR, { recursive: true });
}
function sanitizePriority(rawPriority) {
    if (!rawPriority) {
        return 'MEDIUM';
    }
    const standardPriority = rawPriority.toUpperCase().trim();
    if (['N/A', 'NONE', '0'].includes(standardPriority)) {
        return 'MEDIUM';
    }
    const validEnums = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
    if (validEnums.includes(standardPriority)) {
        return standardPriority;
    }
    if (['CRIT', 'URGENT'].includes(standardPriority)) {
        return 'CRITICAL';
    }
    return 'MEDIUM';
}
async function analyzeWithKMRLApiFile(filePath) {
    const form = new FormData();
    form.append("file", fs.createReadStream(filePath));

    const response = await fetch(KMRL_ANALYSIS_API, {
        method: "POST",
        body: form,
        headers: form.getHeaders(),
    });

    if (!response.ok) {
        const text = await response.text();
        throw new Error(`KMRL API error: ${text}`);
    }
    return response.json();
}

async function processMaximoDocuments() {
    console.log(`\n--- Maximo Worker: Starting Poll (Last Run: ${lastFetchTime ? lastFetchTime.toISOString() : 'Never'}) ---`);

    const fetchTimeQuery = lastFetchTime ? `?lastFetchTime=${lastFetchTime.toISOString()}` : '';
    const newDocsUrl = `${MOCK_MAXIMO_API_BASE}/documents/new${fetchTimeQuery}`;

    try {
        const response = await fetch(newDocsUrl, {
            headers: { 'Authorization': `Bearer ${MAXIMO_API_KEY}` }
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch new document IDs: ${response.statusText}`);
        }

        const data = await response.json();
        const docList = data.DATA || [];
        console.log(`Found ${docList.length} new document(s) to process.`);

        if (docList.length === 0) {
            lastFetchTime = new Date();
            return;
        }
        for (const doc of docList) {
            const docId = doc.DOCID;
            const recordExists = await DocumentRecord.exists({ source_id: docId });

            if (recordExists) {
                console.warn(`Skipping document ${docId}: Already exists in website database.`);
                lastFetchTime = new Date();
                continue;
            }
            const fullDocUrl = `${MOCK_MAXIMO_API_BASE}/document/${docId}`;

            const tempFilePath = path.join(TEMP_UPLOAD_DIR, `${docId}.txt`);
            let maximoDoc;
            let apiData;

            try {
                const fullResponse = await fetch(fullDocUrl);
                if (!fullResponse.ok) {
                    throw new Error(`Failed to fetch full document ${docId}`);
                }
                const fullData = await fullResponse.json();
                maximoDoc = fullData.DATA[0];
                const rawContent = maximoDoc.RAW_CONTENT_TEXT;

                fs.writeFileSync(tempFilePath, rawContent, 'utf8');
                console.log(`Writing Maximo content for ${docId} to temporary file.`);

                console.log(`\nAnalyzing Maximo DOCID: ${docId} via file upload...`);
                apiData = await analyzeWithKMRLApiFile(tempFilePath);
                if (apiData.is_relevant === false || apiData.is_relevant === 'no') {
                    console.log(`❌ Discarding document ${docId}: AI analysis marked it as NOT relevant.`);
                    continue;
                }

                const analysisResult = apiData.data || apiData;
                const actions = analysisResult.actions_required || [];
                const summary = analysisResult.summary || "";
                const flaggedDepartments = getUniqueDepartments(actions);
                let extractedPriority = 'MEDIUM';

                if (actions && actions.length > 0) {
                    const priorityOrder = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
                    const priorities = actions.map(a => sanitizePriority(a.priority));

                    // Find the highest priority among all actions
                    for (const p of priorityOrder) {
                        if (priorities.includes(p)) {
                            extractedPriority = p;
                            break;
                        }
                    }
                }
                await DocumentRecord.create({
                    source: 'MAXIMO',
                    source_id: docId,
                    related_wo_id: maximoDoc.WONUM,
                    related_asset_num: maximoDoc.ASSETNUM,
                    raw_text_source: rawContent,
                    title: maximoDoc.TITLE || `Maximo ${docId} Report`,

                    is_relevant: true,
                    summary: summary,
                    priority: sanitizePriority(extractedPriority),
                    deadline: maximoDoc.TARGCOMPDATE,
                    flaggedDepartments: flaggedDepartments,
                    station_related: analysisResult.stations_related || null,

                    raw_analysis: apiData,
                });

                console.log(`✅ Saved Maximo Document ${docId} to Website DB.`);

            } catch (error) {
                console.error(`🛑 Error processing Maximo Document ${docId}:`, error.message);
            } finally {
                if (fs.existsSync(tempFilePath)) {
                    fs.unlinkSync(tempFilePath);
                    console.log(`Cleaned up temporary file: ${tempFilePath}`);
                }
            }
        }
        lastFetchTime = new Date();
        console.log(`--- Maximo Worker: Poll Complete. Next run scheduled. ---`);

    } catch (error) {
        console.error('CRITICAL Maximo Polling Error:', error.message);
    }
}

async function getMaximoDocuments(limit = 20) {
    try {
        const documents = await DocumentRecord.find({ source: 'MAXIMO' })
            .sort({ createdAt: -1 })
            .limit(limit);
        return documents;
    } catch (error) {
        console.error('Database error fetching Maximo documents:', error);
        throw new Error('Failed to retrieve Maximo documents from DB.');
    }
}

async function getMaximoCount() {
    try {
        const count = await DocumentRecord.countDocuments({ source: 'MAXIMO' });
        console.log(`Fetched Maximo document count: ${count}`);
        return count;
    } catch (error) {
        console.error('Database error fetching Maximo count:', error);
        throw new Error('Failed to retrieve Maximo document count.');
    }
}

module.exports = { processMaximoDocuments, getMaximoDocuments, getMaximoCount };