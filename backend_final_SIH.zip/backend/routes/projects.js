// routes/projects.js

const express = require('express');
const router = express.Router();
// Assuming you created controllers/projectController.js in the previous step
const projectController = require('../middleware/projectController');

// Middleware to simulate user authentication for demonstration (REPLACE with actual auth middleware)
const mockAuth = (req, res, next) => {
    // In a real application, this would verify a token and attach the user ID
    req.user = { id: '654321012345678901234567' }; // Mock Manager ID
    next();
};

// POST /api/projects - Create a new project (Form submission)
router.post('/', mockAuth, projectController.createProject);

// GET /api/projects/my-projects - Get all projects created by the manager
router.get('/my-projects', mockAuth, projectController.getManagerProjects);

module.exports = router;