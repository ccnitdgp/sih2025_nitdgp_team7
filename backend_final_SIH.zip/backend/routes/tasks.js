// routes/tasks.js

const express = require('express');
const router = express.Router();
// Assuming you created controllers/taskController.js in the previous step
const taskController = require('../middleware/taskController');

// Middleware to simulate user authentication (REPLACE with actual auth middleware)
const mockAuth = (req, res, next) => {
    // Allows us to check if the user is a manager (for approval) or the assigned user (for completion)
    req.user = { id: '654321012345678901234567', role: 'manager' }; 
    next();
};

// POST /api/tasks - Assign a new task (Manager action from the '+' button)
router.post('/', mockAuth, taskController.createTask);

// GET /api/tasks/:projectId - Fetch all tasks for a specific project board
router.get('/:projectId', mockAuth, taskController.getTasksByProject);

// PATCH /api/tasks/:id/status - Update the task status (Used for 'Completed' or 'Approved')
router.patch('/:id/status', mockAuth, taskController.updateTaskStatus);

module.exports = router;