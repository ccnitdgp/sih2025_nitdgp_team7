const express = require('express');
const twilio = require('twilio');

const router = express.Router();

// --- Configuration & Initialization ---
// Twilio Credentials pulled from the environment variables loaded in server.js
const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// --- Database Simulation (Replace with actual MongoDB lookup later) ---
// This map simulates fetching a mobile number from your User model
const mockDatabase = {
  // 🛑 REPLACE THIS WITH YOUR ACTUAL, VERIFIED MOBILE NUMBER (e.g., +12345678901)
  'test_user_id_123': { 
    mobile_number: '+918958898580', 
    name: 'WebApp User' 
  },
  // You can add more user lookups here...
};

// --- API Endpoint: /api/sms/send ---
router.post('/send', async (req, res) => {
  const { userId, messageBody } = req.body; 

  try {
    // 1. Authenticate user/Simulate database lookup
    // NOTE: In a real app, you would look up the number using your Mongoose User model:
    // const user = await User.findById(userId).select('mobile_number name');
    const userData = mockDatabase[userId];
    
    if (!userData) {
      return res.status(404).json({ success: false, message: 'User not found or number missing in DB.' });
    }

    const recipientNumber = userData.mobile_number;
    const senderNumber = process.env.TWILIO_PHONE_NUMBER;

    if (!recipientNumber || !senderNumber) {
      // This error likely means a missing .env variable or missing number in the mock DB
      throw new Error('Missing sender or recipient number in configuration/database.');
    }

    // 2. Send SMS using Twilio's API
    const message = await twilioClient.messages.create({
      body: messageBody || `Hello ${userData.name}, your system update code is 9988.`,
      to: recipientNumber,
      from: senderNumber, 
    });

    // 3. Success Response
    console.log(`✅ SMS Sent. SID: ${message.sid} to ${recipientNumber}`);
    res.json({ 
      success: true, 
      message: 'SMS queued successfully!', 
      sid: message.sid 
    });

  } catch (error) {
    // 4. Error Handling
    console.error('❌ Twilio SMS Error:', error.message);
    res.status(500).json({ 
      success: false, 
      message: `Failed to send SMS. Twilio Error: ${error.message}` 
    });
  }
});

module.exports = router;