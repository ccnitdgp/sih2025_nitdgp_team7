const express = require("express");
const router = express.Router();
const nodemailer = require("nodemailer");
const { v4: uuidv4 } = require("uuid");
const Negotiation = require("../models/Negotiation");

// --- EMAIL CONFIGURATION (SMTP) ---
// This is separate from your Gmail API ingestion
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "ipshitatandon@gmail.com",      // <--- YOUR GMAIL
    pass: "bacojwyvhcwmixxe",       // <--- YOUR APP PASSWORD (No spaces)
  },
});

// 1. CREATE REQUEST & SEND EMAIL
router.post("/create", async (req, res) => {
  try {
    const { project_name, budget, deadline, vendor_email } = req.body;
    
    // Generate Magic Token
    const token = uuidv4();
    // CHANGE THIS URL to your actual Frontend URL
    const magic_link = `http://localhost:8080/proposal/${token}`; 

    // Save to DB
    const newNegotiation = new Negotiation({
      token,
      project_name,
      budget,
      deadline,
      vendor_email
    });
    
    await newNegotiation.save();

    // Send Email
    const mailOptions = {
      from: '"KMRL Vendor System" <your_email@gmail.com>',
      to: vendor_email,
      subject: `New Work Request: ${project_name}`,
      text: `Hello,\n\nKMRL has invited you to submit a proposal.\n\nProject: ${project_name}\nBudget: ₹${budget}\n\nClick here to pitch: ${magic_link}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("❌ Email Error:", error);
        // Return success anyway so the UI doesn't freeze. We send the link for debugging.
        return res.json({ 
          success: true, 
          message: "Created, but email failed", 
          debug_link: magic_link 
        });
      } else {
        console.log("✅ Email Sent:", info.response);
        return res.json({ 
          success: true, 
          message: "Email sent successfully",
          debug_link: magic_link 
        });
      }
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// 2. GET DETAILS (Shared by Manager & Vendor)
router.get("/details", async (req, res) => {
  try {
    const { token, id } = req.query;
    let query = {};
    
    if (token) query.token = token;
    else if (id) query._id = id;
    else return res.status(400).json({ error: "Missing token or ID" });

    const doc = await Negotiation.findOne(query);
    if (!doc) return res.status(404).json({ error: "Not found" });
    
    res.json(doc);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. SUBMIT PITCH (Vendor Action)
router.post("/submit-pitch", async (req, res) => {
  try {
    const { token, quote, remarks } = req.body;
    
    const doc = await Negotiation.findOneAndUpdate(
      { token },
      {
        status: "NEGOTIATION_ACTIVE",
        vendor_pitch: { quote, remarks, submitted_at: new Date() },
        $push: { 
          messages: { 
            sender: "VENDOR", 
            text: `OFFICIAL PROPOSAL: ₹${quote}\nRemarks: ${remarks}` 
          }
        }
      },
      { new: true }
    );
    
    res.json(doc);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 4. SEND MESSAGE (Chat)
router.post("/send-message", async (req, res) => {
  try {
    const { token, id, sender, text } = req.body;
    let query = {};
    if (token) query.token = token;
    else if (id) query._id = id;

    await Negotiation.findOneAndUpdate(
      query,
      { $push: { messages: { sender, text, timestamp: new Date() } } }
    );
    
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 5. GET ALL (For Manager Sidebar)
router.get("/list", async (req, res) => {
  try {
    const list = await Negotiation.find().sort({ created_at: -1 });
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;